"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { AbilityData, AttackData } from "@/game/types";
import { store } from "@/game/store";
import { CheckField, NumField, SelectField, TextField, toast } from "@/components/ui";
import { sfx } from "@/game/sfx";

const EFFECTS = [
  { value: "damage", label: "DAMAGE — hurt one/all heroes" },
  { value: "heal", label: "HEAL — restore boss HP" },
  { value: "drain", label: "DRAIN — damage + heal from it" },
  { value: "buff", label: "BUFF — raise boss stat" },
  { value: "debuff", label: "DEBUFF — lower hero stat" },
  { value: "bullet", label: "BULLET PATTERN — launch SOUL attack" },
];
const TARGETS = [
  { value: "self", label: "SELF" },
  { value: "hero", label: "SINGLE HERO" },
  { value: "all", label: "ALL HEROES" },
  { value: "random", label: "RANDOM HERO" },
  { value: "soul", label: "SOUL (bullet phase)" },
  { value: "none", label: "NO TARGET" },
];
const CATEGORIES = ["offensive", "defensive", "healing", "bullet", "buff", "debuff", "utility"];

function AbilityEditor() {
  const router = useRouter();
  const params = useSearchParams();
  const id = params.get("id");
  const [ab, setAb] = useState<AbilityData | null>(null);
  const [missing, setMissing] = useState(false);
  const [dirty, setDirty] = useState(false);

  useEffect(() => {
    store.ensureLoaded().then(() => {
      if (!id) return setMissing(true);
      const row = store.get(id);
      if (!row || row.kind !== "ability") return setMissing(true);
      setAb(JSON.parse(JSON.stringify(row.data)) as AbilityData);
    });
  }, [id]);

  const attacks = useMemo(() => store.byKind<AttackData>("attack"), [store.loaded]); // eslint-disable-line react-hooks/exhaustive-deps

  if (missing)
    return (
      <main className="min-h-screen checker flex items-center justify-center">
        <div className="pixel-panel p-8 text-2xl">
          ABILITY NOT FOUND.{" "}
          <button className="pixel-btn ml-2" onClick={() => router.push("/abilities")}>
            BACK
          </button>
        </div>
      </main>
    );
  if (!ab) return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  const update = (patch: Partial<AbilityData>) => {
    setAb({ ...ab, ...patch });
    setDirty(true);
  };

  async function save() {
    if (!id || !ab) return;
    await store.update(id, ab.name || "Untitled Ability", ab);
    setDirty(false);
    toast("ABILITY SAVED");
    sfx.confirm();
  }

  const isBullet = ab.effect === "bullet";
  const isBuffDebuff = ab.effect === "buff" || ab.effect === "debuff";
  const isDrain = ab.effect === "drain";
  const isHeal = ab.effect === "heal";

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-3xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/abilities")}>
            ◀ ABILITIES
          </button>
          <h1 className="font-display text-lg text-[#ffe14d] flex-1">ABILITY EDITOR</h1>
          <span className={`text-lg ${dirty ? "text-[#ff2040]" : "text-[#46e6a0]"}`}>{dirty ? "* UNSAVED" : "* SAVED"}</span>
          <button className="pixel-btn solid" onClick={save}>
            SAVE
          </button>
        </header>

        <div className="pixel-panel p-4 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <TextField label="NAME" value={ab.name} onCommit={(v) => update({ name: v })} />
            <SelectField
              label="CATEGORY"
              value={ab.category}
              options={CATEGORIES.map((c) => ({ value: c, label: c.toUpperCase() }))}
              onChange={(v) => update({ category: v as AbilityData["category"] })}
            />
          </div>
          <TextField label="DESCRIPTION" value={ab.description} onCommit={(v) => update({ description: v })} />
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <NumField label="TP COST" value={ab.tpCost} min={0} max={999} onCommit={(v) => update({ tpCost: v })} />
            <NumField label="COOLDOWN (TURNS)" value={ab.cooldown} min={0} max={9} onCommit={(v) => update({ cooldown: v })} />
            <SelectField label="TARGET" value={ab.target} options={TARGETS} onChange={(v) => update({ target: v as AbilityData["target"] })} />
            <SelectField label="EFFECT" value={ab.effect} options={EFFECTS} onChange={(v) => update({ effect: v as AbilityData["effect"] })} />
          </div>

          {isBullet ? (
            <div className="pixel-inset p-4 space-y-3">
              <div className="pixel-label">BULLET PATTERN — THIS ABILITY LAUNCHES AN ATTACK IN THE SOUL ARENA</div>
              <SelectField
                label="ATTACK PATTERN"
                value={ab.attackId ?? ""}
                options={[{ value: "", label: "— SELECT ATTACK —" }, ...attacks.map((a) => ({ value: a.id, label: a.name }))]}
                onChange={(v) => update({ attackId: v || null })}
              />
              <p className="text-lg text-[#9a9ab8]">
                DAMAGE COMES FROM THE PATTERN ITSELF: EACH PROJECTILE USES ITS OWN DAMAGE MULTIPLIER × BOSS ATTACK. CREATE
                PATTERNS IN THE ATTACK CREATOR.
              </p>
              <button className="pixel-btn" onClick={() => router.push("/attacks")}>
                OPEN ATTACK CREATOR
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <NumField
                label={isHeal ? "HEAL AMOUNT" : "POWER"}
                value={ab.power}
                min={0}
                step={isBuffDebuff ? 1 : 5}
                onCommit={(v) => update({ power: v })}
              />
              {!isBuffDebuff && !isHeal && (
                <CheckField
                  label="POWER × ATTACK (multiplier)"
                  checked={ab.powerIsMultiplier}
                  onChange={(v) => update({ powerIsMultiplier: v })}
                />
              )}
              {isDrain && (
                <NumField
                  label="HEAL % OF DMG"
                  value={Math.round(ab.drainHeal * 100)}
                  min={0}
                  max={200}
                  onCommit={(v) => update({ drainHeal: v / 100 })}
                />
              )}
            </div>
          )}

          {isBuffDebuff && (
            <div className="grid grid-cols-3 gap-4">
              <SelectField
                label="STAT"
                value={ab.buffStat}
                options={[
                  { value: "attack", label: "ATTACK" },
                  { value: "defense", label: "DEFENSE" },
                ]}
                onChange={(v) => update({ buffStat: v as "attack" | "defense" })}
              />
              <NumField label="AMOUNT" value={ab.buffAmount} min={-99} max={99} onCommit={(v) => update({ buffAmount: v })} />
              <NumField label="DURATION (TURNS)" value={ab.buffDuration} min={1} max={9} onCommit={(v) => update({ buffDuration: v })} />
            </div>
          )}

          <div className="pixel-inset p-3 text-xl text-[#c9c9d9]">
            PREVIEW: <span className="text-[#ffe14d]">{ab.name || "?"}</span> — COST {ab.tpCost} TP
            {ab.cooldown > 0 ? `, CD ${ab.cooldown}` : ""}.{" "}
            {isBullet
              ? "Launches the selected bullet pattern against the AI SOUL."
              : isHeal
              ? `Restores ${ab.power} HP.`
              : isDrain
              ? `Deals ${ab.powerIsMultiplier ? `${ab.power}× ATK` : ab.power} damage, heals ${Math.round(ab.drainHeal * 100)}% of it.`
              : isBuffDebuff
              ? `${ab.effect === "buff" ? "Raises" : "Lowers"} ${ab.buffStat.toUpperCase()} by ${Math.abs(ab.buffAmount)} for ${ab.buffDuration} turns.`
              : `Deals ${ab.powerIsMultiplier ? `${ab.power}× ATK` : ab.power} damage.`}
          </div>
        </div>
      </div>
    </main>
  );
}

export default function AbilityEditPage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <AbilityEditor />
    </Suspense>
  );
}
