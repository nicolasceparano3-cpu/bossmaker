"use client";

import CreationsList from "@/components/CreationsList";
import { newAbility, type AbilityData } from "@/game/types";

export const CATEGORY_ICON: Record<string, string> = {
  offensive: "⚔",
  defensive: "🛡",
  healing: "✚",
  bullet: "✦",
  buff: "▲",
  debuff: "▼",
  utility: "◆",
};

export default function AbilitiesPage() {
  return (
    <CreationsList
      kind="ability"
      title="ABILITY CREATOR"
      subtitle="FORGE THE ARSENAL OF YOUR BOSS"
      newLabel="NEW ABILITY"
      makeNew={() => {
        const d = newAbility("New Ability");
        return { name: d.name, data: d };
      }}
      editHref={(id) => `/abilities/edit?id=${id}`}
      preview={(a) => {
        const ab = a.data as AbilityData;
        return (
          <div className="pixel-inset w-12 h-12 flex flex-col items-center justify-center">
            <span className="text-2xl text-[#ffe14d]">{CATEGORY_ICON[ab.category] ?? "◆"}</span>
            <span className="text-xs text-[#46e6a0]">{ab.tpCost}TP</span>
          </div>
        );
      }}
    />
  );
}
