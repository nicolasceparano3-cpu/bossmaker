"use client";
// ============================================================
// Animator: sprite-swap frame animations + particle emitters.
// Animations are assigned to bosses per trigger (idle, damaged,
// killed, attack, victory, per-ability). Emitters spawn at their
// spawnAt and only despawn at despawnAt — they can outlive the
// animation. Modes: BURST (once) and CONTINUOUS (loops).
// ============================================================

import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { AnimationData, ParticleAnchor } from "@/game/types";
import { PARTICLE_ANCHORS, newEmitter } from "@/game/types";
import { BUILTIN_SPRITES, drawSpriteAt, resolveSprite } from "@/game/sprites";
import { ParticleSystem } from "@/game/particles";
import { store } from "@/game/store";
import { CheckField, NumField, SelectField, TextField, toast } from "@/components/ui";
import { sfx } from "@/game/sfx";

const CW = 460;
const CH = 260;

function previewAnchor(a: ParticleAnchor, runSeed: number): { x: number; y: number } {
  switch (a) {
    case "boss":
      return { x: 360, y: 130 };
    case "hero1":
      return { x: 80, y: 70 };
    case "hero2":
      return { x: 80, y: 110 };
    case "hero3":
      return { x: 80, y: 150 };
    case "hero4":
      return { x: 80, y: 190 };
    case "lastDamaged":
      return { x: 80, y: 110 };
    case "randomHero":
      return { x: 80, y: 70 + ((runSeed * 37) % 4) * 40 };
    case "target":
      return { x: 80, y: 110 };
    case "center":
      return { x: 230, y: 130 };
    case "top":
      return { x: 230, y: 26 };
    case "bottom":
      return { x: 230, y: 234 };
  }
}

function AnimatorEditor({ assetId }: { assetId: string }) {
  const router = useRouter();
  const [anim, setAnim] = useState<AnimationData | null>(null);
  const [missing, setMissing] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [selEm, setSelEm] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [loop, setLoop] = useState(true);
  const [time, setTime] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const psRef = useRef(new ParticleSystem());
  const timeRef = useRef(0);
  const playingRef = useRef(false);
  const loopRef = useRef(true);
  const animRef = useRef<AnimationData | null>(null);
  const spawnedRef = useRef<Set<string>>(new Set());
  const runSeedRef = useRef(1);
  playingRef.current = playing;
  loopRef.current = loop;
  animRef.current = anim;

  useEffect(() => {
    store.ensureLoaded().then(() => {
      const row = store.get(assetId);
      if (!row || row.kind !== "animation") return setMissing(true);
      setAnim(JSON.parse(JSON.stringify(row.data)) as AnimationData);
    });
  }, [assetId]);

  const total = useMemo(() => (anim ? anim.frames.reduce((s, f) => s + f.duration, 0) : 0), [anim]);

  const mutate = (fn: (d: AnimationData) => void) => {
    setAnim((cur) => {
      if (!cur) return cur;
      const d = JSON.parse(JSON.stringify(cur)) as AnimationData;
      fn(d);
      return d;
    });
    setDirty(true);
  };

  // ---------------- preview loop ----------------
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const a = animRef.current;
      if (a && playingRef.current) {
        timeRef.current += dt;
        const tot = a.frames.reduce((s, f) => s + f.duration, 0);
        // emitter spawns (once per run)
        for (const em of a.emitters) {
          if (timeRef.current >= em.spawnAt && !spawnedRef.current.has(em.id)) {
            spawnedRef.current.add(em.id);
            const p = previewAnchor(em.anchor, runSeedRef.current);
            psRef.current.spawnEmitter(em, p.x, p.y);
          }
        }
        if (timeRef.current >= tot) {
          if (loopRef.current) {
            timeRef.current = 0;
            spawnedRef.current.clear();
            runSeedRef.current++;
          } else {
            setPlaying(false);
          }
        }
        psRef.current.update(dt);
        setTime(timeRef.current);
      }
      draw();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function draw() {
    const canvas = canvasRef.current;
    const a = animRef.current;
    if (!canvas || !a) return;
    const ctx = canvas.getContext("2d")!;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, CW, CH);
    // anchor markers
    ctx.save();
    ctx.globalAlpha = 0.35;
    ctx.fillStyle = "#7b4fb0";
    for (const [i, y] of [70, 110, 150, 190].entries()) {
      ctx.fillRect(72, y - 8, 16, 16);
      ctx.fillStyle = "#7b4fb0";
      void i;
    }
    ctx.fillStyle = "#46e6a0";
    ctx.fillRect(352, 122, 16, 16);
    ctx.restore();
    // current frame sprite centered
    let t = timeRef.current;
    let spriteId = a.frames[0]?.spriteId ?? "boss_grim";
    for (const f of a.frames) {
      if (t < f.duration) {
        spriteId = f.spriteId;
        break;
      }
      t -= f.duration;
    }
    const sprite = resolveSprite(spriteId, store.spriteData(spriteId));
    const norm = sprite.kind === "image" ? 96 / sprite.h : 5;
    drawSpriteAt(ctx, sprite, 230, 130, sprite.kind === "image" ? norm : 5, 0, 1);
    psRef.current.render(ctx, (id) => store.spriteData(id));
  }

  if (missing)
    return (
      <main className="min-h-screen checker flex items-center justify-center">
        <div className="pixel-panel p-8 text-2xl">
          ANIMATION NOT FOUND.{" "}
          <button className="pixel-btn ml-2" onClick={() => router.push("/animations")}>
            BACK
          </button>
        </div>
      </main>
    );
  if (!anim) return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  async function save() {
    if (!anim) return;
    await store.update(assetId, anim.name || "Untitled Animation", anim);
    setDirty(false);
    toast("ANIMATION SAVED");
    sfx.confirm();
  }

  const sel = anim.emitters.find((e) => e.id === selEm) ?? null;
  const spriteOptions = [
    ...Object.keys(BUILTIN_SPRITES).map((s) => ({ value: s, label: s })),
    ...store.byKind("sprite").map((a) => ({ value: a.id, label: `★ ${a.name}` })),
  ];

  return (
    <main className="min-h-screen checker px-3 py-4">
      <div className="max-w-[1300px] mx-auto space-y-3">
        <header className="flex flex-wrap items-center gap-2">
          <button className="pixel-btn" onClick={() => router.push("/animations")}>
            ◀ ANIMATIONS
          </button>
          <input
            className="pixel-input !w-56 text-xl"
            value={anim.name}
            onChange={(e) => mutate((d) => void (d.name = e.target.value))}
          />
          <span className={`text-lg ${dirty ? "text-[#ff2040]" : "text-[#46e6a0]"}`}>{dirty ? "* UNSAVED" : "* SAVED"}</span>
          <span className="text-lg text-[#9a9ab8]">LENGTH {total.toFixed(2)}s</span>
          <div className="flex-1" />
          <button className="pixel-btn solid" onClick={save}>
            SAVE
          </button>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-[300px_1fr_340px] gap-3">
          {/* frames */}
          <div className="pixel-panel p-3 space-y-2 self-start">
            <div className="flex items-center justify-between">
              <div className="pixel-label">FRAMES (SPRITE SWAP)</div>
              <button
                className="pixel-btn !py-0.5 !px-2 text-base"
                onClick={() => mutate((d) => void d.frames.push({ spriteId: "boss_grim", duration: 0.3 }))}
              >
                + ADD
              </button>
            </div>
            {anim.frames.map((f, i) => (
              <div key={i} className="pixel-inset p-2 space-y-1">
                <div className="flex gap-1 items-center">
                  <span className="text-[#7a7a96] text-lg w-6">{i + 1}.</span>
                  <select
                    className="pixel-input !text-base flex-1"
                    value={f.spriteId}
                    onChange={(e) => mutate((d) => void (d.frames[i].spriteId = e.target.value))}
                  >
                    {spriteOptions.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-1 items-center">
                  <NumField label="HOLD s" value={f.duration} min={0.02} max={10} step={0.05} onCommit={(v) => mutate((d) => void (d.frames[i].duration = v))} className="flex-1" />
                  <button className="pixel-btn !py-0.5 !px-1.5 text-sm" disabled={i === 0} onClick={() => mutate((d) => { const t2 = d.frames[i - 1]; d.frames[i - 1] = d.frames[i]; d.frames[i] = t2; })}>
                    ▲
                  </button>
                  <button className="pixel-btn !py-0.5 !px-1.5 text-sm" disabled={i === anim.frames.length - 1} onClick={() => mutate((d) => { const t2 = d.frames[i + 1]; d.frames[i + 1] = d.frames[i]; d.frames[i] = t2; })}>
                    ▼
                  </button>
                  <button className="pixel-btn danger !py-0.5 !px-1.5 text-sm" onClick={() => mutate((d) => void d.frames.splice(i, 1))}>
                    ✕
                  </button>
                </div>
              </div>
            ))}
            <p className="text-base text-[#7a7a96]">
              FRAMES PLAY IN ORDER AND LOOP WHILE THE TRIGGER IS IDLE. ONE-SHOT TRIGGERS (DAMAGED, ATTACK…) PLAY ONCE.
            </p>
          </div>

          {/* preview */}
          <div className="pixel-panel p-2 self-start">
            <canvas ref={canvasRef} width={CW} height={CH} className="w-full" />
            <div className="flex items-center gap-2 mt-2 flex-wrap text-lg">
              <button
                className="pixel-btn solid !px-3"
                onClick={() => {
                  if (!playing) {
                    if (timeRef.current >= total) {
                      timeRef.current = 0;
                      spawnedRef.current.clear();
                    }
                    setPlaying(true);
                  } else setPlaying(false);
                }}
              >
                {playing ? "❚❚ PAUSE" : "▶ PLAY"}
              </button>
              <button
                className="pixel-btn !px-3"
                onClick={() => {
                  setPlaying(false);
                  timeRef.current = 0;
                  spawnedRef.current.clear();
                  psRef.current.clear();
                  setTime(0);
                }}
              >
                ■ RESET
              </button>
              <button className={`pixel-btn !px-3 ${loop ? "solid" : ""}`} onClick={() => setLoop(!loop)}>
                LOOP
              </button>
              <span className="text-[#ffe14d] ml-2">T = {time.toFixed(2)}s / {total.toFixed(2)}s</span>
              <span className="text-[#9a9ab8]">PARTICLES {psRef.current.particles.length} · EMITTERS {psRef.current.emitterCount}</span>
            </div>
            <p className="text-base text-[#7a7a96] mt-1">
              PREVIEW ANCHORS: GREEN = BOSS, PURPLE = HEROES 1–4. EMITTERS PERSIST PAST THE ANIMATION UNTIL THEIR DESPAWN TIME.
            </p>
          </div>

          {/* emitters */}
          <div className="pixel-panel p-3 space-y-2 self-start">
            <div className="flex items-center justify-between">
              <div className="pixel-label">PARTICLE EMITTERS</div>
              <button
                className="pixel-btn !py-0.5 !px-2 text-base"
                onClick={() => {
                  const em = newEmitter(Math.round(time * 20) / 20);
                  mutate((d) => void d.emitters.push(em));
                  setSelEm(em.id);
                }}
              >
                + ADD
              </button>
            </div>
            <div className="space-y-1 max-h-40 overflow-auto">
              {anim.emitters.map((e) => (
                <button
                  key={e.id}
                  className={`w-full text-left px-2 py-1 text-lg cursor-pointer border ${
                    selEm === e.id ? "bg-[#ffe14d] text-black border-[#ffe14d]" : "border-transparent text-[#c9c9d9] hover:bg-[#22223a]"
                  }`}
                  onClick={() => setSelEm(e.id)}
                >
                  {e.name} <span className="text-xs opacity-60">[{e.mode} @ {e.spawnAt}s → {e.despawnAt == null ? "∞" : `${e.despawnAt}s`}]</span>
                </button>
              ))}
            </div>

            {sel && (
              <div className="space-y-2">
                <div className="flex gap-1">
                  <TextField label="NAME" value={sel.name} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.name = v))} />
                  <button className="pixel-btn danger self-end !py-1" onClick={() => { mutate((d) => void (d.emitters = d.emitters.filter((x) => x.id !== sel.id))); setSelEm(null); }}>
                    DEL
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <SelectField label="PARTICLE SPRITE" value={sel.spriteId} options={spriteOptions} onChange={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.spriteId = v))} />
                  <SelectField label="MODE" value={sel.mode} options={[{ value: "burst", label: "BURST — all at once" }, { value: "continuous", label: "CONTINUOUS — loops" }]} onChange={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.mode = v as "burst" | "continuous"))} />
                  <SelectField label="SPAWN AT (ANCHOR)" value={sel.anchor} options={PARTICLE_ANCHORS.map((p) => ({ value: p.value, label: p.label }))} onChange={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.anchor = v as ParticleAnchor))} />
                  <NumField label="SPAWN AT s" value={sel.spawnAt} min={0} max={60} step={0.05} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.spawnAt = v))} />
                  <NumField label="DESPAWN AFTER s (0=∞)" value={sel.despawnAt ?? 0} min={0} max={120} step={0.1} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.despawnAt = v <= 0 ? null : v))} />
                  <NumField label={sel.mode === "burst" ? "PARTICLES" : "PER TICK"} value={sel.count} min={1} max={200} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.count = v))} />
                  {sel.mode === "continuous" && (
                    <NumField label="INTERVAL s" value={sel.interval} min={0.01} max={5} step={0.05} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.interval = v))} />
                  )}
                  <NumField label="LIFETIME s" value={sel.lifetime} min={0.05} max={10} step={0.1} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.lifetime = v))} />
                  <NumField label="OUTWARD SPEED" value={sel.speed} min={0} max={600} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.speed = v))} />
                  <NumField label="DRIFT X" value={sel.driftX} min={-400} max={400} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.driftX = v))} />
                  <NumField label="DRIFT Y (−=UP)" value={sel.driftY} min={-400} max={400} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.driftY = v))} />
                  <NumField label="GRAVITY" value={sel.gravity} min={-400} max={400} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.gravity = v))} />
                  <NumField label="SPIN °/s" value={sel.rotSpeed} min={-720} max={720} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.rotSpeed = v))} />
                  <NumField label="SCALE" value={sel.scale} min={0.5} max={10} step={0.5} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.scale = v))} />
                  <NumField label="SPREAD" value={sel.spread} min={0} max={120} onCommit={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.spread = v))} />
                </div>
                <div className="flex gap-4">
                  <CheckField label="MOVE OUTWARD" checked={sel.outward} onChange={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.outward = v))} />
                  <CheckField label="FADE OUT" checked={sel.fade} onChange={(v) => mutate((d) => void (d.emitters.find((x) => x.id === sel.id)!.fade = v))} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

function EditInner() {
  const params = useSearchParams();
  const id = params.get("id");
  if (!id) return <main className="min-h-screen checker flex items-center justify-center text-2xl">NO ANIMATION SELECTED.</main>;
  return <AnimatorEditor assetId={id} />;
}

export default function AnimationEditPage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <EditInner />
    </Suspense>
  );
}
