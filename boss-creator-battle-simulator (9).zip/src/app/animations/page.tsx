"use client";

import CreationsList from "@/components/CreationsList";
import { newAnimation, type AnimationData } from "@/game/types";
import { SpriteView } from "@/components/ui";

export default function AnimationsPage() {
  return (
    <CreationsList
      kind="animation"
      title="ANIMATOR"
      subtitle="SPRITE-SWAP ANIMATIONS + PARTICLE EMITTERS, TRIGGERED IN BATTLE"
      newLabel="NEW ANIMATION"
      makeNew={() => {
        const d = newAnimation("New Animation");
        return { name: d.name, data: d };
      }}
      editHref={(id) => `/animations/edit?id=${id}`}
      preview={(a) => {
        const an = a.data as AnimationData;
        return (
          <div className="flex items-center gap-2">
            <SpriteView spriteId={an.frames[0]?.spriteId ?? "boss_grim"} scale={2} />
            <span className="text-lg text-[#9a9ab8]">
              {an.frames.length} FRAMES
              <br />
              {an.emitters.length} EMITTERS
            </span>
          </div>
        );
      }}
    />
  );
}
