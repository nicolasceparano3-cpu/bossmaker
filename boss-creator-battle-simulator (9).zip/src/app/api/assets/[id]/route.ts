import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { assets } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    const body = await req.json();
    const updated = await db
      .update(assets)
      .set({
        name: String(body.name ?? "Untitled"),
        data: body.data ?? {},
        kind: body.kind ? String(body.kind) : undefined,
        updatedAt: Date.now(),
      })
      .where(eq(assets.id, id))
      .returning();
    if (!updated.length) return NextResponse.json({ error: "not found" }, { status: 404 });
    return NextResponse.json({ asset: updated[0] });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await ctx.params;
    await db.delete(assets).where(eq(assets.id, id));
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
