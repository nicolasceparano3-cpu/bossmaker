import { NextResponse } from "next/server";
import { db } from "@/db";
import { assets, type AssetRow } from "@/db/schema";
import { seedAssets } from "@/game/defaults";
import { uid } from "@/game/types";

export const dynamic = "force-dynamic";

async function ensureSeeded(): Promise<void> {
  const existing = await db.select({ id: assets.id }).from(assets);
  const have = new Set(existing.map((r) => r.id));
  const now = Date.now();
  const missing = seedAssets()
    .filter((s) => !have.has(s.id))
    .map((s) => ({ id: s.id, kind: s.kind, name: s.name, data: s.data, updatedAt: now }));
  if (missing.length) await db.insert(assets).values(missing);
}

export async function GET() {
  try {
    await ensureSeeded();
    const rows: AssetRow[] = await db.select().from(assets).orderBy(assets.updatedAt);
    return NextResponse.json({ assets: rows });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const id = (body.id as string) || uid(body.kind || "asset");
    const row = {
      id,
      kind: String(body.kind),
      name: String(body.name || "Untitled"),
      data: body.data ?? {},
      updatedAt: Date.now(),
    };
    await db.insert(assets).values(row);
    return NextResponse.json({ asset: row });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
