"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import AttackEditor from "@/components/AttackEditor";

function EditInner() {
  const params = useSearchParams();
  const id = params.get("id");
  if (!id)
    return (
      <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">
        NO ATTACK SELECTED. GO BACK AND PICK ONE.
      </main>
    );
  return <AttackEditor assetId={id} initialTest={params.get("test") === "1"} />;
}

export default function AttackEditPage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <EditInner />
    </Suspense>
  );
}
