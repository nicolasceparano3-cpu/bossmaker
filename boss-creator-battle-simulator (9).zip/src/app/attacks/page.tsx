"use client";

import CreationsList from "@/components/CreationsList";
import { newAttack, type AttackData } from "@/game/types";
import { SpriteView } from "@/components/ui";

export default function AttacksPage() {
  return (
    <CreationsList
      kind="attack"
      title="ATTACK CREATOR"
      subtitle="TIMELINE-DRIVEN BULLET-HELL PATTERNS"
      newLabel="NEW ATTACK"
      makeNew={() => {
        const d = newAttack("New Attack");
        return { name: d.name, data: d };
      }}
      editHref={(id) => `/attacks/edit?id=${id}`}
      preview={(a) => {
        const at = a.data as AttackData;
        return (
          <div className="flex items-center gap-2">
            <div className="pixel-inset w-16 h-10 flex items-center justify-center">
              <span className="text-[#ff2040] text-lg">❤</span>
            </div>
            <span className="text-lg text-[#9a9ab8]">
              {at.objects.length} OBJ
              <br />
              {at.duration.toFixed(1)}s
            </span>
          </div>
        );
      }}
      extraActions={(a) => (
        <a className="pixel-btn gold !py-1" href={`/attacks/edit?id=${a.id}&test=1`}>
          TEST
        </a>
      )}
    />
  );
}
