"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { AbilityData, BossData } from "@/game/types";
import { SOUL_DIFFICULTIES } from "@/game/types";
import { allHeroesMeta } from "@/game/heroRegistry";
import { loadBattleConfig, saveBattleConfig, store } from "@/game/store";
import { SpriteView, toast } from "@/components/ui";
import BattleView from "@/components/battle/BattleView";
import { sfx } from "@/game/sfx";

function BattlePageInner() {
  const router = useRouter();
  const params = useSearchParams();
  const [, force] = useState(0);
  const [ready, setReady] = useState(false);
  const [cfg, setCfg] = useState(loadBattleConfig());
  const [started, setStarted] = useState(false);

  useEffect(() => {
    store.ensureLoaded().then(() => {
      const bossParam = params.get("boss");
      setCfg((c) => ({ ...c, bossId: bossParam && store.get(bossParam) ? bossParam : c.bossId }));
      setReady(true);
    });
  }, [params]);

  const bosses = store.byKind<BossData>("boss");
  const bossAsset = store.resolveBoss(cfg.bossId) ?? bosses[0];

  function toggleHero(id: string) {
    sfx.move();
    setCfg((c) => {
      const has = c.heroIds.includes(id);
      const next = has ? c.heroIds.filter((x) => x !== id) : [...c.heroIds, id];
      return { ...c, heroIds: next };
    });
  }

  function startBattle() {
    if (!bossAsset) {
      toast("CREATE A BOSS FIRST!");
      router.push("/bosses");
      return;
    }
    if (cfg.heroIds.length === 0) {
      toast("SELECT AT LEAST ONE HERO");
      return;
    }
    saveBattleConfig(cfg);
    sfx.confirm();
    setStarted(true);
  }

  if (!ready) return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  if (started && bossAsset) {
    const diff = SOUL_DIFFICULTIES.find((d) => d.id === cfg.soulDifficulty) ?? SOUL_DIFFICULTIES[1];
    return <BattleView key={bossAsset.id + cfg.heroIds.join(",")} bossAsset={bossAsset} heroIds={cfg.heroIds} difficulty={diff} />;
  }

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-4xl mx-auto space-y-4">
        <header className="flex items-center gap-3">
          <button className="pixel-btn" onClick={() => router.push("/")}>
            ◀ MENU
          </button>
          <h1 className="font-display text-lg text-[#ffe14d]">BATTLE SETUP</h1>
          <span className="text-xl text-[#9a9ab8]">CHOOSE YOUR BOSS AND THE HERO PARTY</span>
        </header>

        <div className="pixel-panel p-4">
          <div className="pixel-label mb-2">YOUR BOSS</div>
          {bosses.length === 0 ? (
            <div className="text-xl text-[#9a9ab8]">
              NO BOSSES YET —{" "}
              <button className="text-[#ffe14d] underline cursor-pointer" onClick={() => router.push("/bosses")}>
                CREATE ONE
              </button>
            </div>
          ) : (
            <div className="flex gap-3 flex-wrap">
              {bosses.map((b) => (
                <button
                  key={b.id}
                  onClick={() => {
                    sfx.select();
                    setCfg((c) => ({ ...c, bossId: b.id }));
                  }}
                  className={`pixel-inset p-3 flex flex-col items-center gap-1 cursor-pointer ${
                    bossAsset?.id === b.id ? "outline-2 outline-[#ffe14d]" : "opacity-70"
                  }`}
                >
                  <SpriteView spriteId={b.data.spriteId} spriteData={store.spriteData(b.data.spriteId)} scale={3} maxHeight={72} />
                  <span className="text-lg">{b.name}</span>
                  <span className="text-sm text-[#9a9ab8]">
                    HP {b.data.stats.maxHp} · ATK {b.data.stats.attack} ·{" "}
                    {b.data.abilityIds.length} SKILLS
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="pixel-panel p-4">
          <div className="pixel-label mb-2">HERO PARTY (AI-CONTROLLED)</div>
          <div className="flex gap-3 flex-wrap">
            {allHeroesMeta().map((h) => {
              const on = cfg.heroIds.includes(h.id);
              return (
                <button
                  key={h.id}
                  onClick={() => toggleHero(h.id)}
                  className={`pixel-inset p-3 flex flex-col items-center gap-1 cursor-pointer ${
                    on ? "outline-2 outline-[#46e6a0]" : "opacity-50"
                  }`}
                >
                  <SpriteView spriteId={h.spriteId} spriteData={store.spriteData(h.spriteId)} scale={3} maxHeight={56} />
                  <span className="text-lg">{h.name}</span>
                  <span className="text-sm text-[#9a9ab8]">HP {h.maxHp} · ATK {h.attack}</span>
                  <span className={`text-sm ${on ? "text-[#46e6a0]" : "text-[#7a7a96]"}`}>{on ? "■ IN PARTY" : "□ BENCH"}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="pixel-panel p-4">
          <div className="pixel-label mb-2">SOUL AI DIFFICULTY — HOW HARD THE SOUL TRIES TO DODGE YOUR PATTERNS</div>
          <div className="flex gap-2 flex-wrap">
            {SOUL_DIFFICULTIES.map((d) => (
              <button
                key={d.id}
                onClick={() => {
                  sfx.select();
                  setCfg((c) => ({ ...c, soulDifficulty: d.id }));
                }}
                className={`pixel-btn ${cfg.soulDifficulty === d.id ? "solid" : ""}`}
              >
                {d.name}
              </button>
            ))}
          </div>
          <p className="text-lg text-[#9a9ab8] mt-3">
            EASY SOULS MAKE MISTAKES AND GET HIT OFTEN. PERFECT MODE IS FOR TESTING WHETHER A PATTERN IS SURVIVABLE AT ALL.
          </p>
        </div>

        <div className="flex justify-center pt-2">
          <button className="pixel-btn solid !text-2xl !px-10 !py-4" onClick={startBattle}>
            ▶ START BATTLE
          </button>
        </div>
      </div>
    </main>
  );
}

export default function BattlePage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <BattlePageInner />
    </Suspense>
  );
}
