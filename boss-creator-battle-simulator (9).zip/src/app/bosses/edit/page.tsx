"use client";

import { Suspense, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { Asset, AbilityData, BossData } from "@/game/types";
import { BUILTIN_SPRITES } from "@/game/sprites";
import { store } from "@/game/store";
import { CheckField, Field, NumField, SelectField, SpriteView, TextField, toast } from "@/components/ui";
import { BATTLE_BACKGROUNDS, BG_EFFECTS } from "@/game/backgrounds";
import type { BossEffectDef, SoundData } from "@/game/types";
import { newBossEffect } from "@/game/types";
import { collectBossBundle } from "@/game/bundle";
import { downloadJson } from "@/game/store";
import { sfx } from "@/game/sfx";

const BOSS_SPRITE_PRESETS = ["boss_grim", "boss_fang", "kris", "susie", "ralsei", "noelle", "blade", "darkOrb"];

function BossEditor() {
  const router = useRouter();
  const params = useSearchParams();
  const id = params.get("id");
  const [, force] = useState(0);
  const [boss, setBoss] = useState<BossData | null>(null);
  const [dirty, setDirty] = useState(false);
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    store.ensureLoaded().then(() => {
      if (!id) return setMissing(true);
      const row = store.get(id);
      if (!row || row.kind !== "boss") return setMissing(true);
      setBoss(JSON.parse(JSON.stringify(row.data)) as BossData);
    });
  }, [id]);

  const abilityAssets = useMemo(() => store.byKind<AbilityData>("ability"), [store.loaded]); // eslint-disable-line react-hooks/exhaustive-deps
  const spriteAssets = useMemo(() => store.byKind("sprite"), [store.loaded]); // eslint-disable-line react-hooks/exhaustive-deps
  const animAssets = useMemo(() => store.byKind("animation"), [store.loaded]); // eslint-disable-line react-hooks/exhaustive-deps

  if (missing)
    return (
      <main className="min-h-screen checker flex items-center justify-center">
        <div className="pixel-panel p-8 text-center text-2xl">
          BOSS NOT FOUND.{" "}
          <button className="pixel-btn ml-2" onClick={() => router.push("/bosses")}>
            BACK
          </button>
        </div>
      </main>
    );
  if (!boss)
    return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  const update = (patch: Partial<BossData>) => {
    setBoss({ ...boss, ...patch });
    setDirty(true);
  };
  const updateStat = (key: keyof BossData["stats"], v: number) => {
    update({ stats: { ...boss.stats, [key]: v } });
  };

  const updateLayout = (who: "boss" | "hero", i: number, x?: number, y?: number) => {
    const layout = {
      boss: { ...(boss.layout?.boss ?? { x: 76, y: 45 }) },
      heroes: (boss.layout?.heroes ?? DEFAULT_HERO_XY.map(([hx, hy]) => ({ x: hx, y: hy }))).map((p) => ({ ...p })),
    };
    while (layout.heroes.length < 4) layout.heroes.push({ x: 25, y: 68 });
    if (who === "boss") {
      if (x !== undefined) layout.boss.x = x;
      if (y !== undefined) layout.boss.y = y;
    } else {
      if (x !== undefined) layout.heroes[i].x = x;
      if (y !== undefined) layout.heroes[i].y = y;
    }
    update({ layout });
  };

  async function save(silent = false) {
    if (!id || !boss) return;
    await store.update(id, boss.name || "Untitled Boss", boss);
    setDirty(false);
    if (!silent) {
      toast("BOSS SAVED");
      sfx.confirm();
    }
  }

  async function testBattle() {
    await save(true);
    router.push(`/battle?boss=${id}`);
  }

  const customSprite = store.spriteData(boss.spriteId);

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/bosses")}>
            ◀ BOSSES
          </button>
          <h1 className="font-display text-lg text-[#ffe14d] flex-1">BOSS CREATOR</h1>
          <span className={`text-lg ${dirty ? "text-[#ff2040]" : "text-[#46e6a0]"}`}>
            {dirty ? "* UNSAVED CHANGES" : "* SAVED"}
          </span>
          <button className="pixel-btn solid" onClick={() => save()}>
            SAVE
          </button>
          <button
            className="pixel-btn"
            onClick={async () => {
              await save(true);
              const bundle = collectBossBundle(id!);
              if (bundle) {
                downloadJson(`${boss.name.replace(/\s+/g, "_")}.boss.bundle.json`, bundle);
                toast("FULL BOSS BUNDLE EXPORTED");
              }
            }}
          >
            ⇩ FULL EXPORT
          </button>
          <button className="pixel-btn gold" onClick={testBattle}>
            ▶ TEST BOSS
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* identity + sprite */}
          <div className="pixel-panel p-4 space-y-3">
            <div className="pixel-label">IDENTITY</div>
            <TextField label="NAME" value={boss.name} onCommit={(v) => update({ name: v })} />
            <TextField label="DESCRIPTION" value={boss.description} onCommit={(v) => update({ description: v })} />
            <SelectField
              label="BATTLE BACKGROUND"
              value={boss.background ?? "green"}
              options={BATTLE_BACKGROUNDS.map((b) => ({ value: b.id, label: b.name }))}
              onChange={(v) => update({ background: v })}
            />
            <SelectField
              label="THEME MUSIC (LOOPS IN BATTLE)"
              value={boss.themeId ?? ""}
              options={[
                { value: "", label: "— NONE —" },
                ...store.byKind<SoundData>("sound").map((a) => ({ value: a.id, label: a.name })),
              ]}
              onChange={(v) => update({ themeId: v || undefined })}
            />
            <button className="pixel-btn w-full !py-1" onClick={() => router.push("/sounds")}>
              ♪ MANAGE SOUNDS / UPLOAD THEME
            </button>
            <div className="pixel-label pt-2">SPRITE</div>
            <div className="flex justify-center pixel-inset p-4">
              <SpriteView spriteId={boss.spriteId} spriteData={customSprite} scale={6} bob />
            </div>
            <div className="pixel-label">CHOOSE SPRITE</div>
            <div className="grid grid-cols-4 gap-2">
              {BOSS_SPRITE_PRESETS.map((s) => (
                <button
                  key={s}
                  className={`pixel-inset p-1 flex items-center justify-center cursor-pointer ${
                    boss.spriteId === s ? "outline-2 outline-[#ffe14d]" : ""
                  }`}
                  onClick={() => update({ spriteId: s })}
                  title={s}
                >
                  <SpriteView spriteId={s} scale={2} />
                </button>
              ))}
              {spriteAssets.map((s) => (
                <button
                  key={s.id}
                  className={`pixel-inset p-1 flex items-center justify-center cursor-pointer ${
                    boss.spriteId === s.id ? "outline-2 outline-[#ffe14d]" : ""
                  }`}
                  onClick={() => update({ spriteId: s.id })}
                  title={s.name}
                >
                  <SpriteView spriteId={s.id} spriteData={s.data as never} scale={2} />
                </button>
              ))}
            </div>
            <button className="pixel-btn w-full" onClick={() => router.push("/sprites")}>
              + DRAW NEW SPRITE
            </button>
          </div>

          {/* stats */}
          <div className="pixel-panel p-4 space-y-3">
            <div className="pixel-label">STATISTICS</div>
            <div className="grid grid-cols-2 gap-3">
              <NumField label="MAX HP" value={boss.stats.maxHp} min={1} onCommit={(v) => updateStat("maxHp", v)} />
              <NumField label="ATTACK" value={boss.stats.attack} min={0} onCommit={(v) => updateStat("attack", v)} />
              <NumField label="DEFENSE" value={boss.stats.defense} min={0} onCommit={(v) => updateStat("defense", v)} />
              <NumField label="SPEED" value={boss.stats.speed} min={0} onCommit={(v) => updateStat("speed", v)} />
              <NumField label="MAX TP" value={boss.stats.maxTp} min={0} onCommit={(v) => updateStat("maxTp", v)} />
              <NumField
                label="CRIT CHANCE %"
                value={Math.round(boss.stats.critChance * 100)}
                min={0}
                max={100}
                onCommit={(v) => updateStat("critChance", v / 100)}
              />
              <NumField
                label="CRIT DAMAGE x"
                value={boss.stats.critDamage}
                min={1}
                step={0.1}
                onCommit={(v) => updateStat("critDamage", v)}
              />
              <NumField
                label="SOUL DMG x"
                value={boss.stats.soulDamageMult}
                min={0.1}
                step={0.1}
                onCommit={(v) => updateStat("soulDamageMult", v)}
              />
            </div>
            <div className="pixel-hr" />
            <NumField
              label="SPRITE SIZE IN BATTLE (PX)"
              value={boss.spriteSize ?? 150}
              min={40}
              max={400}
              onCommit={(v) => update({ spriteSize: v })}
            />
            <p className="text-lg text-[#9a9ab8]">
              TP IS GAINED BY DEALING DAMAGE (+12% OF DMG), TAKING DAMAGE (+10%) AND DEFENDING (+8). SPEND IT ON ABILITIES.
            </p>
          </div>

          {/* abilities */}
          <div className="pixel-panel p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="pixel-label">ABILITIES ({boss.abilityIds.length})</div>
              <button className="pixel-btn !py-1" onClick={() => router.push("/abilities")}>
                + NEW
              </button>
            </div>
            <div className="space-y-2 max-h-[420px] overflow-auto pr-1">
              {abilityAssets.length === 0 && (
                <div className="text-lg text-[#9a9ab8]">NO ABILITIES YET. CREATE ONE IN THE ABILITY CREATOR.</div>
              )}
              {abilityAssets.map((a: Asset<AbilityData>) => {
                const on = boss.abilityIds.includes(a.id);
                return (
                  <button
                    key={a.id}
                    onClick={() => {
                      sfx.select();
                      update({
                        abilityIds: on ? boss.abilityIds.filter((x) => x !== a.id) : [...boss.abilityIds, a.id],
                      });
                    }}
                    className={`w-full text-left pixel-inset px-3 py-2 cursor-pointer flex items-center gap-2 ${
                      on ? "outline-2 outline-[#46e6a0]" : "opacity-70"
                    }`}
                  >
                    <span className={`text-xl ${on ? "text-[#46e6a0]" : "text-[#3a3a55]"}`}>{on ? "■" : "□"}</span>
                    <span className="flex-1 min-w-0">
                      <span className="text-xl text-white block truncate">{a.name}</span>
                      <span className="text-base text-[#9a9ab8] block truncate">{a.data.description}</span>
                    </span>
                    <span className="text-[#46e6a0] text-lg">{a.data.tpCost}TP</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* animations */}
        <div className="pixel-panel p-4 mt-4">
          <div className="flex items-center justify-between mb-3">
            <div className="pixel-label">ANIMATIONS — PLAYED AUTOMATICALLY IN BATTLE</div>
            <button className="pixel-btn !py-1" onClick={() => router.push("/animations")}>
              + NEW ANIMATION
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {ANIM_TRIGGERS(boss, (id) => abilityAssets.find((a) => a.id === id)?.name ?? "ABILITY").map(([key, label]) => (
              <SelectField
                key={key}
                label={label}
                value={boss.animations?.[key] ?? ""}
                options={[
                  { value: "", label: "— NONE —" },
                  ...animAssets.map((a) => ({ value: a.id, label: a.name })),
                ]}
                onChange={(v) => {
                  const next: Record<string, string> = { ...(boss.animations ?? {}) };
                  if (v) next[key] = v;
                  else delete next[key];
                  update({ animations: next });
                }}
              />
            ))}
          </div>
        </div>

        {/* stage / environment / effects */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
          <div className="pixel-panel p-4 space-y-3">
            <div className="pixel-label">STAGE & ENVIRONMENT</div>
            <div className="grid grid-cols-2 gap-3">
              <SelectField
                label="BATTLE BACKGROUND"
                value={boss.background ?? "grid"}
                options={BATTLE_BACKGROUNDS.map((b) => ({ value: b.id, label: b.name }))}
                onChange={(v) => update({ background: v })}
              />
              {(boss.background ?? "grid") === "grid" && (
                <Field label="LINE COLOR">
                  <input
                    type="color"
                    className="pixel-input h-9"
                    value={boss.bgColor ?? "#ff00ff"}
                    onChange={(e) => update({ bgColor: e.target.value })}
                  />
                </Field>
              )}
              <SelectField
                label="BACKGROUND EFFECT"
                value={boss.bgEffect ?? "none"}
                options={BG_EFFECTS.map((b) => ({ value: b.value, label: b.label }))}
                onChange={(v) => update({ bgEffect: v as typeof boss.bgEffect })}
              />
              <Field label="EFFECT COLOR">
                <input
                  type="color"
                  className="pixel-input h-9"
                  value={boss.bgEffectColor ?? "#46e6a0"}
                  onChange={(e) => update({ bgEffectColor: e.target.value })}
                />
              </Field>
              <SelectField
                label="FLOOR"
                value={boss.floor ?? "default"}
                options={[
                  { value: "default", label: "DEFAULT PLATFORM" },
                  { value: "none", label: "NONE (VOID)" },
                  ...spriteAssets.map((s) => ({ value: `sprite:${s.id}`, label: `★ ${s.name}` })),
                ]}
                onChange={(v) => update({ floor: v })}
              />
              <div className="flex flex-col gap-2 justify-end">
                <CheckField label="HOVER (GLIDE UP/DOWN)" checked={boss.hover ?? true} onChange={(v) => update({ hover: v })} />
                <CheckField label="AFTERIMAGES TRAIL" checked={boss.afterimages ?? false} onChange={(v) => update({ afterimages: v })} />
              </div>
            </div>
            <p className="text-base text-[#7a7a96]">
              FLOOR SPRITES ARE TILED ACROSS THE GROUND — DRAW YOUR OWN IN THE SPRITE EDITOR (WIDE + SHORT WORKS BEST).
              FIRE GROUND SPAWNS RISING EMBERS; SNOW DRIFTS DOWN-LEFT.
            </p>
            <div className="pixel-hr" />
            <div className="pixel-label">POSITIONS IN THE ARENA (% OF SCENE)</div>
            <StageVisualizer boss={boss} onMove={(who, i, x, y) => updateLayout(who, i, x, y)} />
            <div className="grid grid-cols-2 gap-3">
              <NumField label="BOSS X" value={boss.layout?.boss.x ?? 76} min={0} max={100} onCommit={(v) => updateLayout("boss", 0, v, undefined)} />
              <NumField label="BOSS Y" value={boss.layout?.boss.y ?? 45} min={0} max={100} onCommit={(v) => updateLayout("boss", 0, undefined, v)} />
              {[0, 1, 2, 3].map((i) => (
                <div key={i} className="contents">
                  <NumField
                    label={`HERO ${i + 1} X`}
                    value={boss.layout?.heroes?.[i]?.x ?? DEFAULT_HERO_XY[i][0]}
                    min={0}
                    max={100}
                    onCommit={(v) => updateLayout("hero", i, v, undefined)}
                  />
                  <NumField
                    label={`HERO ${i + 1} Y`}
                    value={boss.layout?.heroes?.[i]?.y ?? DEFAULT_HERO_XY[i][1]}
                    min={0}
                    max={100}
                    onCommit={(v) => updateLayout("hero", i, undefined, v)}
                  />
                </div>
              ))}
            </div>
          </div>

          <div className="pixel-panel p-4 space-y-2">
            <div className="flex items-center justify-between">
              <div className="pixel-label">BOSS EFFECTS (PERSISTENT PARTICLES, HP-GATED)</div>
              <button className="pixel-btn !py-0.5 !px-2 text-base" onClick={() => update({ effects: [...(boss.effects ?? []), newBossEffect()] })}>
                + ADD
              </button>
            </div>
            {(boss.effects ?? []).length === 0 && (
              <p className="text-lg text-[#9a9ab8]">
                NO EFFECTS YET. ADD EMBERS ON THE SHOULDERS BELOW 50% HP, A RAGE AURA AT LOW HP, SPARKLES AT FULL HP…
              </p>
            )}
            <div className="space-y-2 max-h-[430px] overflow-auto pr-1">
              {(boss.effects ?? []).map((ef, idx) => (
                <BossEffectEditor
                  key={ef.id}
                  ef={ef}
                  onChange={(next) =>
                    update({ effects: (boss.effects ?? []).map((x, i) => (i === idx ? next : x)) })
                  }
                  onDelete={() => update({ effects: (boss.effects ?? []).filter((_, i) => i !== idx) })}
                  spriteOptions={spriteAssets.map((s) => ({ value: s.id, label: s.name }))}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

const DEFAULT_HERO_XY: [number, number][] = [
  [16, 42],
  [24, 55],
  [17, 68],
  [27, 68],
];

function BossEffectEditor({
  ef,
  onChange,
  onDelete,
  spriteOptions,
}: {
  ef: BossEffectDef;
  onChange: (e: BossEffectDef) => void;
  onDelete: () => void;
  spriteOptions: { value: string; label: string }[];
}) {
  const ALL_SPRITES = [
    "spark",
    "fireball",
    "orb",
    "bullet",
    "darkOrb",
    "bone",
    ...spriteOptions.map((o) => o.value),
  ];
  return (
    <div className="pixel-inset p-2 space-y-2">
      <div className="flex gap-2 items-center">
        <TextField label="NAME" value={ef.name} onCommit={(v) => onChange({ ...ef, name: v })} />
        <button className="pixel-btn danger self-end !py-1" onClick={onDelete}>
          DEL
        </button>
      </div>
      <div className="grid grid-cols-3 gap-2">
        <SelectField
          label="SPRITE"
          value={ef.spriteId}
          options={ALL_SPRITES.map((s) => ({ value: s, label: s }))}
          onChange={(v) => onChange({ ...ef, spriteId: v })}
        />
        <NumField label="OFFSET X (-0.5..0.5)" value={ef.ax} min={-1} max={1} step={0.05} onCommit={(v) => onChange({ ...ef, ax: v })} />
        <NumField label="OFFSET Y" value={ef.ay} min={-1} max={1} step={0.05} onCommit={(v) => onChange({ ...ef, ay: v })} />
        <SelectField
          label="MODE"
          value={ef.mode}
          options={[
            { value: "continuous", label: "CONTINUOUS" },
            { value: "burst", label: "BURST" },
          ]}
          onChange={(v) => onChange({ ...ef, mode: v as "burst" | "continuous" })}
        />
        <NumField label="INTERVAL s" value={ef.interval} min={0.02} max={5} step={0.05} onCommit={(v) => onChange({ ...ef, interval: v })} />
        <NumField label="COUNT" value={ef.count} min={1} max={50} onCommit={(v) => onChange({ ...ef, count: v })} />
        <NumField label="HP ≥ %" value={ef.hpMin} min={0} max={100} onCommit={(v) => onChange({ ...ef, hpMin: v })} />
        <NumField label="HP ≤ %" value={ef.hpMax} min={0} max={100} onCommit={(v) => onChange({ ...ef, hpMax: v })} />
        <NumField label="LIFETIME s" value={ef.lifetime} min={0.1} max={10} step={0.1} onCommit={(v) => onChange({ ...ef, lifetime: v })} />
        <NumField label="SCALE" value={ef.scale} min={0.5} max={8} step={0.5} onCommit={(v) => onChange({ ...ef, scale: v })} />
        <NumField label="SPEED" value={ef.speed} min={0} max={400} onCommit={(v) => onChange({ ...ef, speed: v })} />
        <NumField label="DRIFT X" value={ef.driftX} min={-400} max={400} onCommit={(v) => onChange({ ...ef, driftX: v })} />
        <NumField label="DRIFT Y (−=UP)" value={ef.driftY} min={-400} max={400} onCommit={(v) => onChange({ ...ef, driftY: v })} />
        <NumField label="GRAVITY" value={ef.gravity} min={-400} max={400} onCommit={(v) => onChange({ ...ef, gravity: v })} />
        <NumField label="SPIN °/s" value={ef.rotSpeed} min={-720} max={720} onCommit={(v) => onChange({ ...ef, rotSpeed: v })} />
        <NumField label="SPREAD" value={ef.spread} min={0} max={100} onCommit={(v) => onChange({ ...ef, spread: v })} />
      </div>
      <div className="flex gap-4">
        <CheckField label="OUTWARD" checked={ef.outward} onChange={(v) => onChange({ ...ef, outward: v })} />
        <CheckField label="FADE" checked={ef.fade} onChange={(v) => onChange({ ...ef, fade: v })} />
      </div>
    </div>
  );
}

function ANIM_TRIGGERS(boss: BossData, abilityName: (id: string) => string): [string, string][] {
  const base: [string, string][] = [
    ["idle", "IDLE (LOOPS)"],
    ["damaged", "DAMAGED"],
    ["killed", "KILLED"],
    ["attack", "BASIC ATTACK"],
    ["defend", "DEFEND (LOOPS WHILE DEFENDING)"],
    ["victory", "VICTORY"],
  ];
  const abilityTriggers = boss.abilityIds.map(
    (id) => [`ability:${id}`, `ABILITY: ${abilityName(id).toUpperCase()}`] as [string, string]
  );
  return [...base, ...abilityTriggers];
}

/** draggable mini-map of the arena: ground line, boss and hero markers */
function StageVisualizer({
  boss,
  onMove,
}: {
  boss: BossData;
  onMove: (who: "boss" | "hero", i: number, x: number, y: number) => void;
}) {
  const dragRef = { current: null as null | { who: "boss" | "hero"; i: number } };
  const boxRef = { current: null as null | HTMLDivElement };
  const W = 320;
  const H = 180;
  const pos = (who: "boss" | "hero", i: number): { x: number; y: number } => {
    if (who === "boss") return boss.layout?.boss ?? { x: 76, y: 45 };
    const p = boss.layout?.heroes?.[i];
    return p ?? { x: DEFAULT_HERO_XY[i][0], y: DEFAULT_HERO_XY[i][1] };
  };

  function toPct(e: React.PointerEvent) {
    const rect = boxRef.current!.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100))),
      y: Math.max(0, Math.min(100, Math.round(((e.clientY - rect.top) / rect.height) * 100))),
    };
  }

  const marker = (who: "boss" | "hero", i: number, label: string, color: string) => {
    const p = pos(who, i);
    return (
      <div
        key={`${who}${i}`}
        className="absolute cursor-move text-center"
        style={{ left: `${p.x}%`, top: `${p.y}%`, transform: "translate(-50%,-50%)" }}
        onPointerDown={(e) => {
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          dragRef.current = { who, i };
        }}
        onPointerMove={(e) => {
          if (dragRef.current?.who === who && dragRef.current.i === i) {
            const q = toPct(e);
            onMove(who, i, q.x, q.y);
          }
        }}
        onPointerUp={() => (dragRef.current = null)}
      >
        <div className={`w-6 h-6 border-2 ${color} bg-black/60`} />
        <div className="text-xs text-white leading-3">{label}</div>
      </div>
    );
  };

  return (
    <div
      ref={(el) => void (boxRef.current = el)}
      className="relative border-2 border-[#3a3a55] bg-black touch-none"
      style={{ width: W, height: H }}
    >
      <div className="absolute left-0 right-0 bottom-0" style={{ height: "24%", background: "#141022", borderTop: "2px solid #2a2440" }} />
      {marker("boss", 0, "BOSS", "border-[#ffe14d]")}
      {[0, 1, 2, 3].map((i) => marker("hero", i, `H${i + 1}`, "border-[#46e6a0]"))}
      <div className="absolute top-1 left-2 text-xs text-[#7a7a96]">DRAG MARKERS TO POSITION THE BATTLE</div>
    </div>
  );
}

export default function BossEditPage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <BossEditor />
    </Suspense>
  );
}
