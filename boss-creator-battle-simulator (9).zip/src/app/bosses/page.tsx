"use client";

import { useRef } from "react";
import CreationsList from "@/components/CreationsList";
import { SpriteView, toast } from "@/components/ui";
import { newBoss, type Asset, type BossData } from "@/game/types";
import { store } from "@/game/store";
import { importBossBundle, type BossBundle } from "@/game/bundle";
import { useRouter } from "next/navigation";

export default function BossesPage() {
  const router = useRouter();
  return (
    <CreationsList
      headerExtra={<BossBundleImportButton />}
      kind="boss"
      title="BOSS CREATOR"
      subtitle="CREATE, EDIT AND TEST YOUR BOSSES"
      newLabel="NEW BOSS"
      makeNew={() => {
        const d = newBoss("My Boss");
        return { name: d.name, data: d };
      }}
      editHref={(id) => `/bosses/edit?id=${id}`}
      preview={(a) => {
        const b = a.data as BossData;
        return <SpriteView spriteId={b.spriteId} spriteData={store.spriteData(b.spriteId)} scale={3} maxHeight={56} />;
      }}
      extraActions={(a: Asset) => (
        <button
          className="pixel-btn gold !py-1"
          onClick={() => {
            router.push(`/battle?boss=${a.id}`);
          }}
        >
          TEST
        </button>
      )}
    />
  );
}

export function BossBundleImportButton() {
  const router = useRouter();
  const ref = useRef<HTMLInputElement>(null);
  return (
    <>
      <input
        ref={ref}
        type="file"
        accept="application/json"
        className="hidden"
        onChange={async (e) => {
          const f = e.target.files?.[0];
          e.target.value = "";
          if (!f) return;
          try {
            const json = JSON.parse(await f.text()) as BossBundle;
            const id = await importBossBundle(json);
            if (!id) throw new Error("not a boss bundle");
            toast("BOSS BUNDLE IMPORTED");
            router.push(`/bosses/edit?id=${id}`);
          } catch (err) {
            toast(`IMPORT FAILED: ${err}`);
          }
        }}
      />
      <button className="pixel-btn" onClick={() => ref.current?.click()}>
        IMPORT FULL BOSS
      </button>
    </>
  );
}
