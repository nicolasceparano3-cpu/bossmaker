"use client";
// ============================================================
// Hero customizer: restyle roster heroes (sprite, stats,
// animations, stance) and CREATE entirely new heroes. Custom
// heroes join the party picker in battle setup.
// ============================================================

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { HERO_ROSTER } from "@/game/heroes";
import { saveHeroCfg } from "@/game/heroCfg";
import { resolveHeroCfg } from "@/game/heroRegistry";
import { store } from "@/game/store";
import { BUILTIN_SPRITES } from "@/game/sprites";
import type { HeroCustom } from "@/game/types";
import { uid } from "@/game/types";
import { CheckField, NumField, SelectField, SpriteView, TextField, toast } from "@/components/ui";
import { sfx } from "@/game/sfx";

const TRIGGERS: [string, string][] = [
  ["idle", "IDLE (LOOPS)"],
  ["attack", "ATTACK"],
  ["ability", "ABILITY / MAGIC"],
  ["heal", "HEAL"],
  ["damaged", "DAMAGED"],
  ["killed", "DEATH IDLE (LOOPS WHILE DOWN)"],
  ["defend", "DEFEND IDLE (LOOPS WHILE DEFENDING)"],
];

function HeroCard({
  heroId,
  displayName,
  isCustom,
  onChanged,
}: {
  heroId: string;
  displayName: string;
  isCustom: boolean;
  onChanged: () => void;
}) {
  const [cfg, setCfg] = useState<HeroCustom>({});
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setCfg({ ...(resolveHeroCfg(heroId) ?? {}) });
    setLoaded(true);
  }, [heroId]);

  if (!loaded) return null;
  const set = (patch: Partial<HeroCustom>) => setCfg((c) => ({ ...c, ...patch }));
  const sprite = cfg.spriteId ?? "kris";

  async function save() {
    if (isCustom) {
      await store.update(heroId, cfg.name ?? displayName, cfg);
    } else {
      await saveHeroCfg(heroId, cfg, cfg.name ?? displayName);
    }
    toast(`${(cfg.name ?? displayName).toUpperCase()} SAVED`);
    sfx.confirm();
    onChanged();
  }

  return (
    <div className="pixel-panel p-4 space-y-3">
      <div className="flex items-center gap-3">
        <div className="pixel-inset p-2 checker">
          <SpriteView spriteId={sprite} spriteData={store.spriteData(sprite)} scale={4} maxHeight={64} />
        </div>
        <div className="flex-1 min-w-0">
          <TextField label={isCustom ? "HERO NAME" : "DISPLAY NAME"} value={cfg.name ?? displayName} onCommit={(v) => set({ name: v })} />
        </div>
        <button className="pixel-btn solid" onClick={save}>
          SAVE
        </button>
      </div>

      <div className="grid grid-cols-2 gap-2">
        <SelectField
          label="SPRITE"
          value={sprite}
          options={[
            ...Object.keys(BUILTIN_SPRITES).map((s) => ({ value: s, label: s })),
            ...store.byKind("sprite").map((s) => ({ value: s.id, label: `★ ${s.name}` })),
          ]}
          onChange={(v) => set({ spriteId: v })}
        />
        <div className="flex items-end pb-1">
          <CheckField label="HOVER (GLIDE)" checked={cfg.hover ?? true} onChange={(v) => set({ hover: v })} />
        </div>
        <NumField label="MAX HP" value={cfg.maxHp ?? 120} min={1} max={9999} onCommit={(v) => set({ maxHp: v })} />
        <NumField label="ATTACK" value={cfg.attack ?? 20} min={0} max={999} onCommit={(v) => set({ attack: v })} />
        <NumField label="DEFENSE" value={cfg.defense ?? 6} min={0} max={999} onCommit={(v) => set({ defense: v })} />
        <NumField label="MAGIC" value={cfg.magic ?? 12} min={0} max={999} onCommit={(v) => set({ magic: v })} />
      </div>

      <div className="grid grid-cols-2 gap-2">
        {TRIGGERS.map(([key, label]) => (
          <SelectField
            key={key}
            label={label}
            value={cfg.animations?.[key] ?? ""}
            options={[
              { value: "", label: "— NONE —" },
              ...store.byKind("animation").map((a) => ({ value: a.id, label: a.name })),
            ]}
            onChange={(v) => {
              const anims = { ...(cfg.animations ?? {}) };
              if (v) anims[key] = v;
              else delete anims[key];
              set({ animations: anims });
            }}
          />
        ))}
      </div>
    </div>
  );
}

export default function HeroesPage() {
  const router = useRouter();
  const [, force] = useState(0);

  useEffect(() => {
    store.ensureLoaded().then(() => force((x) => x + 1));
  }, []);

  const customHeroes = store.byKind<HeroCustom>("hero");

  async function createHero() {
    const id = uid("herocust");
    const data: HeroCustom = {
      name: "New Hero",
      spriteId: "kris",
      hover: true,
      maxHp: 140,
      attack: 22,
      defense: 6,
      magic: 14,
    };
    await store.create("hero", data.name!, data, id);
    toast("NEW HERO CREATED");
    sfx.confirm();
    force((x) => x + 1);
  }

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/")}>
            ◀ MENU
          </button>
          <div className="flex-1">
            <h1 className="font-display text-lg text-[#ffe14d]">HERO CUSTOMIZER</h1>
            <p className="text-xl text-[#9a9ab8]">EDIT THE AI PARTY — STATS, SPRITES, ANIMATIONS — OR FORGE NEW HEROES</p>
          </div>
          <button className="pixel-btn solid" onClick={createHero}>
            + NEW HERO
          </button>
        </header>

        <div className="pixel-label mb-2">CREATED HEROES (JOIN THE PARTY PICKER)</div>
        {customHeroes.length === 0 ? (
          <div className="pixel-panel p-3 mb-4 text-lg text-[#9a9ab8]">NONE YET — CUSTOM HEROES CAN BE ADDED TO THE PARTY IN BATTLE SETUP.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {customHeroes.map((a) => (
              <div key={a.id} className="relative">
                <HeroCard heroId={a.id} displayName={a.data.name ?? a.name} isCustom onChanged={() => force((x) => x + 1)} />
                <button
                  className="pixel-btn danger !py-0.5 absolute top-2 right-2"
                  onClick={async () => {
                    if (!confirm(`Delete hero "${a.data.name ?? a.name}"?`)) return;
                    await store.remove(a.id);
                    force((x) => x + 1);
                  }}
                >
                  DEL
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="pixel-label mb-2">FUN GANG ROSTER (OVERRIDES)</div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {HERO_ROSTER.map((h) => (
            <HeroCard key={h.id} heroId={h.id} displayName={h.name} isCustom={false} onChanged={() => force((x) => x + 1)} />
          ))}
        </div>
      </div>
    </main>
  );
}
