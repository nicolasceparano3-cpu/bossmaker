import type { Metadata } from "next";
import type { ReactNode } from "react";
import "@fontsource/press-start-2p";
import "@fontsource/vt323";
import "./globals.css";

export const metadata: Metadata = {
  title: "BOSS MAKER — create your boss, become the battle",
  description:
    "A 2D bullet-hell boss-fight creation sandbox. Build your boss, design attacks, and battle an AI hero party.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-[#0b0b12] text-[#f2f2f5]">{children}</body>
    </html>
  );
}
