"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { store } from "@/game/store";
import { SpriteView } from "@/components/ui";
import { sfx } from "@/game/sfx";

const MENU = [
  { label: "PLAY", href: "/battle", desc: "FIGHT THE HEROES WITH YOUR BOSS" },
  { label: "BOSS CREATOR", href: "/bosses", desc: "CREATE & EDIT YOUR BOSSES" },
  { label: "ATTACK CREATOR", href: "/attacks", desc: "DESIGN BULLET-HELL PATTERNS" },
  { label: "ABILITY CREATOR", href: "/abilities", desc: "FORGE ABILITIES FOR YOUR BOSS" },
  { label: "SPRITE EDITOR", href: "/sprites", desc: "DRAW PIXEL SPRITES" },
  { label: "SOUND LIBRARY", href: "/sounds", desc: "UPLOAD SFX & BOSS THEMES" },
  { label: "ANIMATOR", href: "/animations", desc: "ANIMATIONS & PARTICLES" },
  { label: "HERO CUSTOMIZER", href: "/heroes", desc: "RESTYLE THE AI PARTY" },
];

export default function Home() {
  const router = useRouter();
  const [sel, setSel] = useState(0);
  const [, force] = useState(0);

  useEffect(() => {
    store.ensureLoaded().then(() => force((x) => x + 1));
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowDown") {
        setSel((s) => (s + 1) % MENU.length);
        sfx.move();
      } else if (e.key === "ArrowUp") {
        setSel((s) => (s + MENU.length - 1) % MENU.length);
        sfx.move();
      } else if (e.key === "Enter" || e.key === "z" || e.key === "Z") {
        sfx.confirm();
        router.push(MENU[sel].href);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sel, router]);

  const bosses = store.byKind("boss").length;
  const attacks = store.byKind("attack").length;
  const abilities = store.byKind("ability").length;
  const sprites = store.byKind("sprite").length;
  const localMode = store.usingLocal;

  return (
    <main className="min-h-screen flex flex-col items-center justify-center px-4 py-10 checker">
      <div className="text-center mb-8 select-none">
        <div className="text-[#9a9ab8] text-xl tracking-[0.4em] mb-3">* A BOSS-FIGHT CREATION SANDBOX *</div>
        <h1 className="font-display text-4xl md:text-6xl text-white drop-shadow-[6px_6px_0_#7b4fb0]">
          BOSS<span className="text-[#ffe14d]">MAKER</span>
        </h1>
        <p className="mt-4 text-2xl text-[#c9c9d9]">
          CREATE YOUR BOSS. DESIGN ITS ATTACKS. <span className="text-[#ff2040]">YOU ARE THE BOSS.</span>
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8 items-center md:items-stretch w-full max-w-4xl">
        <div className="pixel-panel p-5 flex-1 w-full">
          <div className="pixel-label mb-3">MAIN MENU</div>
          <ul className="space-y-1">
            {MENU.map((m, i) => (
              <li key={m.label}>
                <button
                  onMouseEnter={() => setSel(i)}
                  onClick={() => {
                    sfx.confirm();
                    router.push(m.href);
                  }}
                  className={`w-full text-left text-2xl py-1.5 px-2 cursor-pointer ${
                    sel === i ? "menu-cursor text-[#ffe14d]" : "text-white"
                  }`}
                >
                  {m.label}
                  <span className="hidden md:inline text-[#7a7a96] text-lg ml-4">{sel === i ? m.desc : ""}</span>
                </button>
              </li>
            ))}
          </ul>
          <div className="pixel-hr" />
          <div className="text-lg text-[#9a9ab8]">
            CREATIONS: <span className="text-white">{bosses}</span> BOSSES · <span className="text-white">{attacks}</span>{" "}
            ATTACKS · <span className="text-white">{abilities}</span> ABILITIES · <span className="text-white">{sprites}</span>{" "}
            SPRITES
          </div>
        </div>

        <div className="pixel-panel p-5 flex flex-col items-center justify-center w-full md:w-64">
          <SpriteView spriteId="boss_grim" scale={7} bob />
          <div className="mt-3 text-center">
            <div className="font-display text-[10px] text-[#ffe14d]">TEST BOSS</div>
            <div className="text-lg text-[#9a9ab8] mt-1">AWAITS YOUR COMMAND</div>
          </div>
          <div className="mt-4 flex gap-3 anim-bob-slow">
            <SpriteView spriteId="soul" scale={2} />
          </div>
        </div>
      </div>

      <div className="mt-8 text-[#6a6a86] text-lg">
        KEYBOARD: ARROWS + ENTER ·{" "}
        {localMode ? "STORAGE: THIS BROWSER (NO DATABASE DETECTED)" : "DATA SAVED TO YOUR WORLD AUTOMATICALLY"}
      </div>
    </main>
  );
}
