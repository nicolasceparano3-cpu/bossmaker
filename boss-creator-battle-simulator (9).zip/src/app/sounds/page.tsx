"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { store } from "@/game/store";
import type { SoundData } from "@/game/types";
import { SFX_LIBRARY, playAudioUrl, playSfxPreset, sfx } from "@/game/sfx";
import { toast } from "@/components/ui";

export default function SoundsPage() {
  const router = useRouter();
  const [, force] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [progress, setProgress] = useState<number | null>(null); // 0..1 while loading

  useEffect(() => {
    store.ensureLoaded().then(() => force((x) => x + 1));
    return () => audioRef.current?.pause();
  }, []);

  const sounds = store.byKind<SoundData>("sound");

  function stop() {
    audioRef.current?.pause();
    audioRef.current = null;
    setPlayingId(null);
  }

  function previewPreset(id: string) {
    stop();
    playSfxPreset(id);
    setPlayingId(id);
    setTimeout(() => setPlayingId((p) => (p === id ? null : p)), 700);
  }

  function previewAsset(id: string, url: string) {
    stop();
    const a = playAudioUrl(url);
    if (a) {
      audioRef.current = a;
      setPlayingId(id);
      a.onended = () => setPlayingId((p) => (p === id ? null : p));
    }
  }

  function upload(file: File) {
    const MAX = 10 * 1024 * 1024;
    if (file.size > MAX) {
      toast("MAX 10MB PER SOUND");
      return;
    }
    setProgress(0);
    const reader = new FileReader();
    reader.onprogress = (e) => {
      if (e.lengthComputable) setProgress(e.loaded / e.total);
    };
    reader.onload = async () => {
      // data-url encoding is done; saving may still take a moment for big files
      setProgress(1);
      try {
        const name = file.name.replace(/\.[^.]+$/, "").toUpperCase();
        await store.create<SoundData>("sound", name, { name, dataUrl: String(reader.result) });
        toast("SOUND ADDED TO LIBRARY");
        sfx.confirm();
      } catch {
        toast("SAVE FAILED — FILE TOO LARGE FOR STORAGE?");
      } finally {
        setProgress(null);
        force((x) => x + 1);
      }
    };
    reader.onerror = () => {
      setProgress(null);
      toast("COULD NOT READ THAT FILE");
    };
    reader.readAsDataURL(file);
  }

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-3xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/")}>
            ◀ MENU
          </button>
          <div className="flex-1">
            <h1 className="font-display text-lg text-[#ffe14d]">SOUND LIBRARY</h1>
            <p className="text-xl text-[#9a9ab8]">SYNTH PRESETS + YOUR UPLOADED AUDIO — USABLE AS SPAWN/HIT/DESPAWN SFX AND BOSS THEMES</p>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) upload(f);
              e.target.value = "";
            }}
          />
          <button className="pixel-btn solid" onClick={() => fileRef.current?.click()} disabled={progress !== null}>
            + UPLOAD AUDIO
          </button>
        </header>

        {progress !== null && (
          <div className="pixel-panel p-3 mb-4">
            <div className="flex justify-between text-lg mb-1">
              <span className="text-[#46e6a0]">LOADING SOUND…</span>
              <span className="text-white">{Math.round(progress * 100)}%</span>
            </div>
            <div className="w-full h-4 border-2 border-white bg-black">
              <div className="h-full bg-[#46e6a0]" style={{ width: `${Math.round(progress * 100)}%` }} />
            </div>
            <div className="text-base text-[#9a9ab8] mt-1">BIG FILES (4–8MB) CAN TAKE A FEW SECONDS TO ENCODE.</div>
          </div>
        )}

        <div className="pixel-panel p-4 mb-4">
          <div className="pixel-label mb-2">BUILT-IN PRESETS (SYNTHESIZED)</div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {SFX_LIBRARY.map((s) => (
              <button
                key={s.id}
                className={`pixel-btn !py-1 ${playingId === s.id ? "solid" : ""}`}
                onClick={() => previewPreset(s.id)}
              >
                ▶ {s.name}
              </button>
            ))}
          </div>
        </div>

        <div className="pixel-panel p-4">
          <div className="pixel-label mb-2">UPLOADED ({sounds.length})</div>
          {sounds.length === 0 ? (
            <div className="text-xl text-[#9a9ab8]">
              NO UPLOADED SOUNDS YET. SMALL LOOPING OGG/MP3 FILES WORK GREAT AS BOSS THEMES.
            </div>
          ) : (
            <div className="space-y-2">
              {sounds.map((a) => (
                <div key={a.id} className="pixel-inset px-3 py-2 flex items-center gap-3">
                  <span className="text-xl text-[#46e6a0]">♪</span>
                  <span className="flex-1 text-xl truncate">{a.name}</span>
                  <button
                    className="pixel-btn !py-1"
                    onClick={() => (playingId === a.id ? stop() : previewAsset(a.id, a.data.dataUrl))}
                  >
                    {playingId === a.id ? "■ STOP" : "▶ PLAY"}
                  </button>
                  <button
                    className="pixel-btn danger !py-1"
                    onClick={async () => {
                      if (!confirm(`Delete sound "${a.name}"?`)) return;
                      await store.remove(a.id);
                      force((x) => x + 1);
                    }}
                  >
                    DEL
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
