"use client";

import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import type { SpriteData } from "@/game/types";
import { store } from "@/game/store";
import { NumField, SpriteView, TextField, toast } from "@/components/ui";
import { sfx } from "@/game/sfx";

const DEFAULT_W = 16;
const DEFAULT_H = 16;
const MIN_DIM = 4;
const MAX_DIM = 100;

function cellFor(w: number, h: number) {
  return Math.max(4, Math.min(26, Math.floor(700 / Math.max(w, h))));
}
const DEFAULT_PALETTE: Record<string, string> = {
  a: "#ffffff",
  b: "#c9c9d9",
  c: "#8a8aa0",
  d: "#3a3a4a",
  e: "#0b0b12",
  f: "#ff2040",
  g: "#ff8c1a",
  h: "#ffe14d",
  i: "#46e6a0",
  j: "#46e6ff",
  k: "#7b4fb0",
  l: "#3d2d5c",
  m: "#f0d0a0",
  n: "#4caf50",
  o: "#2e7d32",
  p: "#1d2b53",
};
const PALETTE_KEYS = Object.keys(DEFAULT_PALETTE);

type Tool = "pencil" | "eraser" | "fill" | "pick";

function emptyGrid(w: number, h: number): string[] {
  return Array.from({ length: h }, () => ".".repeat(w));
}

function resizeGrid(grid: string[], w: number, h: number): string[] {
  const out: string[] = [];
  for (let y = 0; y < h; y++) {
    const src = grid[y] ?? "";
    let row = src.slice(0, w);
    row = row + ".".repeat(Math.max(0, w - row.length));
    out.push(row);
  }
  return out;
}

function SpriteEditor() {
  const router = useRouter();
  const params = useSearchParams();
  const id = params.get("id");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sprite, setSprite] = useState<SpriteData | null>(null);
  const [missing, setMissing] = useState(false);
  const [tool, setTool] = useState<Tool>("pencil");
  const [colorKey, setColorKey] = useState("a");
  const [palette, setPalette] = useState<Record<string, string>>({ ...DEFAULT_PALETTE });
  const [dirty, setDirty] = useState(false);
  const [resW, setResW] = useState(DEFAULT_W);
  const [resH, setResH] = useState(DEFAULT_H);
  const undoStack = useRef<string[][]>([]);
  const drawing = useRef(false);
  const strokeStart = useRef<string[] | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    store.ensureLoaded().then(() => {
      if (!id) return setMissing(true);
      const row = store.get(id);
      if (!row || row.kind !== "sprite") return setMissing(true);
      const d = JSON.parse(JSON.stringify(row.data)) as SpriteData;
      if (d.type !== "image" && (!d.grid || !d.grid.length)) {
        d.type = "pixels";
        d.grid = emptyGrid(DEFAULT_W, DEFAULT_H);
      }
      // palette lives ON the sprite so recoloring persists with SAVE
      const merged = { ...DEFAULT_PALETTE, ...(d.palette ?? {}) };
      d.palette = merged;
      setSprite(d);
      setPalette(merged);
      if (d.grid) {
        setResW(d.grid[0]?.length ?? DEFAULT_W);
        setResH(d.grid.length);
      }
    });
  }, [id]);

  const W = sprite?.grid?.[0]?.length ?? DEFAULT_W;
  const H = sprite?.grid?.length ?? DEFAULT_H;
  const cell = cellFor(W, H);

  // ---- trace background (reference image to draw over) ----
  const [traceUrl, setTraceUrl] = useState<string | null>(null);
  const [traceScale, setTraceScale] = useState(100);
  const [traceX, setTraceX] = useState(0);
  const [traceY, setTraceY] = useState(0);
  const [traceOpacity, setTraceOpacity] = useState(50);
  const traceImgRef = useRef<HTMLImageElement | null>(null);
  const traceFileRef = useRef<HTMLInputElement>(null);

  const redraw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas || !sprite || sprite.type !== "pixels" || !sprite.grid) return;
    const w = sprite.grid[0]?.length ?? DEFAULT_W;
    const h = sprite.grid.length;
    const c = cellFor(w, h);
    canvas.width = w * c;
    canvas.height = h * c;
    const ctx = canvas.getContext("2d")!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // trace image UNDER the pixels
    const ti = traceImgRef.current;
    const traceActive = !!(traceUrl && ti && ti.complete && ti.naturalWidth > 0);
    if (traceActive && ti) {
      const dw = canvas.width * (traceScale / 100);
      const dh = dw * (ti.naturalHeight / ti.naturalWidth);
      ctx.save();
      ctx.globalAlpha = Math.max(0, Math.min(1, traceOpacity / 100));
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(ti, traceX, traceY, dw, dh);
      ctx.restore();
    }
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const ch = sprite.grid[y]?.[x] ?? ".";
        // opaque checker normally; faint checker while tracing so the
        // reference image stays visible underneath
        ctx.globalAlpha = traceActive ? 0.22 : 1;
        ctx.fillStyle = (x + y) % 2 === 0 ? "#1a1a26" : "#16161f";
        ctx.fillRect(x * c, y * c, c, c);
        ctx.globalAlpha = 1;
        if (ch !== "." && palette[ch]) {
          ctx.fillStyle = palette[ch];
          ctx.fillRect(x * c, y * c, c, c);
        }
        ctx.strokeStyle = "rgba(255,255,255,0.06)";
        ctx.strokeRect(x * c + 0.5, y * c + 0.5, c, c);
      }
    }
  }, [sprite, palette, traceUrl, traceScale, traceX, traceY, traceOpacity]);

  useEffect(() => redraw(), [redraw]);

  function uploadTrace(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      const url = String(reader.result);
      const img = new Image();
      img.onload = () => {
        traceImgRef.current = img;
        setTraceUrl(url);
        redraw();
      };
      img.src = url;
    };
    reader.readAsDataURL(file);
  }

  function pushUndo() {
    if (sprite?.grid) {
      undoStack.current.push(JSON.parse(JSON.stringify(sprite.grid)));
      if (undoStack.current.length > 64) undoStack.current.shift();
    }
  }

  function setCell(x: number, y: number, value: string) {
    if (!sprite || !sprite.grid) return;
    if (x < 0 || y < 0 || x >= W || y >= H) return;
    const grid = sprite.grid.slice();
    const row = grid[y].split("");
    if (row[x] === value) return;
    row[x] = value;
    grid[y] = row.join("");
    setSprite({ ...sprite, grid });
    setDirty(true);
  }

  function floodFill(x: number, y: number, value: string) {
    if (!sprite?.grid) return;
    const target = sprite.grid[y]?.[x] ?? ".";
    if (target === value) return;
    const grid = sprite.grid.map((r) => r.split(""));
    const stack = [[x, y]];
    while (stack.length) {
      const [cx, cy] = stack.pop()!;
      if (cx < 0 || cy < 0 || cx >= W || cy >= H) continue;
      if (grid[cy][cx] !== target) continue;
      grid[cy][cx] = value;
      stack.push([cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]);
    }
    setSprite({ ...sprite, grid: grid.map((r) => r.join("")) });
    setDirty(true);
  }

  function cellFromEvent(e: React.PointerEvent): [number, number] | null {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect = canvas.getBoundingClientRect();
    const x = Math.floor(((e.clientX - rect.left) / rect.width) * W);
    const y = Math.floor(((e.clientY - rect.top) / rect.height) * H);
    if (x < 0 || y < 0 || x >= W || y >= H) return null;
    return [x, y];
  }

  function applyTool(x: number, y: number, isFirst: boolean) {
    if (!sprite?.grid) return;
    if (tool === "pencil") setCell(x, y, colorKey);
    else if (tool === "eraser") setCell(x, y, ".");
    else if (tool === "pick" && isFirst) {
      const ch = sprite.grid[y]?.[x] ?? ".";
      if (ch !== ".") setColorKey(ch);
      setTool("pencil");
    } else if (tool === "fill" && isFirst) floodFill(x, y, colorKey);
  }

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = (e.target as HTMLElement)?.tagName;
      const typing = t === "INPUT" || t === "TEXTAREA" || t === "SELECT";
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "z") {
        if (typing) return;
        e.preventDefault();
        const prev = undoStack.current.pop();
        if (prev && sprite) {
          setSprite({ ...sprite, grid: prev });
          setDirty(true);
        }
        return;
      }
      // number keys pick the active palette slot (1-9, 0 = 10)
      if (!typing && !e.ctrlKey && !e.metaKey && !e.altKey && /^[0-9]$/.test(e.key)) {
        const idx = e.key === "0" ? 9 : parseInt(e.key, 10) - 1;
        if (idx < PALETTE_KEYS.length) {
          setColorKey(PALETTE_KEYS[idx]);
          sfx.move();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sprite]);

  if (missing)
    return (
      <main className="min-h-screen checker flex items-center justify-center">
        <div className="pixel-panel p-8 text-2xl">
          SPRITE NOT FOUND.{" "}
          <button className="pixel-btn ml-2" onClick={() => router.push("/sprites")}>
            BACK
          </button>
        </div>
      </main>
    );
  if (!sprite) return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  async function save() {
    if (!id || !sprite) return;
    await store.update(id, sprite.name || "Untitled Sprite", sprite);
    setDirty(false);
    toast("SPRITE SAVED");
    sfx.confirm();
  }

  function uploadImage(file: File) {
    // keep FULL quality — the image is stored at original resolution and
    // only *display size* is normalized where it's used (battle/attacks)
    const reader = new FileReader();
    reader.onload = () => {
      setSprite({ name: sprite!.name, type: "image", dataUrl: String(reader.result) });
      setDirty(true);
      toast("UPLOADED AT FULL QUALITY");
    };
    reader.onerror = () => toast("COULD NOT READ THAT IMAGE");
    reader.readAsDataURL(file);
  }

  const isPixels = sprite.type !== "image";

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-5xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/sprites")}>
            ◀ SPRITES
          </button>
          <h1 className="font-display text-lg text-[#ffe14d] flex-1">SPRITE EDITOR</h1>
          <span className={`text-lg ${dirty ? "text-[#ff2040]" : "text-[#46e6a0]"}`}>{dirty ? "* UNSAVED" : "* SAVED"}</span>
          <button className="pixel-btn solid" onClick={save}>
            SAVE
          </button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-[auto_1fr] gap-4">
          <div className="pixel-panel p-4">
            <div className="pixel-label mb-2">
              {isPixels ? `CANVAS ${W}×${H}` : "UPLOADED IMAGE (TRANSPARENT PNG WORKS BEST)"}
            </div>
            {isPixels ? (
              <canvas
                ref={canvasRef}
                width={W * cell}
                height={H * cell}
                className="border-2 border-white cursor-crosshair touch-none max-w-full"
                onPointerDown={(e) => {
                  (e.target as HTMLElement).setPointerCapture(e.pointerId);
                  drawing.current = true;
                  strokeStart.current = sprite.grid ?? null;
                  const c = cellFromEvent(e);
                  if (c) applyTool(c[0], c[1], true);
                }}
                onPointerMove={(e) => {
                  if (!drawing.current) return;
                  const c = cellFromEvent(e);
                  if (c) applyTool(c[0], c[1], false);
                }}
                onPointerUp={() => {
                  drawing.current = false;
                  // one undo step per stroke
                  if (strokeStart.current && sprite.grid && sprite.grid !== strokeStart.current) {
                    undoStack.current.push(strokeStart.current);
                    if (undoStack.current.length > 64) undoStack.current.shift();
                  }
                  strokeStart.current = null;
                }}
                onPointerCancel={() => (drawing.current = false)}
              />
            ) : (
              <div className="pixel-inset p-6 flex items-center justify-center min-w-72 min-h-72">
                <SpriteView spriteId={id ?? ""} spriteData={sprite} scale={6} />
              </div>
            )}
            <div className="flex gap-2 mt-3 flex-wrap">
              <input
                ref={fileRef}
                type="file"
                accept="image/png,image/gif,image/webp"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) uploadImage(f);
                  e.target.value = "";
                }}
              />
              <button className="pixel-btn !py-1 flex-1" onClick={() => fileRef.current?.click()}>
                UPLOAD PNG
              </button>
              {isPixels ? (
                <>
                  <button
                    className="pixel-btn !py-1"
                    onClick={() => {
                      const prev = undoStack.current.pop();
                      if (prev) setSprite({ ...sprite, grid: prev });
                    }}
                  >
                    UNDO
                  </button>
                  <button
                    className="pixel-btn danger !py-1"
                    onClick={() => {
                      pushUndo();
                      setSprite({ ...sprite, grid: emptyGrid(W, H) });
                      setDirty(true);
                    }}
                  >
                    CLEAR
                  </button>
                </>
              ) : (
                <button
                  className="pixel-btn !py-1"
                  onClick={() =>
                    setSprite({ ...sprite, type: "pixels", grid: emptyGrid(DEFAULT_W, DEFAULT_H), palette })
                  }
                >
                  CONVERT TO PIXELS
                </button>
              )}
            </div>

            {isPixels && (
              <div className="mt-4">
                <div className="pixel-label mb-2">TRACE BACKGROUND (REFERENCE TO DRAW OVER)</div>
                <input
                  ref={traceFileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) uploadTrace(f);
                    e.target.value = "";
                  }}
                />
                <div className="flex gap-2 flex-wrap mb-2">
                  <button className="pixel-btn !py-1" onClick={() => traceFileRef.current?.click()}>
                    UPLOAD TRACE IMAGE
                  </button>
                  {traceUrl && (
                    <button
                      className="pixel-btn danger !py-1"
                      onClick={() => {
                        setTraceUrl(null);
                        traceImgRef.current = null;
                      }}
                    >
                      CLEAR
                    </button>
                  )}
                </div>
                {traceUrl && (
                  <div className="grid grid-cols-2 gap-2">
                    <label className="block">
                      <span className="pixel-label block mb-1">SCALE {traceScale}%</span>
                      <input
                        type="range"
                        min={5}
                        max={400}
                        step={1}
                        value={traceScale}
                        onChange={(e) => setTraceScale(parseInt(e.target.value, 10))}
                        className="w-full"
                      />
                    </label>
                    <label className="block">
                      <span className="pixel-label block mb-1">OPACITY {traceOpacity}%</span>
                      <input
                        type="range"
                        min={5}
                        max={100}
                        step={1}
                        value={traceOpacity}
                        onChange={(e) => setTraceOpacity(parseInt(e.target.value, 10))}
                        className="w-full"
                      />
                    </label>
                    <NumField label="OFFSET X" value={traceX} min={-2000} max={2000} onCommit={setTraceX} />
                    <NumField label="OFFSET Y" value={traceY} min={-2000} max={2000} onCommit={setTraceY} />
                  </div>
                )}
                <div className="pixel-hr" />
                <div className="pixel-label mb-2">CANVAS SIZE (CONTENT IS CROPPED / PADDED, MAX 100×100)</div>
                <div className="flex items-end gap-2 flex-wrap">
                  <NumField label="WIDTH" value={resW} min={MIN_DIM} max={MAX_DIM} onCommit={setResW} className="w-24" />
                  <NumField label="HEIGHT" value={resH} min={MIN_DIM} max={MAX_DIM} onCommit={setResH} className="w-24" />
                  <button
                    className="pixel-btn !py-1"
                    onClick={() => {
                      if (resW === W && resH === H) return;
                      pushUndo();
                      setSprite({ ...sprite, grid: resizeGrid(sprite.grid ?? [], resW, resH) });
                      setDirty(true);
                      sfx.confirm();
                    }}
                  >
                    RESIZE
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="pixel-panel p-4 space-y-3">
              <TextField label="NAME" value={sprite.name} onCommit={(v) => setSprite({ ...sprite, name: v })} />
              <TextField
                label="FOLDER (GROUP A BOSS + ITS ANIMATION SPRITES)"
                value={sprite.folder ?? ""}
                placeholder="e.g. test_boss"
                onCommit={(v) => setSprite({ ...sprite, folder: v || undefined })}
              />
              <div className="flex items-end gap-6 flex-wrap">
                <div>
                  <div className="pixel-label mb-2">PREVIEW ×4</div>
                  <div className="pixel-inset p-3 inline-block checker">
                    <SpriteView spriteId={id ?? ""} spriteData={sprite} scale={4} />
                  </div>
                </div>
                <div>
                  <div className="pixel-label mb-2">IN-BATTLE LOOK</div>
                  <div className="pixel-inset p-3 inline-block bg-black">
                    <SpriteView spriteId={id ?? ""} spriteData={sprite} scale={6} bob />
                  </div>
                </div>
              </div>
            </div>

            {isPixels && (
              <div className="pixel-panel p-4">
                <div className="pixel-label mb-2">TOOLS</div>
                <div className="flex gap-2 flex-wrap mb-3">
                  {(
                    [
                      ["pencil", "✏ PENCIL"],
                      ["eraser", "▭ ERASER"],
                      ["fill", "▨ FILL"],
                      ["pick", "◉ PICK"],
                    ] as [Tool, string][]
                  ).map(([t, label]) => (
                    <button key={t} className={`pixel-btn !py-1 ${tool === t ? "solid" : ""}`} onClick={() => setTool(t)}>
                      {label}
                    </button>
                  ))}
                </div>
                <div className="pixel-label mb-2">PALETTE — CLICK A SLOT TO RECOLOR IT</div>
                <div className="grid grid-cols-8 gap-2 max-w-80">
                  {PALETTE_KEYS.map((k) => (
                    <label
                      key={k}
                      className={`relative h-10 cursor-pointer border-2 ${colorKey === k ? "border-[#ffe14d]" : "border-[#3a3a55]"}`}
                      style={{ background: palette[k] }}
                    >
                      <input
                        type="color"
                        value={palette[k]}
                        className="absolute inset-0 opacity-0 cursor-pointer"
                        onChange={(e) => {
                          const next = { ...palette, [k]: e.target.value };
                          setPalette(next);
                          setSprite({ ...sprite, palette: next });
                          setDirty(true);
                        }}
                      />
                      <span className="absolute bottom-0 right-1 text-xs text-black/70 font-bold">
                        {(PALETTE_KEYS.indexOf(k) + 1) % 10}
                      </span>
                    </label>
                  ))}
                </div>
                <p className="text-lg text-[#9a9ab8] mt-3">
                  KEY <span className="text-[#ffe14d]">{colorKey}</span> SELECTED · PRESS <span className="text-white">1–9, 0</span> TO
                  SWITCH COLORS · CTRL+Z UNDO · PIXELS STAY CRISP IN BATTLE.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}

export default function SpriteEditPage() {
  return (
    <Suspense fallback={<main className="min-h-screen checker" />}>
      <SpriteEditor />
    </Suspense>
  );
}
