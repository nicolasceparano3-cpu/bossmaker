"use client";

import CreationsList from "@/components/CreationsList";
import { type SpriteData } from "@/game/types";
import { SpriteView } from "@/components/ui";
import { store } from "@/game/store";

export default function SpritesPage() {
  return (
    <CreationsList
      kind="sprite"
      title="SPRITE EDITOR"
      subtitle="DRAW PIXEL ART OR UPLOAD TRANSPARENT PNGS"
      newLabel="NEW SPRITE"
      makeNew={() => {
        const d: SpriteData = {
          name: "New Sprite",
          type: "pixels",
          grid: Array.from({ length: 16 }, () => ".".repeat(16)),
          palette: { a: "#ffffff", b: "#ff2040", c: "#ffe14d", d: "#46e6a0", e: "#7b4fb0", f: "#46e6ff" },
        };
        return { name: d.name, data: d };
      }}
      editHref={(id) => `/sprites/edit?id=${id}`}
      preview={(a) => {
        const s = a.data as SpriteData;
        return <SpriteView spriteId={a.id} spriteData={s} scale={3} maxHeight={56} />;
      }}
      folderOf={(a) => (a.data as SpriteData).folder}
      onFolder={async (a, folder) => {
        const data = { ...(a.data as SpriteData), folder };
        await store.update(a.id, a.name, data);
      }}
    />
  );
}
