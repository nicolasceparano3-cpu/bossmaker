"use client";
// ============================================================
// Attack editor: box + timeline + objects + keyframes + live
// AI-SOUL preview + headless TEST. Uses the same playback
// engine that runs in real battles.
// ============================================================

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type { AttackData, AttackObject, Easing, LayerId, ObjKind, SoulAIDifficulty } from "@/game/types";
import { LAYER_ORDER, SOUL_DIFFICULTIES, newAttackObject, uid } from "@/game/types";
import { AttackRuntime, evalKF, evalKeyframedState, simulateAttack, type TestResult } from "@/game/engine";
import { createSoulAI } from "@/game/soulAI";
import { renderScene } from "@/game/renderScene";
import { store } from "@/game/store";
import { playObjectSound } from "@/game/soundPlay";
import { SFX_LIBRARY } from "@/game/sfx";
import Timeline, { type SelectedKF } from "./editor/Timeline";
import { Modal, NumField, SelectField, TextField, toast } from "./ui";
import { sfx } from "@/game/sfx";

const CANVAS_W = 760;
const CANVAS_H = 430;
const OBJECT_SPRITES = ["bullet", "orb", "blade", "fireball", "bone", "spark", "knife", "darkOrb", "rect"];
const EASINGS: Easing[] = ["linear", "in", "out", "inout", "step"];

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

export default function AttackEditor({ assetId, initialTest }: { assetId: string; initialTest?: boolean }) {
  const router = useRouter();
  const [attack, setAttack] = useState<AttackData | null>(null);
  const [missing, setMissing] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const selectedObjId = selectedIds[0] ?? null;
  function setSelectedObjId(id: string | null) {
    setSelectedIds(id ? [id] : []);
  }
  const [selectedKF, setSelectedKF] = useState<SelectedKF | null>(null);
  const [time, setTime] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [loop, setLoop] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [showCollisions, setShowCollisions] = useState(true);
  const [handlesOn, setHandlesOn] = useState(true);
  const handlesRef = useRef(true);
  handlesRef.current = handlesOn;
  const [snap, setSnap] = useState(0);
  const [pxPerSec, setPxPerSec] = useState(80);
  const [difficultyId, setDifficultyId] = useState("normal");
  const [testPower, setTestPower] = useState(50);
  const [testOpen, setTestOpen] = useState(!!initialTest);
  const [testResult, setTestResult] = useState<TestResult[] | null>(null);
  const [patternOpen, setPatternOpen] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [, force] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rtRef = useRef<AttackRuntime | null>(null);
  const historyRef = useRef<{ past: string[]; future: string[] }>({ past: [], future: [] });
  const transientRef = useRef<string | null>(null);
  const dragRef = useRef<{
    objId: string;
    moved: boolean;
    mode: "move" | "rot" | "scale";
    ids: string[];
    origins: Record<string, { x: number; y: number }>;
  } | null>(null);
  const attackRef = useRef<AttackData | null>(null);
  attackRef.current = attack;
  const playingRef = useRef(false);
  const speedRef = useRef(1);
  const loopRef = useRef(true);
  playingRef.current = playing;
  speedRef.current = speed;
  loopRef.current = loop;

  const difficulty = useMemo(
    () => SOUL_DIFFICULTIES.find((d) => d.id === difficultyId) ?? SOUL_DIFFICULTIES[1],
    [difficultyId]
  );

  // ---------- load ----------
  useEffect(() => {
    store.ensureLoaded().then(() => {
      const row = store.get(assetId);
      if (!row || row.kind !== "attack") return setMissing(true);
      setAttack(clone(row.data) as AttackData);
      force((x) => x + 1);
    });
  }, [assetId]);

  // ---------- runtime ----------
  const rebuildRuntime = useCallback(
    (seekTo: number) => {
      if (!attack) return;
      const rt = new AttackRuntime(clone(attack), {
        attackPower: testPower,
        onObjEvent: (type, objId) => {
          const o = attack.objects.find((x) => x.id === objId);
          if (!o) return;
          if (type === "spawn") playObjectSound(o.spawnSound, o.kind === "warning" ? "warn" : "shoot");
          else if (type === "despawn") playObjectSound(o.despawnSound, "fade");
          else playObjectSound(o.hitSound, "soulhit");
        },
      });
      rt.aiUpdate = createSoulAI(difficulty);
      rt.seek(seekTo);
      rtRef.current = rt;
    },
    [attack, testPower, difficulty]
  );

  useEffect(() => {
    rebuildTime(timeRefSafe());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attack, testPower, difficulty]);

  const timeRef = useRef(0);
  timeRef.current = time;
  function timeRefSafe() {
    return timeRef.current;
  }
  function rebuildTime(t: number) {
    rebuildRuntime(t);
  }

  // ---------- draw loop ----------
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const rt = rtRef.current;
      if (rt && playingRef.current) {
        rt.update(dt * speedRef.current);
        if (rt.finished) {
          if (loopRef.current) {
            rebuildTime(0);
          } else {
            setPlaying(false);
          }
        } else {
          setTime(rt.time);
        }
      }
      draw();
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attack, showCollisions, selectedObjId, selectedIds.length]);

  function draw() {
    const canvas = canvasRef.current;
    const rt = rtRef.current;
    if (!canvas || !rt || !attack) return;
    const ctx = canvas.getContext("2d")!;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = "#050508";
    ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
    const boxNow = rt.boxAt(rt.time);
    const scale = Math.min((CANVAS_W - 30) / boxNow.width, (CANVAS_H - 30) / boxNow.height);
    const ox = (CANVAS_W - boxNow.width * scale) / 2;
    const oy = (CANVAS_H - boxNow.height * scale) / 2;
    ctx.save();
    ctx.translate(ox, oy);
    ctx.scale(scale, scale);
    renderScene(ctx, rt, {
      time: rt.time,
      spriteLookup: (id) => store.spriteData(id),
      showCollisions,
      selectedId: selectedObjId,
      showSoul: true,
      showSoulHp: playing || rt.damageDealt > 0,
    });
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 3 / scale;
    ctx.strokeRect(0, 0, boxNow.width, boxNow.height);
    // rotation ring + scale handle for the selected object (single selection)
    if (handlesRef.current && selectedIds.length === 1 && selectedObjId) {
      const o = attack.objects.find((ob) => ob.id === selectedObjId);
      if (o) {
        const st = rt.stateOf(o, rt.time);
        const g = gripsFor(st);
        ctx.save();
        ctx.globalAlpha = 0.9;
        ctx.strokeStyle = "#8a8aa0";
        ctx.setLineDash([4, 4]);
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(st.x, st.y, HANDLE_R, 0, Math.PI * 2);
        ctx.stroke();
        ctx.setLineDash([]);
        // rotation grip (yellow)
        ctx.strokeStyle = "#ffe14d";
        ctx.beginPath();
        ctx.moveTo(st.x, st.y);
        ctx.lineTo(g.rot.x, g.rot.y);
        ctx.stroke();
        ctx.fillStyle = "#ffe14d";
        ctx.beginPath();
        ctx.arc(g.rot.x, g.rot.y, 4, 0, Math.PI * 2);
        ctx.fill();
        // scale grip (green)
        ctx.strokeStyle = "#46e6a0";
        ctx.beginPath();
        ctx.moveTo(st.x, st.y);
        ctx.lineTo(g.scale.x, g.scale.y);
        ctx.stroke();
        ctx.fillStyle = "#46e6a0";
        ctx.fillRect(g.scale.x - 3, g.scale.y - 3, 6, 6);
        ctx.restore();
      }
    }
    ctx.restore();
  }

  // ---------- history ----------
  function commitSnapshot(prevJson: string) {
    const h = historyRef.current;
    h.past.push(prevJson);
    if (h.past.length > 100) h.past.shift();
    h.future = [];
    setDirty(true);
  }

  const mutate = useCallback((fn: (draft: AttackData) => void) => {
    const cur = attackRef.current;
    if (!cur) return;
    const prevJson = JSON.stringify(cur);
    const draft = clone(cur);
    fn(draft);
    commitSnapshot(prevJson);
    setAttack(draft);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function silentMutate(fn: (draft: AttackData) => void) {
    const cur = attackRef.current;
    if (!cur) return;
    const draft = clone(cur);
    fn(draft);
    setAttack(draft);
  }

  function beginTransient() {
    if (attack) transientRef.current = JSON.stringify(attack);
  }
  function endTransient() {
    if (transientRef.current) {
      historyRef.current.past.push(transientRef.current);
      if (historyRef.current.past.length > 100) historyRef.current.past.shift();
      historyRef.current.future = [];
      transientRef.current = null;
      setDirty(true);
    }
  }

  function undo() {
    const h = historyRef.current;
    const prev = h.past.pop();
    if (!prev || !attack) return;
    h.future.push(JSON.stringify(attack));
    setAttack(JSON.parse(prev));
    setSelectedKF(null);
    sfx.cancel();
  }
  function redo() {
    const h = historyRef.current;
    const next = h.future.pop();
    if (!next || !attack) return;
    h.past.push(JSON.stringify(attack));
    setAttack(JSON.parse(next));
    setSelectedKF(null);
  }

  // ---------- object operations ----------
  function addObject(kind: ObjKind) {
    mutate((d) => {
      const o = newAttackObject(kind, Math.round(time * 20) / 20);
      o.keyframes.pos[0].x = d.box.width / 2;
      o.keyframes.pos[0].y = d.box.height / 4;
      d.objects.push(o);
      setSelectedObjId(o.id);
    });
    sfx.confirm();
  }

  function selectedObj(): AttackObject | null {
    return attack?.objects.find((o) => o.id === selectedObjId) ?? null;
  }

  function duplicateSelected() {
    if (!selectedIds.length) return;
    mutate((d) => {
      const copies: string[] = [];
      for (const sid of selectedIds) {
        const src = d.objects.find((x) => x.id === sid);
        if (!src) continue;
        const copy: AttackObject = clone(src);
        copy.id = uid("obj");
        copy.name = `${src.name} copy`;
        copy.keyframes.pos = copy.keyframes.pos.map((k) => ({ ...k, x: k.x + 24, y: k.y + 16 }));
        d.objects.push(copy);
        copies.push(copy.id);
      }
      setSelectedIds(copies);
    });
    sfx.confirm();
  }

  function deleteSelected() {
    if (selectedKF) {
      deleteKF(selectedKF);
      return;
    }
    if (!selectedIds.length) return;
    mutate((d) => {
      d.objects = d.objects.filter((o) => !selectedIds.includes(o.id));
    });
    setSelectedIds([]);
    sfx.cancel();
  }

  function deleteKF(kf: SelectedKF) {
    mutate((d) => {
      const o = d.objects.find((x) => x.id === kf.objId);
      if (!o) return;
      const arr = o.keyframes[kf.channel] as { t: number }[];
      if (kf.index >= 0 && kf.index < arr.length) arr.splice(kf.index, 1);
    });
    setSelectedKF(null);
  }

  function addKFAtPlayhead(channel: "pos" | "rot" | "scale" | "opacity") {
    if (!selectedObjId) return;
    mutate((d) => {
      const o = d.objects.find((x) => x.id === selectedObjId);
      if (!o) return;
      if (channel === "pos") {
        const st = evalKeyframedState(d, o, time);
        o.keyframes.pos.push({ t: time, x: st.x, y: st.y, e: "linear" });
        o.keyframes.pos.sort((a, b) => a.t - b.t);
      } else {
        const def = channel === "scale" || channel === "opacity" ? 1 : 0;
        const v = evalKF(o.keyframes[channel], time, def);
        o.keyframes[channel].push({ t: time, v, e: "linear" });
        o.keyframes[channel].sort((a, b) => a.t - b.t);
      }
    });
    sfx.select();
  }

  // ---------- canvas dragging ----------
  function canvasTransform() {
    if (!attack) return { scale: 1, ox: 0, oy: 0 };
    const scale = Math.min((CANVAS_W - 30) / attack.box.width, (CANVAS_H - 30) / attack.box.height);
    return { scale, ox: (CANVAS_W - attack.box.width * scale) / 2, oy: (CANVAS_H - attack.box.height * scale) / 2 };
  }

  function toBox(e: React.PointerEvent): { x: number; y: number } {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    const { scale, ox, oy } = canvasTransform();
    const sx = ((e.clientX - rect.left) / rect.width) * CANVAS_W;
    const sy = ((e.clientY - rect.top) / rect.height) * CANVAS_H;
    return { x: (sx - ox) / scale, y: (sy - oy) / scale };
  }

  function snapVal(v: number) {
    return snap > 0 ? Math.round(v / snap) * snap : Math.round(v * 2) / 2;
  }

  function hitTest(x: number, y: number): AttackObject | null {
    const rt = rtRef.current;
    if (!rt || !attack) return null;
    const states = rt.allStates(time);
    for (let i = states.length - 1; i >= 0; i--) {
      const { obj, st } = states[i];
      const r = Math.max(14, 16 * st.scale);
      if (Math.hypot(st.x - x, st.y - y) <= r) return obj;
    }
    return null;
  }

  function applyPosition(d: AttackData, objId: string, x: number, y: number) {
    const o = d.objects.find((ob) => ob.id === objId);
    if (!o) return;
    if (o.movement === "keyframed") {
      const near = o.keyframes.pos.find((k) => Math.abs(k.t - time) < 0.03);
      if (near) {
        near.x = x;
        near.y = y;
      } else {
        o.keyframes.pos.push({ t: time, x, y, e: "linear" });
        o.keyframes.pos.sort((a, b) => a.t - b.t);
      }
    } else {
      if (!o.keyframes.pos.length) o.keyframes.pos.push({ t: o.start, x, y, e: "linear" });
      o.keyframes.pos[0].x = x;
      o.keyframes.pos[0].y = y;
    }
  }

  // ---- rotation ring / scale handle geometry ----
  const HANDLE_R = 26;
  function gripsFor(st: { x: number; y: number; rot: number; scale: number }) {
    const ra = (st.rot * Math.PI) / 180;
    return {
      rot: { x: st.x + Math.cos(ra) * HANDLE_R, y: st.y + Math.sin(ra) * HANDLE_R },
      scale: { x: st.x + HANDLE_R * st.scale * 0.8, y: st.y + HANDLE_R * st.scale * 0.8 },
    };
  }

  function applyScalar(d: AttackData, objId: string, channel: "rot" | "scale", v: number) {
    const o = d.objects.find((ob) => ob.id === objId);
    if (!o) return;
    const kfs = o.keyframes[channel];
    const near = kfs.find((k) => Math.abs(k.t - time) < 0.03);
    if (near) {
      near.v = v;
    } else {
      kfs.push({ t: time, v, e: "linear" });
      kfs.sort((a, b) => a.t - b.t);
    }
  }

  function onCanvasPointerDown(e: React.PointerEvent) {
    if (!attack) return;
    const p = toBox(e);
    // handles first (rotation ring grip / scale grip) — single selection only
    if (handlesOn && selectedIds.length === 1 && selectedObjId) {
      const selObj = attack.objects.find((o) => o.id === selectedObjId);
      const rt = rtRef.current;
      if (selObj && rt) {
        const st = rt.stateOf(selObj, time);
        const g = gripsFor(st);
        const dRot = Math.hypot(p.x - g.rot.x, p.y - g.rot.y);
        const dScale = Math.hypot(p.x - g.scale.x, p.y - g.scale.y);
        if (dRot < 8 || dScale < 8) {
          dragRef.current = { objId: selObj.id, moved: false, mode: dRot < 8 ? "rot" : "scale", ids: [selObj.id], origins: {} };
          beginTransient();
          (e.target as HTMLElement).setPointerCapture(e.pointerId);
          return;
        }
      }
    }
    const hit = hitTest(p.x, p.y);
    if (hit) {
      if (e.shiftKey) {
        // shift-click toggles multi selection
        setSelectedIds((cur) => (cur.includes(hit.id) ? cur.filter((x) => x !== hit.id) : [...cur, hit.id]));
        sfx.move();
        return;
      }
      const ids = selectedIds.includes(hit.id) ? selectedIds : [hit.id];
      if (!selectedIds.includes(hit.id)) setSelectedObjId(hit.id);
      setSelectedKF(null);
      const rt = rtRef.current;
      const origins: Record<string, { x: number; y: number }> = {};
      if (rt)
        for (const id of ids) {
          const o = attack.objects.find((x) => x.id === id);
          if (o) origins[id] = rt.stateOf(o, time);
        }
      dragRef.current = { objId: hit.id, moved: false, mode: "move", ids, origins };
      beginTransient();
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
      sfx.select();
    } else if (!e.shiftKey) {
      setSelectedKF(null);
      setSelectedIds([]);
    }
  }

  function onCanvasPointerMove(e: React.PointerEvent) {
    if (!dragRef.current || !attack) return;
    const drag = dragRef.current;
    const p = toBox(e);
    drag.moved = true;
    if (drag.mode === "rot" || drag.mode === "scale") {
      const rt = rtRef.current;
      const o = attack.objects.find((ob) => ob.id === drag.objId);
      if (!rt || !o) return;
      const st = rt.stateOf(o, time);
      if (drag.mode === "rot") {
        let deg = (Math.atan2(p.y - st.y, p.x - st.x) * 180) / Math.PI;
        deg = Math.round(deg);
        silentMutate((d) => applyScalar(d, drag.objId, "rot", deg));
      } else {
        const s = Math.max(0.1, Math.min(8, Math.round((Math.hypot(p.x - st.x, p.y - st.y) / HANDLE_R) * 20) / 20));
        silentMutate((d) => applyScalar(d, drag.objId, "scale", s));
      }
      return;
    }
    const base = drag.origins[drag.objId] ?? p;
    const dx = p.x - base.x;
    const dy = p.y - base.y;
    silentMutate((d) => {
      for (const id of drag.ids) {
        const o0 = drag.origins[id];
        if (!o0) continue;
        const nx = Math.max(-40, Math.min(d.box.width + 40, snapVal(o0.x + dx)));
        const ny = Math.max(-40, Math.min(d.box.height + 40, snapVal(o0.y + dy)));
        applyPosition(d, id, nx, ny);
      }
    });
  }

  function onCanvasPointerUp() {
    if (dragRef.current) {
      if (dragRef.current.moved) endTransient();
      else transientRef.current = null;
      dragRef.current = null;
      rebuildTime(time);
    }
  }

  function nudge(dx: number, dy: number) {
    if (!selectedIds.length) return;
    silentMutate((d) => {
      for (const sid of selectedIds) {
        const o = d.objects.find((ob) => ob.id === sid);
        if (!o) continue;
        const st = evalKeyframedState(d, o, time);
        applyPosition(d, sid, snapVal(st.x + dx), snapVal(st.y + dy));
      }
    });
  }

  // ---------- keyboard ----------
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "z" && !e.shiftKey) {
        e.preventDefault();
        undo();
      } else if ((mod && e.key.toLowerCase() === "y") || (mod && e.shiftKey && e.key.toLowerCase() === "z")) {
        e.preventDefault();
        redo();
      } else if (mod && e.key.toLowerCase() === "d") {
        e.preventDefault();
        duplicateSelected();
      } else if (e.key === " ") {
        e.preventDefault();
        togglePlay();
      } else if (e.key === "Delete" || e.key === "Backspace") {
        deleteSelected();
      } else if (e.key.startsWith("Arrow")) {
        e.preventDefault();
        const step = e.shiftKey ? 10 : 1;
        if (!transientRef.current) beginTransient();
        if (e.key === "ArrowLeft") nudge(-step, 0);
        if (e.key === "ArrowRight") nudge(step, 0);
        if (e.key === "ArrowUp") nudge(0, -step);
        if (e.key === "ArrowDown") nudge(0, step);
        clearTimeout(nudgeEndTimer.current);
        nudgeEndTimer.current = window.setTimeout(() => endTransient(), 400);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attack, selectedObjId, selectedKF, time, snap]);

  const nudgeEndTimer = useRef<number>(0);

  // ---------- transport ----------
  function togglePlay() {
    if (playing) {
      setPlaying(false);
    } else {
      const rt = rtRef.current;
      if (rt && rt.finished) rebuildTime(0);
      setPlaying(true);
      sfx.confirm();
    }
  }

  function stop() {
    setPlaying(false);
    rebuildTime(0);
    setTime(0);
  }

  function seek(t: number) {
    const tt = Math.max(0, Math.min(attack?.duration ?? 0, t));
    setTime(tt);
    rebuildTime(tt);
  }

  function stepTime(delta: number) {
    setPlaying(false);
    seek(time + delta);
  }

  // ---------- save ----------
  async function save(silent = false) {
    if (!attack) return;
    await store.update(assetId, attack.name || "Untitled Attack", attack);
    setDirty(false);
    if (!silent) {
      toast("ATTACK SAVED");
      sfx.confirm();
    }
  }

  // ---------- testing ----------
  function runTest(runs: number) {
    if (!attack) return;
    const results: TestResult[] = [];
    for (let i = 0; i < runs; i++) {
      results.push(simulateAttack(attack, difficulty, testPower, createSoulAI));
    }
    setTestResult(results);
  }

  // ---------- pattern helpers ----------
  function generatePattern(cfg: PatternCfg) {
    mutate((d) => {
      const t0 = time;
      const cx = d.box.width / 2;
      const cy = d.box.height / 2;
      for (let i = 0; i < cfg.count; i++) {
        const o = newAttackObject("projectile", t0 + i * cfg.delay);
        o.spriteId = cfg.sprite;
        o.damageMult = cfg.damageMult;
        o.velocity = cfg.speed;
        o.lifetime = cfg.lifetime;
        const kft = t0 + i * cfg.delay;
        if (cfg.type === "circle") {
          const a = (i / cfg.count) * 360 + cfg.rotation;
          o.movement = "radial";
          o.angle = a;
          o.keyframes.pos = [{ t: kft, x: cx + Math.cos((a * Math.PI) / 180) * cfg.radius, y: cy + Math.sin((a * Math.PI) / 180) * cfg.radius, e: "linear" }];
          o.start = kft;
        } else if (cfg.type === "spiral") {
          const a = cfg.rotation + i * cfg.spiralTwist;
          o.movement = "radial";
          o.angle = a;
          o.keyframes.pos = [{ t: kft, x: cx, y: cy, e: "linear" }];
          o.start = kft;
        } else if (cfg.type === "line") {
          o.movement = "linear";
          o.angle = cfg.rotation;
          const rad = (cfg.rotation * Math.PI) / 180;
          const off = (i - (cfg.count - 1) / 2) * cfg.radius;
          o.keyframes.pos = [{ t: kft, x: cx + Math.cos(rad + Math.PI / 2) * off, y: cy + Math.sin(rad + Math.PI / 2) * off, e: "linear" }];
          o.start = kft;
        } else {
          o.movement = "linear";
          o.angle = 90;
          o.keyframes.pos = [{ t: kft, x: Math.random() * d.box.width, y: -16, e: "linear" }];
          o.start = kft;
        }
        d.objects.push(o);
      }
    });
    toast("PATTERN GENERATED — OBJECTS ARE FULLY EDITABLE");
    sfx.confirm();
  }

  // ============================================================

  if (missing)
    return (
      <main className="min-h-screen checker flex items-center justify-center">
        <div className="pixel-panel p-8 text-2xl">
          ATTACK NOT FOUND.{" "}
          <button className="pixel-btn ml-2" onClick={() => router.push("/attacks")}>
            BACK
          </button>
        </div>
      </main>
    );
  if (!attack) return <main className="min-h-screen checker flex items-center justify-center text-2xl text-[#9a9ab8]">LOADING...</main>;

  const sel = selectedObj();
  const rt = rtRef.current;

  return (
    <main className="min-h-screen checker px-3 py-4">
      <div className="max-w-[1400px] mx-auto space-y-3">
        {/* header */}
        <header className="flex flex-wrap items-center gap-2">
          <button className="pixel-btn" onClick={() => router.push("/attacks")}>
            ◀ ATTACKS
          </button>
          <input
            className="pixel-input !w-56 text-xl"
            value={attack.name}
            onChange={(e) => silentMutate((d) => void (d.name = e.target.value))}
            onBlur={() => setDirty(true)}
          />
          <span className={`text-lg ${dirty ? "text-[#ff2040]" : "text-[#46e6a0]"}`}>{dirty ? "* UNSAVED" : "* SAVED"}</span>
          <div className="flex-1" />
          <button className="pixel-btn" onClick={undo} title="Ctrl+Z">
            UNDO
          </button>
          <button className="pixel-btn" onClick={redo} title="Ctrl+Y">
            REDO
          </button>
          <button className="pixel-btn" onClick={() => setPatternOpen(true)}>
            ✦ PATTERNS
          </button>
          <button
            className="pixel-btn gold"
            onClick={() => {
              setTestResult(null);
              setTestOpen(true);
            }}
          >
            ⚑ TEST ATTACK
          </button>
          <button className="pixel-btn solid" onClick={() => save()}>
            SAVE
          </button>
        </header>

        <div className="grid grid-cols-1 xl:grid-cols-[210px_1fr_290px] gap-3">
          {/* left: objects palette */}
          <div className="pixel-panel p-3 space-y-2 self-start">
            <div className="pixel-label">+ ADD OBJECT</div>
            {(
              [
                ["projectile", "● PROJECTILE"],
                ["hazard", "■ HAZARD"],
                ["warning", "▲ WARNING"],
                ["effect", "✦ EFFECT"],
              ] as [ObjKind, string][]
            ).map(([k, label]) => (
              <button key={k} className="pixel-btn w-full !justify-start" onClick={() => addObject(k)}>
                {label}
              </button>
            ))}
            <div className="pixel-hr" />
            <div className="pixel-label">OBJECTS ({attack.objects.length})</div>
            <div className="max-h-64 overflow-auto space-y-1">
              {attack.objects.map((o) => (
                <button
                  key={o.id}
                  className={`w-full text-left px-2 py-1 text-lg cursor-pointer truncate border ${
                    selectedIds.includes(o.id) ? "bg-[#ffe14d] text-black border-[#ffe14d]" : "border-transparent text-[#c9c9d9] hover:bg-[#22223a]"
                  }`}
                  onClick={(e) => {
                    if (e.shiftKey) {
                      setSelectedIds((cur) => (cur.includes(o.id) ? cur.filter((x) => x !== o.id) : [...cur, o.id]));
                    } else {
                      setSelectedObjId(o.id);
                    }
                    setSelectedKF(null);
                  }}
                >
                  {o.name} <span className="text-xs opacity-60">[{o.kind}]</span>
                </button>
              ))}
            </div>
            <div className="pixel-hr" />
            <div className="pixel-label">VIEW</div>
            <SelectField
              label="GRID SNAP"
              value={String(snap)}
              options={[
                { value: "0", label: "OFF" },
                { value: "1", label: "1 PX" },
                { value: "5", label: "5 PX" },
                { value: "10", label: "10 PX" },
                { value: "25", label: "25 PX" },
              ]}
              onChange={(v) => setSnap(parseInt(v))}
            />
            <button className={`pixel-btn w-full ${showCollisions ? "solid" : ""}`} onClick={() => setShowCollisions(!showCollisions)}>
              COLLISIONS: {showCollisions ? "ON" : "OFF"}
            </button>
            <button className={`pixel-btn w-full ${handlesOn ? "solid" : ""}`} onClick={() => setHandlesOn(!handlesOn)}>
              ROT/SCALE RING: {handlesOn ? "ON" : "OFF"}
            </button>
            <NumField label="TIMELINE ZOOM %" value={Math.round((pxPerSec / 80) * 100)} min={40} max={250} onCommit={(v) => setPxPerSec((v / 100) * 80)} />
          </div>

          {/* center: canvas + transport + timeline */}
          <div className="space-y-2 min-w-0">
            <div className="pixel-panel p-2">
              <canvas
                ref={canvasRef}
                width={CANVAS_W}
                height={CANVAS_H}
                className="w-full cursor-crosshair touch-none"
                onPointerDown={onCanvasPointerDown}
                onPointerMove={onCanvasPointerMove}
                onPointerUp={onCanvasPointerUp}
                onPointerCancel={onCanvasPointerUp}
              />
              <div className="flex flex-wrap items-center gap-2 mt-2 text-lg">
                <button className="pixel-btn solid !px-3" onClick={togglePlay}>
                  {playing ? "❚❚ PAUSE" : "▶ PLAY"}
                </button>
                <button className="pixel-btn !px-3" onClick={stop}>
                  ■ STOP
                </button>
                <button className="pixel-btn !px-2" onClick={() => stepTime(-0.1)}>
                  −0.1s
                </button>
                <button className="pixel-btn !px-2" onClick={() => stepTime(0.1)}>
                  +0.1s
                </button>
                <button className={`pixel-btn !px-3 ${loop ? "solid" : ""}`} onClick={() => setLoop(!loop)}>
                  LOOP
                </button>
                <select className="pixel-input !w-24" value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))}>
                  {[0.25, 0.5, 1, 2, 4].map((s) => (
                    <option key={s} value={s}>
                      {s}×
                    </option>
                  ))}
                </select>
                <span className="text-[#ffe14d] font-ui text-xl ml-2">
                  T = {time.toFixed(2)}s / {attack.duration.toFixed(1)}s
                </span>
                <span className="ml-auto text-[#9a9ab8]">
                  SOUL HP {rt ? Math.max(0, Math.round(rt.soul.hp)) : "–"} · HITS {rt?.hits ?? 0} · DMG {rt?.damageDealt ?? 0}
                </span>
              </div>
            </div>

            <div className="pixel-panel p-2">
              <div className="pixel-label mb-1">TIMELINE — DRAG ◆ KEYFRAMES · CLICK RULER TO SCRUB · SPACE = PLAY</div>
              <Timeline
                attack={attack}
                time={time}
                pxPerSec={pxPerSec}
                selectedObjId={selectedObjId}
                selectedKF={selectedKF}
                onSelectObject={(id) => {
                  setSelectedObjId(id);
                  setSelectedKF(null);
                }}
                onSelectKF={setSelectedKF}
                onSeek={(t) => {
                  setPlaying(false);
                  seek(t);
                }}
                onKFDragStart={() => {
                  setPlaying(false);
                  beginTransient();
                }}
                onKFDrag={(kf, newT) => {
                  silentMutate((d) => {
                    const o = d.objects.find((x) => x.id === kf.objId);
                    if (!o) return;
                    const arr = o.keyframes[kf.channel] as { t: number }[];
                    if (arr[kf.index]) arr[kf.index].t = Math.round(newT * 100) / 100;
                  });
                }}
                onKFDragEnd={() => {
                  endTransient();
                  silentMutate((d) => {
                    for (const o of d.objects)
                      for (const ch of ["pos", "rot", "scale", "opacity"] as const)
                        (o.keyframes[ch] as { t: number }[]).sort((a, b) => a.t - b.t);
                  });
                  setSelectedKF(null);
                }}
              />
            </div>
          </div>

          {/* right: properties */}
          <div className="space-y-3 self-start">
            <div className="pixel-panel p-3 space-y-2">
              <div className="pixel-label">ATTACK BOX</div>
              <div className="grid grid-cols-2 gap-2">
                <NumField label="WIDTH" value={attack.box.width} min={120} max={900} onCommit={(v) => mutate((d) => void (d.box.width = v))} />
                <NumField label="HEIGHT" value={attack.box.height} min={120} max={900} onCommit={(v) => mutate((d) => void (d.box.height = v))} />
                <NumField label="SOUL X" value={attack.box.soulStart.x} min={0} onCommit={(v) => mutate((d) => void (d.box.soulStart.x = v))} />
                <NumField label="SOUL Y" value={attack.box.soulStart.y} min={0} onCommit={(v) => mutate((d) => void (d.box.soulStart.y = v))} />
                <NumField label="DURATION s" value={attack.duration} min={0.5} max={60} step={0.5} onCommit={(v) => mutate((d) => void (d.duration = v))} />
                <NumField label="INVULN s" value={attack.invuln} min={0} max={3} step={0.1} onCommit={(v) => mutate((d) => void (d.invuln = v))} />
              </div>
              <div className="pixel-hr" />
              <div className="flex items-center justify-between">
                <span className="pixel-label">BOX SIZE KEYFRAMES (ANIMATED ARENA)</span>
                <button
                  className="pixel-btn !py-0.5 !px-2 text-sm"
                  onClick={() =>
                    mutate((d) => {
                      (d.boxKeys ??= []).push({ t: Math.round(time * 100) / 100, w: d.box.width, h: d.box.height });
                      d.boxKeys!.sort((a, b) => a.t - b.t);
                    })
                  }
                >
                  + ◆ SIZE @ {time.toFixed(2)}s
                </button>
              </div>
              {(attack.boxKeys ?? []).map((k, i) => (
                <div key={i} className="grid grid-cols-4 gap-1 items-end">
                  <NumField
                    label="T s"
                    value={k.t}
                    min={0}
                    max={attack.duration}
                    step={0.1}
                    onCommit={(v) =>
                      mutate((d) => {
                        d.boxKeys![i].t = v;
                        d.boxKeys!.sort((a, b) => a.t - b.t);
                      })
                    }
                  />
                  <NumField label="W" value={k.w} min={80} max={900} onCommit={(v) => mutate((d) => void (d.boxKeys![i].w = v))} />
                  <NumField label="H" value={k.h} min={80} max={900} onCommit={(v) => mutate((d) => void (d.boxKeys![i].h = v))} />
                  <button className="pixel-btn danger !py-1" onClick={() => mutate((d) => void d.boxKeys!.splice(i, 1))}>
                    ✕
                  </button>
                </div>
              ))}
              {(attack.boxKeys ?? []).length === 0 && (
                <p className="text-base text-[#7a7a96]">NO SIZE KEYS — THE BOX STAYS STATIC. ADD KEYS TO SHRINK/GROW THE ARENA MID-ATTACK (SEE “BOX MELTDOWN” PRESET).</p>
              )}
            </div>

            {!sel ? (
              <div className="pixel-panel p-3 text-lg text-[#9a9ab8]">
                SELECT AN OBJECT — CLICK IT IN THE BOX OR THE TIMELINE.
                <br />
                <br />
                DRAG TO MOVE · ARROWS NUDGE · SHIFT+ARROWS ×10 · CTRL+D DUPLICATE · DEL REMOVE.
              </div>
            ) : (
              <ObjectProps
                key={sel.id}
                obj={sel}
                ids={selectedIds}
                attack={attack}
                time={time}
                selectedKF={selectedKF}
                onChange={(fn) => mutate(fn)}
                onAddKF={addKFAtPlayhead}
                onDeleteKF={deleteKF}
                onDelete={deleteSelected}
                onDuplicate={duplicateSelected}
              />
            )}
          </div>
        </div>
      </div>

      {/* TEST modal */}
      {testOpen && (
        <Modal title="TEST ATTACK" onClose={() => setTestOpen(false)} wide>
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-4">
            <div className="space-y-3">
              <p className="text-xl text-[#c9c9d9]">
                RUNS A HEADLESS SIMULATION: THE AI SOUL ATTEMPTS TO SURVIVE YOUR PATTERN. USE THIS TO BALANCE DIFFICULTY.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <SelectField
                  label="AI DIFFICULTY"
                  value={difficultyId}
                  options={SOUL_DIFFICULTIES.map((d) => ({ value: d.id, label: d.name }))}
                  onChange={setDifficultyId}
                />
                <NumField label="BOSS ATTACK (TEST VALUE)" value={testPower} min={1} max={999} onCommit={setTestPower} />
              </div>
              <div className="flex gap-2">
                <button className="pixel-btn solid" onClick={() => runTest(1)}>
                  ▶ RUN TEST
                </button>
                <button className="pixel-btn" onClick={() => runTest(5)}>
                  RUN ×5 AVERAGE
                </button>
                <button
                  className="pixel-btn gold"
                  onClick={() => {
                    setTestOpen(false);
                    rebuildTime(0);
                    setTime(0);
                    setPlaying(true);
                  }}
                >
                  WATCH LIVE PREVIEW
                </button>
              </div>
              {testResult && (
                <div className="pixel-inset p-4 text-xl space-y-1">
                  <div className="font-display text-[10px] text-[#ffe14d] mb-2">ATTACK TEST — {difficulty.name}</div>
                  <TestStats results={testResult} duration={attack.duration} />
                </div>
              )}
            </div>
          </div>
        </Modal>
      )}

      {patternOpen && <PatternModal onGenerate={(cfg) => { generatePattern(cfg); setPatternOpen(false); }} onClose={() => setPatternOpen(false)} />}
    </main>
  );
}

// ============================================================

function TestStats({ results, duration }: { results: TestResult[]; duration: number }) {
  const avg = (f: (r: TestResult) => number) => results.reduce((s, r) => s + f(r), 0) / results.length;
  const dmg = avg((r) => r.damage);
  const hits = avg((r) => r.hits);
  const survival = results.filter((r) => r.survived).length / results.length;
  const minHp = Math.min(...results.map((r) => r.minHpPct));
  const stars = dmg <= 1 ? 1 : dmg < 25 ? 2 : dmg < 50 ? 3 : dmg < 85 ? 4 : 5;
  return (
    <div className="grid grid-cols-2 gap-x-8 gap-y-1">
      <span>DURATION:</span>
      <span className="text-white">{duration.toFixed(1)}s</span>
      <span>AVG SOUL DAMAGE:</span>
      <span className="text-[#ff2040]">{dmg.toFixed(1)}</span>
      <span>AVG HITS:</span>
      <span className="text-white">{hits.toFixed(1)}</span>
      <span>SURVIVAL:</span>
      <span className={survival > 0.5 ? "text-[#46e6a0]" : "text-[#ff2040]"}>{Math.round(survival * 100)}%</span>
      <span>MIN SOUL HP:</span>
      <span className="text-white">{minHp.toFixed(0)}%</span>
      <span>EST. DIFFICULTY:</span>
      <span className="text-[#ffe14d]">{"★".repeat(stars)}{"☆".repeat(5 - stars)}</span>
    </div>
  );
}

// ---------------- object properties ----------------

function soundOptions(): { value: string; label: string }[] {
  const custom = store.byKind("sound").map((a) => ({ value: `asset:${a.id}`, label: `♪ ${a.name}` }));
  return [
    { value: "default", label: "DEFAULT" },
    { value: "none", label: "NONE (SILENT)" },
    ...SFX_LIBRARY.map((s) => ({ value: s.id, label: s.name })),
    ...custom,
  ];
}

function ObjectProps({
  obj,
  ids,
  attack,
  time,
  selectedKF,
  onChange,
  onAddKF,
  onDeleteKF,
  onDelete,
  onDuplicate,
}: {
  obj: AttackObject;
  ids: string[];
  attack: AttackData;
  time: number;
  selectedKF: SelectedKF | null;
  onChange: (fn: (d: AttackData) => void) => void;
  onAddKF: (ch: "pos" | "rot" | "scale" | "opacity") => void;
  onDeleteKF: (kf: SelectedKF) => void;
  onDelete: () => void;
  onDuplicate: () => void;
}) {
  const set = (fn: (o: AttackObject) => void) =>
    onChange((d) => {
      // edits apply to EVERY selected object
      for (const id of ids.length ? ids : [obj.id]) {
        const o = d.objects.find((x) => x.id === id);
        if (o) fn(o);
      }
    });

  const customSprites = store.byKind("sprite");
  type KfAny = { t: number; v?: number; x?: number; y?: number; e?: Easing };
  const selKf: KfAny | undefined =
    selectedKF && selectedKF.objId === obj.id
      ? (obj.keyframes[selectedKF.channel][selectedKF.index] as KfAny | undefined)
      : undefined;

  return (
    <div className="pixel-panel p-3 space-y-2">
      <div className="flex items-center justify-between">
        <div className="pixel-label">SELECTED: {obj.kind.toUpperCase()}</div>
        <div className="flex gap-1">
          <button className="pixel-btn !py-0.5 !px-2 text-sm" onClick={onDuplicate}>
            COPY
          </button>
          <button className="pixel-btn danger !py-0.5 !px-2 text-sm" onClick={onDelete}>
            DEL
          </button>
        </div>
      </div>
      {ids.length > 1 ? (
        <div className="pixel-inset px-2 py-1 text-lg text-[#ffe14d]">
          {ids.length} OBJECTS SELECTED — EDITS APPLY TO ALL (SHIFT-CLICK TO TOGGLE)
        </div>
      ) : (
        <TextField label="NAME" value={obj.name} onCommit={(v) => set((o) => void (o.name = v))} />
      )}
      <div className="grid grid-cols-2 gap-2">
        <SelectField
          label="SPRITE"
          value={obj.spriteId}
          options={[...OBJECT_SPRITES, ...customSprites.map((s) => s.id)].map((s) => ({ value: s, label: s }))}
          onChange={(v) => set((o) => void (o.spriteId = v))}
        />
        <SelectField
          label="LAYER"
          value={obj.layer}
          options={LAYER_ORDER.map((l) => ({ value: l, label: l.toUpperCase() }))}
          onChange={(v) => set((o) => void (o.layer = v as LayerId))}
        />
        <SelectField
          label="MOVEMENT"
          value={obj.movement}
          options={[
            { value: "keyframed", label: "KEYFRAMED" },
            { value: "static", label: "STATIC" },
            { value: "linear", label: "LINEAR" },
            { value: "radial", label: "RADIAL (from point)" },
            { value: "homing", label: "HOMING (tracks SOUL)" },
          ]}
          onChange={(v) => set((o) => void (o.movement = v as AttackObject["movement"]))}
        />
        <NumField label="DMG ×ATK" value={obj.damageMult} min={0} max={9} step={0.05} onCommit={(v) => set((o) => void (o.damageMult = v))} />
      </div>

      {obj.movement !== "keyframed" && obj.movement !== "static" && (
        <div className="grid grid-cols-2 gap-2">
          <NumField label="SPEED px/s" value={obj.velocity} min={0} onCommit={(v) => set((o) => void (o.velocity = v))} />
          <NumField label="ANGLE °" value={obj.angle} min={-360} max={360} onCommit={(v) => set((o) => void (o.angle = v))} />
          <NumField label="ACCEL px/s²" value={obj.accel} min={-500} max={900} onCommit={(v) => set((o) => void (o.accel = v))} />
          {obj.movement === "homing" && (
            <NumField label="TURN °/s" value={obj.turnRate} min={0} max={720} onCommit={(v) => set((o) => void (o.turnRate = v))} />
          )}
        </div>
      )}
      {obj.keyframes.rot.length === 0 && obj.movement !== "keyframed" && (
        <NumField label="SPIN °/s" value={obj.spin} min={-720} max={720} onCommit={(v) => set((o) => void (o.spin = v))} />
      )}

      <div className="grid grid-cols-2 gap-2">
        <NumField label="START s" value={obj.start} min={0} max={attack.duration} step={0.1} onCommit={(v) => set((o) => void (o.start = v))} />
        <NumField
          label="LIFETIME s (0=∞)"
          value={obj.lifetime ?? 0}
          min={0}
          step={0.1}
          onCommit={(v) => set((o) => void (o.lifetime = v <= 0 ? null : v))}
        />
      </div>

      <div className="pixel-hr" />
      <div className="pixel-label">COLLISION</div>
      <div className="grid grid-cols-2 gap-2">
        <SelectField
          label="TYPE"
          value={obj.collision.type}
          options={[
            { value: "circle", label: "CIRCLE" },
            { value: "rect", label: "RECTANGLE" },
            { value: "none", label: "NONE" },
          ]}
          onChange={(v) =>
            set((o) => {
              if (v === "circle") o.collision = { type: "circle", radius: 8 };
              else if (v === "rect") o.collision = { type: "rect", w: 20, h: 20 };
              else o.collision = { type: "none" };
            })
          }
        />
        {obj.collision.type === "circle" && (
          <NumField label="RADIUS" value={obj.collision.radius} min={1} max={200} onCommit={(v) => set((o) => o.collision.type === "circle" && void (o.collision.radius = v))} />
        )}
        {obj.collision.type === "rect" && (
          <>
            <NumField label="W" value={obj.collision.w} min={1} max={900} onCommit={(v) => set((o) => o.collision.type === "rect" && void (o.collision.w = v))} />
            <NumField label="H" value={obj.collision.h} min={1} max={900} onCommit={(v) => set((o) => o.collision.type === "rect" && void (o.collision.h = v))} />
          </>
        )}
      </div>

      <div className="pixel-hr" />
      <div className="pixel-label">SOUNDS (PLAYS IN PREVIEW & BATTLE)</div>
      <div className="grid grid-cols-3 gap-2">
        <SelectField
          label="SPAWN"
          value={obj.spawnSound ?? "default"}
          options={soundOptions()}
          onChange={(v) => set((o) => void (o.spawnSound = v))}
        />
        <SelectField
          label="HIT"
          value={obj.hitSound ?? "default"}
          options={soundOptions()}
          onChange={(v) => set((o) => void (o.hitSound = v))}
        />
        <SelectField
          label="DESPAWN"
          value={obj.despawnSound ?? "default"}
          options={soundOptions()}
          onChange={(v) => set((o) => void (o.despawnSound = v))}
        />
      </div>

      <div className="pixel-hr" />
      <div className="pixel-label">KEYFRAMES @ T={time.toFixed(2)}s</div>
      <div className="grid grid-cols-2 gap-1">
        {(["pos", "rot", "scale", "opacity"] as const).map((ch) => (
          <button key={ch} className="pixel-btn !py-1 text-sm" onClick={() => onAddKF(ch)}>
            + ◆ {ch.toUpperCase()}
          </button>
        ))}
      </div>
      {selectedKF && selectedKF.objId === obj.id && selKf && (
        <div className="pixel-inset p-2 text-lg space-y-1">
          <div className="text-[#ffe14d]">
            {selectedKF.channel.toUpperCase()} KEYFRAME #{selectedKF.index + 1}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <NumField
              label="TIME s"
              value={selKf.t}
              min={0}
              max={attack.duration}
              step={0.05}
              onCommit={(v) =>
                set((o) => {
                  const arr = o.keyframes[selectedKF.channel] as { t: number }[];
                  if (arr[selectedKF.index]) arr[selectedKF.index].t = v;
                })
              }
            />
            {selKf.v !== undefined || (selKf.x === undefined && selKf.y === undefined) ? (
              <NumField
                label={selectedKF.channel === "rot" ? "DEGREES" : selectedKF.channel === "opacity" ? "ALPHA 0-1" : "VALUE"}
                value={selKf.v ?? 0}
                step={selectedKF.channel === "rot" ? 5 : 0.1}
                onCommit={(v) =>
                  set((o) => {
                    const arr = o.keyframes[selectedKF.channel] as { v: number }[];
                    if (arr[selectedKF.index]) arr[selectedKF.index].v = v;
                  })
                }
              />
            ) : (
              <>
                <NumField
                  label="X"
                  value={selKf.x ?? 0}
                  onCommit={(v) =>
                    set((o) => {
                      const arr = o.keyframes.pos;
                      if (arr[selectedKF.index]) arr[selectedKF.index].x = v;
                    })
                  }
                />
                <NumField
                  label="Y"
                  value={selKf.y ?? 0}
                  onCommit={(v) =>
                    set((o) => {
                      const arr = o.keyframes.pos;
                      if (arr[selectedKF.index]) arr[selectedKF.index].y = v;
                    })
                  }
                />
              </>
            )}
            <SelectField
              label="EASING"
              value={selKf.e ?? "linear"}
              options={EASINGS.map((e) => ({ value: e, label: e.toUpperCase() }))}
              onChange={(v) =>
                set((o) => {
                  const arr = o.keyframes[selectedKF.channel] as { e: Easing }[];
                  if (arr[selectedKF.index]) arr[selectedKF.index].e = v as Easing;
                })
              }
            />
          </div>
          <button className="pixel-btn danger !py-0.5 text-sm" onClick={() => onDeleteKF(selectedKF)}>
            DELETE KEYFRAME
          </button>
        </div>
      )}
      <p className="text-base text-[#7a7a96]">
        TIP: MOVE THE PLAYHEAD, DRAG THE OBJECT OR USE “+ ◆” TO KEYFRAME POSITION OVER TIME. ROTATION/SCALE/OPACITY
        KEYFRAMES WORK THE SAME WAY.
      </p>
    </div>
  );
}

// ---------------- pattern generator ----------------

interface PatternCfg {
  type: "circle" | "spiral" | "line" | "random";
  count: number;
  radius: number;
  rotation: number;
  speed: number;
  delay: number;
  spiralTwist: number;
  damageMult: number;
  sprite: string;
  lifetime: number;
}

function PatternModal({ onGenerate, onClose }: { onGenerate: (cfg: PatternCfg) => void; onClose: () => void }) {
  const [cfg, setCfg] = useState<PatternCfg>({
    type: "circle",
    count: 8,
    radius: 60,
    rotation: 0,
    speed: 90,
    delay: 0.15,
    spiralTwist: 30,
    damageMult: 0.5,
    sprite: "bullet",
    lifetime: 4,
  });
  return (
    <Modal title="SPAWN PATTERN HELPER" onClose={onClose}>
      <p className="text-lg text-[#9a9ab8] mb-3">
        GENERATES EDITABLE OBJECTS AT THE CURRENT PLAYHEAD TIME. NOTHING IS BAKED — YOU CAN TWEAK EVERY PROJECTILE
        AFTERWARD.
      </p>
      <div className="grid grid-cols-2 gap-3">
        <SelectField
          label="PATTERN"
          value={cfg.type}
          options={[
            { value: "circle", label: "CIRCLE — ring around center" },
            { value: "spiral", label: "SPIRAL — staggered rotating stream" },
            { value: "line", label: "LINE — side-by-side volley" },
            { value: "random", label: "RANDOM — rain from above" },
          ]}
          onChange={(v) => setCfg({ ...cfg, type: v as PatternCfg["type"] })}
        />
        <SelectField
          label="SPRITE"
          value={cfg.sprite}
          options={OBJECT_SPRITES.filter((s) => s !== "rect").map((s) => ({ value: s, label: s }))}
          onChange={(v) => setCfg({ ...cfg, sprite: v })}
        />
        <NumField label="COUNT" value={cfg.count} min={1} max={64} onCommit={(v) => setCfg({ ...cfg, count: v })} />
        <NumField label="SPEED px/s" value={cfg.speed} min={0} max={900} onCommit={(v) => setCfg({ ...cfg, speed: v })} />
        <NumField label="RADIUS / SPACING" value={cfg.radius} min={0} max={400} onCommit={(v) => setCfg({ ...cfg, radius: v })} />
        <NumField label="BASE ANGLE °" value={cfg.rotation} min={-360} max={360} onCommit={(v) => setCfg({ ...cfg, rotation: v })} />
        <NumField label="DELAY BETWEEN s" value={cfg.delay} min={0} max={2} step={0.05} onCommit={(v) => setCfg({ ...cfg, delay: v })} />
        {cfg.type === "spiral" && (
          <NumField label="TWIST °/SHOT" value={cfg.spiralTwist} min={-180} max={180} onCommit={(v) => setCfg({ ...cfg, spiralTwist: v })} />
        )}
        <NumField label="DMG ×ATK" value={cfg.damageMult} min={0} max={5} step={0.05} onCommit={(v) => setCfg({ ...cfg, damageMult: v })} />
        <NumField label="LIFETIME s" value={cfg.lifetime} min={0.5} max={20} step={0.5} onCommit={(v) => setCfg({ ...cfg, lifetime: v })} />
      </div>
      <div className="mt-4 flex gap-2">
        <button className="pixel-btn solid" onClick={() => onGenerate(cfg)}>
          ✦ GENERATE
        </button>
        <button className="pixel-btn" onClick={onClose}>
          CANCEL
        </button>
      </div>
    </Modal>
  );
}
