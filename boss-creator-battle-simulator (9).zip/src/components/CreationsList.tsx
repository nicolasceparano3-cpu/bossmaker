"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import type { Asset, AssetKind } from "@/game/types";
import { store } from "@/game/store";
import { downloadJson } from "@/game/store";
import { toast } from "./ui";
import { sfx } from "@/game/sfx";

export default function CreationsList({
  kind,
  title,
  subtitle,
  newLabel,
  makeNew,
  editHref,
  preview,
  extraActions,
  folderOf,
  onFolder,
  headerExtra,
}: {
  kind: AssetKind;
  title: string;
  subtitle: string;
  newLabel: string;
  makeNew: () => { name: string; data: unknown };
  editHref: (id: string) => string;
  preview: (asset: Asset) => ReactNode;
  extraActions?: (asset: Asset) => ReactNode;
  /** enables folder grouping UI */
  folderOf?: (asset: Asset) => string | undefined;
  onFolder?: (asset: Asset, folder: string | undefined) => Promise<void> | void;
  headerExtra?: ReactNode;
}) {
  const router = useRouter();
  const [, force] = useState(0);
  const [busy, setBusy] = useState(false);
  const [folderFilter, setFolderFilter] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    store.ensureLoaded().then(() => force((x) => x + 1));
  }, []);

  const allItems = store.byKind(kind);
  const folders = folderOf
    ? Array.from(new Set(allItems.map((a) => folderOf(a)).filter((f): f is string => !!f))).sort()
    : [];
  const items = folderOf && folderFilter ? allItems.filter((a) => folderOf(a) === folderFilter) : allItems;

  async function createNew() {
    if (busy) return;
    setBusy(true);
    try {
      const { name, data } = makeNew();
      const asset = await store.create(kind, name, data);
      sfx.confirm();
      router.push(editHref(asset.id));
    } catch (e) {
      toast(`FAILED: ${e}`);
    } finally {
      setBusy(false);
    }
  }

  async function importJson(file: File) {
    try {
      const text = await file.text();
      const json = JSON.parse(text);
      const data = json.data ?? json;
      const name = json.name ?? data?.name ?? "Imported";
      await store.create(kind, name, data);
      toast("IMPORTED");
      force((x) => x + 1);
    } catch (e) {
      toast(`IMPORT FAILED: ${e}`);
    }
  }

  return (
    <main className="min-h-screen checker px-4 py-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex flex-wrap items-center gap-3 mb-5">
          <button className="pixel-btn" onClick={() => router.push("/")}>
            ◀ MENU
          </button>
          <div className="flex-1 min-w-52">
            <h1 className="font-display text-lg text-[#ffe14d]">{title}</h1>
            <p className="text-xl text-[#9a9ab8]">{subtitle}</p>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importJson(f);
              e.target.value = "";
            }}
          />
          <button className="pixel-btn" onClick={() => fileRef.current?.click()}>
            IMPORT JSON
          </button>
          {headerExtra}
          <button className="pixel-btn solid" onClick={createNew} disabled={busy}>
            + {newLabel}
          </button>
        </header>

        {folderOf && (
          <div className="flex items-center gap-2 flex-wrap mb-4">
            <span className="pixel-label">FOLDERS:</span>
            <button
              className={`pixel-btn !py-0.5 !px-2 text-base ${folderFilter === null ? "solid" : ""}`}
              onClick={() => setFolderFilter(null)}
            >
              ALL ({allItems.length})
            </button>
            {folders.map((f) => (
              <button
                key={f}
                className={`pixel-btn !py-0.5 !px-2 text-base ${folderFilter === f ? "solid" : ""}`}
                onClick={() => setFolderFilter(f)}
              >
                ▸ {f.toUpperCase()}
              </button>
            ))}
            {folders.length === 0 && (
              <span className="text-lg text-[#7a7a96]">NONE YET — SET A FOLDER ON AN ITEM TO GROUP IT (E.G. A BOSS + ITS ANIM SPRITES).</span>
            )}
          </div>
        )}

        {items.length === 0 ? (
          <div className="pixel-panel p-10 text-center text-2xl text-[#9a9ab8]">
            NOTHING HERE YET.
            <br />
            <span className="text-[#ffe14d]">CREATE YOUR FIRST {kind.toUpperCase()}!</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map((a) => (
              <div key={a.id} className="pixel-panel p-3 flex flex-col">
                <div className="flex items-center gap-3 mb-2">
                  {preview(a)}
                  <div className="min-w-0 flex-1">
                    <div className="font-display text-[10px] text-white truncate">{a.name}</div>
                    <div className="text-base text-[#7a7a96]">{new Date(a.updatedAt).toLocaleDateString()}</div>
                    {folderOf && onFolder && (
                      <input
                        className="pixel-input !text-base !py-0 mt-1"
                        placeholder="▸ folder…"
                        defaultValue={folderOf(a) ?? ""}
                        key={`${a.id}:${folderOf(a) ?? ""}`}
                        onBlur={(e) => {
                          const v = e.target.value.trim();
                          if (v !== (folderOf(a) ?? "")) void onFolder(a, v || undefined);
                        }}
                        onKeyDown={(e) => e.key === "Enter" && (e.target as HTMLInputElement).blur()}
                      />
                    )}
                  </div>
                </div>
                <div className="flex flex-wrap gap-2 mt-auto">
                  <button
                    className="pixel-btn !py-1"
                    onClick={() => {
                      sfx.select();
                      router.push(editHref(a.id));
                    }}
                  >
                    EDIT
                  </button>
                  {extraActions?.(a)}
                  <button
                    className="pixel-btn !py-1"
                    onClick={async () => {
                      await store.duplicate(a.id);
                      toast("DUPLICATED");
                      force((x) => x + 1);
                    }}
                  >
                    COPY
                  </button>
                  <button
                    className="pixel-btn !py-1"
                    onClick={() => {
                      downloadJson(`${a.name.replace(/\s+/g, "_").toLowerCase()}.${kind}.json`, {
                        format: "bossmaker",
                        kind,
                        name: a.name,
                        data: a.data,
                      });
                    }}
                  >
                    EXPORT
                  </button>
                  <button
                    className="pixel-btn danger !py-1"
                    onClick={async () => {
                      if (!confirm(`Delete "${a.name}"?`)) return;
                      await store.remove(a.id);
                      force((x) => x + 1);
                    }}
                  >
                    DEL
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
