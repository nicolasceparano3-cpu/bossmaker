"use client";
// ============================================================
// Battle mode: YOU ARE THE BOSS. Deltarune-style staging with a
// data-driven backdrop (editable void grid), ground, positions,
// hover/static stances, per-entity animation runners (boss AND
// heroes: idle/attack/ability/damaged/killed/defend loops) and a
// particle overlay fed by those animations.
// ============================================================

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import type {
  AbilityData,
  AnimationData,
  Asset,
  AttackData,
  BossData,
  HeroCustom,
  ParticleAnchor,
  SoulAIDifficulty,
  SoundData,
} from "@/game/types";
import {
  addTp,
  bossAttack,
  makeBossInstance,
  makeHeroInstance,
  makeLog,
  pickHeroAction,
  resolveAbilityPower,
  resolveBossFight,
  resolveHeroAction,
  tickBossMods,
  tickCooldowns,
  tickHeroMods,
  type BossInstance,
  type HeroInstance,
  type LogLine,
} from "@/game/battle";
import { tpFromDamageDealt, tpFromDamageTaken } from "@/game/combat";
import { resolveHeroData, resolveHeroCfg } from "@/game/heroRegistry";
import { bgVisual } from "@/game/backgrounds";
import { ParticleSystem } from "@/game/particles";
import { BUILTIN_SPRITES, drawSpriteAt, resolveSprite, spriteDataUrlFromGrid } from "@/game/sprites";
import { store } from "@/game/store";
import { SpriteView, HpBar } from "@/components/ui";
import SoulPhase, { type SoulPhaseResult } from "./SoulPhase";
import { sfx } from "@/game/sfx";

type Phase = "intro" | "heroes" | "bossMenu" | "abilities" | "target" | "soul" | "win" | "lose";

interface FloatNum {
  id: number;
  target: number | "boss";
  text: string;
  tone: "dmg" | "heal" | "tp" | "crit";
}

interface BV {
  round: number;
  phase: Phase;
  boss: BossInstance;
  heroes: HeroInstance[];
  log: LogLine[];
  banner: string | null;
  dialogue: string;
  floats: FloatNum[];
  shake: number;
  bossFlash: number;
  heroFlashIdx: number;
  heroFlash: number;
  bossLunge: number;
  heroLungeIdx: number;
  heroLunge: number;
  menuIdx: number;
  targetIdx: number;
  abilityIdx: number;
  targetMode: "fight" | "ability";
  pendingAbility: Asset<AbilityData> | null;
  pendingAttack: AttackData | null;
  logOpen: boolean;
}

let floatId = 1;
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

const HERO_BAR_COLOR: Record<string, string> = {
  kris: "#00a2e8",
  susie: "#e838a0",
  ralsei: "#00c832",
  noelle: "#8fd8ff",
};

const DEFAULT_HERO_POS = [
  { x: 16, y: 42 },
  { x: 24, y: 55 },
  { x: 17, y: 68 },
  { x: 27, y: 68 },
];
const DEFAULT_BOSS_POS = { x: 76, y: 45 };

const ICONS = {
  fight: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M13 1l2 2-7 7 1 1-2 2-1-1-3 3H1v-2l3-3-1-1 2-2 1 1z" />
    </svg>
  ),
  skill: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M8 0l2 5 5 1-4 3 1 6-4-3-4 3 1-6-4-3 5-1z" />
    </svg>
  ),
  defend: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M8 0l6 2v6c0 4-3 7-6 8-3-1-6-4-6-8V2z" />
    </svg>
  ),
  item: (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden>
      <path d="M4 2h8v3h3l-1 10H2L1 5h3zM6 5h4V4H6z" />
    </svg>
  ),
};

interface Run {
  anim: AnimationData;
  t: number;
  loop: boolean;
  spawned: Set<string>;
}

/** resolve a 'sprite:<id>' floor to a drawable url (uploads, pixel grids, built-ins) */
function floorUrl(floor: string): string | null {
  const id = floor.slice(7);
  const data = store.spriteData(id);
  if (data?.type === "image" && data.dataUrl) return data.dataUrl;
  if (data?.grid && data.palette) return spriteDataUrlFromGrid(data.grid, data.palette);
  const b = BUILTIN_SPRITES[id];
  if (b) return spriteDataUrlFromGrid(b.grid, b.palette);
  return null;
}

export default function BattleView({
  bossAsset,
  heroIds,
  difficulty,
}: {
  bossAsset: Asset<BossData>;
  heroIds: string[];
  difficulty: SoulAIDifficulty;
}) {
  const router = useRouter();
  const runToken = useRef(0);

  const S = useRef<BV>(null as unknown as BV);
  if (!S.current) S.current = initState();

  const [, setTick] = useState(0);
  const sync = useCallback(() => setTick((t) => t + 1), []);

  // hero customizations, resolved once per battle
  const heroCfgsRef = useRef<(HeroCustom | undefined)[]>([]);
  if (heroCfgsRef.current.length === 0) heroCfgsRef.current = heroIds.map((id) => resolveHeroCfg(id));

  function initState(): BV {
    return {
      round: 0,
      phase: "intro",
      boss: makeBossInstance(bossAsset.data),
      heroes: heroIds.map((id) => makeHeroInstance(resolveHeroData(id))),
      log: [],
      banner: null,
      dialogue: "",
      floats: [],
      shake: 0,
      bossFlash: 0,
      heroFlashIdx: -1,
      heroFlash: 0,
      bossLunge: 0,
      heroLungeIdx: -1,
      heroLunge: 0,
      menuIdx: 0,
      targetIdx: 0,
      abilityIdx: 0,
      targetMode: "fight",
      pendingAbility: null,
      pendingAttack: null,
      logOpen: false,
    };
  }

  const v = S.current;

  function log(text: string, tone: LogLine["tone"] = "info") {
    v.log = [...v.log.slice(-40), makeLog(text, tone)];
  }
  function addFloat(target: number | "boss", text: string, tone: FloatNum["tone"]) {
    v.floats = [...v.floats.slice(-10), { id: floatId++, target, text, tone }];
    const id = v.floats[v.floats.length - 1].id;
    setTimeout(() => {
      v.floats = v.floats.filter((f) => f.id !== id);
      sync();
    }, 950);
  }
  const aliveHeroes = () => v.heroes.map((h, i) => ({ h, i })).filter((x) => x.h.hp > 0);

  // ---------------- orchestration ----------------

  async function start() {
    const token = ++runToken.current;
    const ok = () => runToken.current === token;
    v.banner = `* THE FUN GANG BLOCKS ${bossAsset.data.name.toUpperCase()}'S WAY!`;
    sync();
    await sleep(1400);
    if (!ok()) return;
    v.banner = null;
    log(`* Round 1 begins. The heroes act first!`, "system");
    await heroTurn(token);
  }

  async function heroTurn(token: number) {
    const ok = () => runToken.current === token;
    v.round += 1;
    v.phase = "heroes";
    for (let i = 0; i < v.heroes.length; i++) {
      const h = v.heroes[i];
      const wasDefending = h.defending;
      h.defending = false;
      tickHeroMods(h);
      if (wasDefending && h.hp > 0) heroLoop(i, "idle");
    }
    tickBossMods(v.boss);
    v.banner = `— ROUND ${v.round}: HERO TURN —`;
    sync();
    await sleep(900);
    if (!ok()) return;
    v.banner = null;

    for (let i = 0; i < v.heroes.length; i++) {
      const h = v.heroes[i];
      if (h.hp <= 0) continue;
      const action = pickHeroAction(h, v.heroes, v.boss);
      v.dialogue = `* ${h.data.name} uses ${action.name}!`;
      v.heroLungeIdx = i;
      v.heroLunge++;
      heroPlay(i, action.kind === "attack" ? "attack" : action.kind === "heal" ? "heal" : "ability");
      sfx.select();
      sync();
      await sleep(420);
      if (!ok()) return;

      const out = resolveHeroAction(h, action, v.boss);
      if (action.kind === "heal") {
        const allies = aliveHeroes();
        const weakest = allies.sort((a, b) => a.h.hp / a.h.data.maxHp - b.h.hp / b.h.data.maxHp)[0];
        if (weakest) {
          weakest.h.hp = Math.min(weakest.h.data.maxHp, weakest.h.hp + out.heal);
          addFloat(weakest.i, `+${out.heal}`, "heal");
          log(`* ${h.data.name} heals ${weakest.h.data.name} for ${out.heal} HP!`, "heal");
          sfx.heal();
        }
      } else if (action.kind === "defend") {
        h.defending = true;
        heroLoop(i, "defend");
        log(`* ${h.data.name} braces for your attack.`, "info");
      } else {
        v.boss.hp = Math.max(0, v.boss.hp - out.damage);
        const gained = addTp(v.boss, tpFromDamageTaken(out.damage));
        v.bossFlash++;
        v.shake++;
        bossPlay("damaged");
        addFloat("boss", `-${out.damage}${out.crit ? "!!" : ""}`, out.crit ? "crit" : "dmg");
        log(`* ${h.data.name} deals ${out.damage} damage${out.crit ? " (CRIT!)" : ""} to ${bossAsset.data.name}!`, "damage");
        if (gained > 0) log(`* ${bossAsset.data.name} gains ${gained} TP.`, "tp");
        sfx.hurt();
      }
      sync();
      await sleep(620);
      if (!ok()) return;
      if (v.boss.hp <= 0) {
        await lose();
        return;
      }
      v.dialogue = "";
      sync();
    }

    // boss turn begins
    tickCooldowns(v.boss);
    const wasDef = v.boss.defending;
    v.boss.defending = false;
    if (wasDef) bossLoop("idle");
    v.banner = "— YOUR TURN —";
    sync();
    await sleep(800);
    if (!ok()) return;
    v.banner = null;
    v.dialogue = "";
    v.phase = "bossMenu";
    v.menuIdx = 0;
    sync();
  }

  async function lose() {
    v.phase = "lose";
    v.banner = null;
    stopTheme();
    bossLoop("killed");
    log(`* ${bossAsset.data.name} has fallen...`, "system");
    sync();
    sfx.defeat();
  }

  async function win() {
    v.phase = "win";
    v.banner = null;
    stopTheme();
    bossPlay("victory");
    log(`* All heroes have fallen. VICTORY!`, "system");
    sync();
    sfx.victory();
  }

  function checkHeroesDead(): boolean {
    return v.heroes.every((h) => h.hp <= 0);
  }

  async function endBossAction() {
    const token = runToken.current;
    sync();
    if (checkHeroesDead()) {
      await win();
      return;
    }
    await sleep(500);
    if (runToken.current !== token) return;
    await heroTurn(token);
  }

  // ---------------- boss commands ----------------

  function bossFight(targetIdx: number) {
    const target = v.heroes[targetIdx];
    if (!target || target.hp <= 0) return;
    const token = runToken.current;
    v.phase = "heroes";
    v.dialogue = "";
    v.bossLunge++;
    lastTargetRef.current = targetIdx;
    bossPlay("attack");
    sync();
    sfx.confirm();
    setTimeout(() => {
      if (runToken.current !== token) return;
      lastDamagedRef.current = targetIdx;
      const { damage, crit } = resolveBossFight(v.boss, target);
      target.hp = Math.max(0, target.hp - damage);
      const gained = addTp(v.boss, tpFromDamageDealt(damage));
      heroPlay(targetIdx, "damaged");
      v.heroFlashIdx = targetIdx;
      v.heroFlash++;
      v.shake++;
      addFloat(targetIdx, `-${damage}${crit ? "!!" : ""}`, crit ? "crit" : "dmg");
      log(`* ${bossAsset.data.name} attacks ${target.data.name}!`, "info");
      log(`* ${target.data.name} takes ${damage} damage${crit ? " (CRIT!)" : ""}!`, "damage");
      if (gained > 0) log(`* ${bossAsset.data.name} gains ${gained} TP.`, "tp");
      if (target.hp <= 0) {
        log(`* ${target.data.name} is DOWN!`, "system");
        addTp(v.boss, 10);
        heroLoop(targetIdx, "killed");
      }
      sfx.hit();
      void endBossAction();
    }, 380);
  }

  function bossDefend() {
    v.boss.defending = true;
    const gained = addTp(v.boss, 8);
    bossLoop("defend");
    log(`* ${bossAsset.data.name} defends (+DEF) and gains ${gained} TP.`, "tp");
    sfx.tp();
    void endBossAction();
  }

  function useAbility(abAsset: Asset<AbilityData>, targetIdx?: number) {
    const ab = abAsset.data;
    const token = runToken.current;
    if (v.boss.tp < ab.tpCost) return;
    if ((v.boss.cooldowns[abAsset.id] ?? 0) > 0) return;
    v.boss.tp -= ab.tpCost;
    if (ab.cooldown > 0) v.boss.cooldowns[abAsset.id] = ab.cooldown + 1;
    if (targetIdx !== undefined) lastTargetRef.current = targetIdx;

    if (ab.effect === "bullet" && ab.attackId) {
      const atk = store.resolveAttack(ab.attackId);
      if (atk) {
        v.pendingAbility = abAsset;
        v.pendingAttack = atk.data;
        v.phase = "soul";
        bossPlay(`ability:${abAsset.id}`);
        v.dialogue = `* ${bossAsset.data.name} unleashes ${ab.name}!`;
        log(`* ${bossAsset.data.name} uses ${ab.name}!`, "info");
        sfx.warn();
        sync();
        return;
      }
      v.boss.tp += ab.tpCost;
      sync();
      return;
    }

    v.phase = "heroes";
    v.dialogue = "";
    log(`* ${bossAsset.data.name} uses ${ab.name}!`, "info");
    v.bossLunge++;
    bossPlay(`ability:${abAsset.id}`);
    sync();
    sfx.confirm();

    setTimeout(() => {
      if (runToken.current !== token) return;
      applyDirectAbility(abAsset, targetIdx);
      void endBossAction();
    }, 420);
  }

  function applyDirectAbility(abAsset: Asset<AbilityData>, targetIdx?: number) {
    const ab = abAsset.data;
    const targets: HeroInstance[] = [];
    if (ab.target === "hero") {
      const t = v.heroes[targetIdx ?? 0];
      if (t && t.hp > 0) targets.push(t);
    } else if (ab.target === "random") {
      const alive = aliveHeroes();
      if (alive.length) {
        const pick = alive[Math.floor(Math.random() * alive.length)].i;
        lastTargetRef.current = pick;
        targets.push(v.heroes[pick]);
      }
    } else if (ab.target === "all") {
      for (const h of v.heroes) if (h.hp > 0) targets.push(h);
    }

    if (ab.effect === "heal") {
      const { heal } = resolveAbilityPower(v.boss, ab);
      v.boss.hp = Math.min(v.boss.data.stats.maxHp, v.boss.hp + heal);
      addFloat("boss", `+${heal}`, "heal");
      log(`* ${bossAsset.data.name} restores ${heal} HP!`, "heal");
      sfx.heal();
    } else if (ab.effect === "buff") {
      if (ab.buffStat === "attack") {
        v.boss.atkMod += ab.buffAmount;
        v.boss.atkModTurns = Math.max(v.boss.atkModTurns, ab.buffDuration);
      } else {
        v.boss.defMod += ab.buffAmount;
        v.boss.defModTurns = Math.max(v.boss.defModTurns, ab.buffDuration);
      }
      log(`* ${bossAsset.data.name}'s ${ab.buffStat.toUpperCase()} rose for ${ab.buffDuration} turns!`, "tp");
      sfx.tp();
    } else if (ab.effect === "debuff") {
      for (const h of aliveHeroes()) {
        h.h.atkMod += ab.buffAmount;
        h.h.atkModTurns = Math.max(h.h.atkModTurns, ab.buffDuration);
      }
      log(`* The heroes' ${ab.buffStat.toUpperCase()} fell for ${ab.buffDuration} turns!`, "tp");
      sfx.tp();
    } else if (ab.effect === "damage" || ab.effect === "drain") {
      let total = 0;
      for (const t of targets) {
        const { damage, crit } = resolveAbilityPower(v.boss, ab, t);
        t.hp = Math.max(0, t.hp - damage);
        total += damage;
        const idx = v.heroes.indexOf(t);
        lastDamagedRef.current = idx;
        heroPlay(idx, "damaged");
        v.heroFlashIdx = idx;
        v.heroFlash++;
        addFloat(idx, `-${damage}${crit ? "!!" : ""}`, crit ? "crit" : "dmg");
        log(`* ${t.data.name} takes ${damage} damage${crit ? " (CRIT!)" : ""}!`, "damage");
        if (t.hp <= 0) {
          log(`* ${t.data.name} is DOWN!`, "system");
          addTp(v.boss, 10);
          heroLoop(idx, "killed");
        }
      }
      if (total > 0) {
        addTp(v.boss, tpFromDamageDealt(total));
        v.shake++;
        sfx.hit();
        if (ab.effect === "drain" && ab.drainHeal > 0) {
          const heal = Math.round(total * ab.drainHeal);
          v.boss.hp = Math.min(v.boss.data.stats.maxHp, v.boss.hp + heal);
          addFloat("boss", `+${heal}`, "heal");
          log(`* ${bossAsset.data.name} drains ${heal} HP!`, "heal");
        }
      }
    }
    sync();
  }

  function onSoulEnd(r: SoulPhaseResult) {
    const token = runToken.current;
    const abName = v.pendingAbility?.data.name ?? "ATTACK";
    let total = r.damage;
    if (r.soulDown) total += Math.round(bossAttack(v.boss) * 1.5);
    v.pendingAttack = null;
    v.pendingAbility = null;
    v.phase = "heroes";
    v.dialogue = "";
    log(`* SOUL took ${r.damage} damage across ${r.hits} hit${r.hits === 1 ? "" : "s"}!`, "damage");
    if (r.soulDown) log(`* SOUL DOWN! The heroes are shattered for bonus damage!`, "system");
    const alive = aliveHeroes();
    if (total > 0 && alive.length) {
      const share = Math.max(1, Math.ceil(total / alive.length));
      for (const { h, i } of alive) {
        const dealt = Math.min(h.hp, share);
        h.hp = Math.max(0, h.hp - share);
        lastDamagedRef.current = i;
        heroPlay(i, "damaged");
        addFloat(i, `-${dealt}`, "dmg");
        if (h.hp <= 0) {
          log(`* ${h.data.name} is DOWN!`, "system");
          addTp(v.boss, 10);
          heroLoop(i, "killed");
        }
      }
      const gained = addTp(v.boss, tpFromDamageDealt(total));
      if (gained > 0) log(`* ${bossAsset.data.name} gains ${gained} TP.`, "tp");
      v.shake += 2;
      sfx.hit();
    } else {
      log(`* The SOUL dodged ${abName} flawlessly!`, "info");
    }
    sync();
    setTimeout(() => {
      if (runToken.current !== token) return;
      void endBossAction();
    }, 700);
  }

  // ---------------- boss theme music ----------------

  const themeRef = useRef<HTMLAudioElement | null>(null);

  function stopTheme() {
    themeRef.current?.pause();
  }

  useEffect(() => {
    const row = bossAsset.data.themeId ? store.get(bossAsset.data.themeId) : undefined;
    const url = (row?.data as SoundData | undefined)?.dataUrl;
    if (!url) return;
    const a = new Audio(url);
    a.loop = true;
    a.volume = 0.55;
    themeRef.current = a;
    const tryPlay = () => {
      if (a.paused) a.play().catch(() => {});
    };
    tryPlay();
    window.addEventListener("pointerdown", tryPlay);
    window.addEventListener("keydown", tryPlay);
    return () => {
      window.removeEventListener("pointerdown", tryPlay);
      window.removeEventListener("keydown", tryPlay);
      a.pause();
      themeRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------------- entity animations & particles ----------------

  const sceneRef = useRef<HTMLDivElement | null>(null);
  const bossElRef = useRef<HTMLDivElement | null>(null);
  const bossInnerRef = useRef<HTMLDivElement | null>(null);
  const heroElsRef = useRef<(HTMLDivElement | null)[]>([]);
  const partCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const lastDamagedRef = useRef(0);
  const lastTargetRef = useRef(0);
  const psRef = useRef(new ParticleSystem());
  const envAccRef = useRef(0);
  const aiAccRef = useRef(0);
  const afterimagesRef = useRef<{ spriteId: string; x: number; y: number; age: number }[]>([]);
  const fxStateRef = useRef(new Map<string, { last: number; burst: boolean; acc: number }>());
  const runsRef = useRef<Record<string, Run>>({});
  const framesRef = useRef<Record<string, string | null>>({});
  const [frames, setFrames] = useState<Record<string, string | null>>({});

  const bossAnims = () => bossAsset.data.animations;
  const heroAnims = (i: number) => heroCfgsRef.current[i]?.animations;

  function startRun(key: string, id: string | undefined, loop: boolean) {
    if (!id) {
      if (runsRef.current[key]) delete runsRef.current[key];
      if (framesRef.current[key] !== null) {
        framesRef.current[key] = null;
        setFrames({ ...framesRef.current });
      }
      return;
    }
    const row = store.get(id);
    if (!row) return;
    const data = row.data as AnimationData;
    if (!data.frames.length) return;
    runsRef.current[key] = { anim: data, t: 0, loop, spawned: new Set() };
  }

  function bossLoop(trig: string) {
    startRun("boss", bossAnims()?.[trig], true);
  }
  function bossPlay(trig: string) {
    const id = bossAnims()?.[trig];
    if (!id) return;
    startRun("boss", id, false);
  }
  function heroLoop(i: number, trig: string) {
    startRun(`hero:${i}`, heroAnims(i)?.[trig], true);
  }
  function heroPlay(i: number, trig: string) {
    const id = heroAnims(i)?.[trig];
    if (!id) return;
    startRun(`hero:${i}`, id, false);
  }

  function resumeLoop(key: string) {
    if (key === "boss") {
      bossLoop(v.boss.defending ? "defend" : "idle");
    } else {
      const i = parseInt(key.split(":")[1], 10);
      const h = v.heroes[i];
      if (!h) return;
      if (h.hp <= 0) heroLoop(i, "killed");
      else if (h.defending) heroLoop(i, "defend");
      else heroLoop(i, "idle");
    }
  }

  function anchorPos(anchor: ParticleAnchor): { x: number; y: number } | null {
    const scene = sceneRef.current;
    if (!scene) return null;
    const s = scene.getBoundingClientRect();
    const rel = (el: Element | null) => {
      if (!el) return null;
      const r = el.getBoundingClientRect();
      return { x: r.left - s.left + r.width / 2, y: r.top - s.top + r.height / 2 };
    };
    switch (anchor) {
      case "boss":
        return rel(bossElRef.current);
      case "hero1":
        return rel(heroElsRef.current[0]);
      case "hero2":
        return rel(heroElsRef.current[1]);
      case "hero3":
        return rel(heroElsRef.current[2]);
      case "hero4":
        return rel(heroElsRef.current[3]);
      case "target":
        return rel(heroElsRef.current[lastTargetRef.current]) ?? rel(bossElRef.current);
      case "lastDamaged":
        return rel(heroElsRef.current[lastDamagedRef.current]) ?? rel(bossElRef.current);
      case "randomHero": {
        const aliveIdx = v.heroes.map((h, i) => (h.hp > 0 ? i : -1)).filter((i) => i >= 0);
        if (!aliveIdx.length) return rel(bossElRef.current);
        return rel(heroElsRef.current[aliveIdx[Math.floor(Math.random() * aliveIdx.length)]]);
      }
      case "center":
        return { x: s.width / 2, y: s.height / 2 };
      case "top":
        return { x: s.width / 2, y: 40 };
      case "bottom":
        return { x: s.width / 2, y: s.height - 40 };
    }
  }

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      let changed = false;
      for (const key of Object.keys(runsRef.current)) {
        const run = runsRef.current[key];
        run.t += dt;
        for (const em of run.anim.emitters) {
          if (run.t >= em.spawnAt && !run.spawned.has(em.id)) {
            run.spawned.add(em.id);
            const p = anchorPos(em.anchor);
            if (p) psRef.current.spawnEmitter(em, p.x, p.y);
          }
        }
        const total = run.anim.frames.reduce((s2, f) => s2 + f.duration, 0);
        if (run.t >= total) {
          if (run.loop) {
            run.t = 0;
            run.spawned.clear();
          } else {
            delete runsRef.current[key];
            framesRef.current[key] = null;
            changed = true;
            resumeLoop(key);
            continue;
          }
        }
        let t = run.t;
        let sid: string | null = run.anim.frames[0]?.spriteId ?? null;
        for (const f of run.anim.frames) {
          if (t < f.duration) {
            sid = f.spriteId;
            break;
          }
          t -= f.duration;
        }
        if (framesRef.current[key] !== sid) {
          framesRef.current[key] = sid;
          changed = true;
        }
      }
        if (changed) setFrames({ ...framesRef.current });

      // ---- ambient environment effects (fire ground / snow) ----
      envAccRef.current += dt;
      const effect = bossAsset.data.bgEffect;
      if (effect === "fire" && envAccRef.current >= 0.14) {
        envAccRef.current = 0;
        const scene = sceneRef.current;
        if (scene) {
          psRef.current.particles.push({
            x: Math.random() * scene.clientWidth,
            y: scene.clientHeight + 8,
            vx: (Math.random() - 0.5) * 24,
            vy: -(50 + Math.random() * 90),
            rot: Math.random() * 360,
            vr: 60,
            g: -10,
            life: 1.1 + Math.random() * 0.7,
            max: 1.6,
            scale: 1.5 + Math.random() * 1.5,
            spriteId: "fireball",
            fade: true,
          });
        }
      } else if (effect === "snow" && envAccRef.current >= 0.16) {
        envAccRef.current = 0;
        const scene = sceneRef.current;
        if (scene) {
          psRef.current.particles.push({
            x: Math.random() * (scene.clientWidth + 200),
            y: -8,
            vx: -(14 + Math.random() * 22),
            vy: 26 + Math.random() * 26,
            rot: 0,
            vr: 30,
            g: 0,
            life: 6 + Math.random() * 4,
            max: 9,
            scale: 1 + Math.random(),
            spriteId: "spark",
            fade: true,
          });
        }
      }

      // ---- persistent boss effects (HP-gated) ----
      const hpPct = (v.boss.hp / v.boss.data.stats.maxHp) * 100;
      for (const ef of bossAsset.data.effects ?? []) {
        let st = fxStateRef.current.get(ef.id);
        if (!st) {
          st = { last: 0, burst: false, acc: 0 };
          fxStateRef.current.set(ef.id, st);
        }
        const active = hpPct >= ef.hpMin && hpPct <= ef.hpMax && v.boss.hp > 0;
        if (!active) {
          st.burst = false;
          continue;
        }
        // inner ref includes the glide/bob transform, so effects track the real sprite
        const rect = (bossInnerRef.current ?? bossElRef.current)?.getBoundingClientRect();
        const sceneRect = sceneRef.current?.getBoundingClientRect();
        if (!rect || !sceneRect) continue;
        const cx = rect.left - sceneRect.left + rect.width / 2 + ef.ax * rect.width;
        const cy = rect.top - sceneRect.top + rect.height / 2 + ef.ay * rect.height;
        if (ef.mode === "burst") {
          if (!st.burst) {
            st.burst = true;
            psRef.current.spawnEmitter(
              { ...ef, spawnAt: 0, despawnAt: null, anchor: "boss" } as unknown as Parameters<ParticleSystem["spawnEmitter"]>[0],
              cx,
              cy
            );
          }
        } else {
          st.acc += dt;
          const interval = Math.max(0.02, ef.interval);
          while (st.acc >= interval) {
            st.acc -= interval;
            for (let n = 0; n < ef.count; n++) {
              const ang = Math.random() * Math.PI * 2;
              const sp = ef.outward ? ef.speed * (0.4 + Math.random() * 0.8) : 0;
              psRef.current.particles.push({
                x: cx + (Math.random() - 0.5) * ef.spread * 2,
                y: cy + (Math.random() - 0.5) * ef.spread * 2,
                vx: Math.cos(ang) * sp + ef.driftX,
                vy: Math.sin(ang) * sp + ef.driftY,
                rot: Math.random() * 360,
                vr: ef.rotSpeed,
                g: ef.gravity,
                life: ef.lifetime * (0.7 + Math.random() * 0.6),
                max: ef.lifetime,
                scale: ef.scale,
                spriteId: ef.spriteId,
                fade: ef.fade,
              });
            }
          }
        }
      }

      // ---- afterimages ----
      if (bossAsset.data.afterimages && v.boss.hp > 0) {
        aiAccRef.current += dt;
        if (aiAccRef.current >= 0.1) {
          aiAccRef.current = 0;
          // capture the ACTUAL sprite position (glide transform included)
          const rect = (bossInnerRef.current ?? bossElRef.current)?.getBoundingClientRect();
          const sceneRect = sceneRef.current?.getBoundingClientRect();
          if (rect && sceneRect) {
            afterimagesRef.current.push({
              spriteId: framesRef.current["boss"] ?? bossAsset.data.spriteId,
              x: rect.left - sceneRect.left + rect.width / 2,
              y: rect.top - sceneRect.top + rect.height / 2,
              age: 0,
            });
            if (afterimagesRef.current.length > 12) afterimagesRef.current.shift();
          }
        }
      }
      for (let i = afterimagesRef.current.length - 1; i >= 0; i--) {
        afterimagesRef.current[i].age += dt;
        if (afterimagesRef.current[i].age > 0.7) afterimagesRef.current.splice(i, 1);
      }

      psRef.current.update(dt);
      const canvas = partCanvasRef.current;
      const scene = sceneRef.current;
      if (canvas && scene) {
        if (canvas.width !== scene.clientWidth || canvas.height !== scene.clientHeight) {
          canvas.width = scene.clientWidth;
          canvas.height = scene.clientHeight;
        }
        const ctx = canvas.getContext("2d")!;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // afterimages: faded clones gliding right
        for (const ai of afterimagesRef.current) {
          const sprite = resolveSprite(ai.spriteId, store.spriteData(ai.spriteId));
          if (sprite.h > 0) {
            const scale = (bossAsset.data.spriteSize ?? 150) / sprite.h;
            drawSpriteAt(ctx, sprite, ai.x + ai.age * 60, ai.y, scale, 0, Math.max(0, 1 - ai.age / 0.7) * 0.45);
          }
        }
        psRef.current.render(ctx, (id) => store.spriteData(id));
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    bossLoop("idle");
    for (let i = 0; i < v.heroes.length; i++) {
      if (v.heroes[i].hp > 0) heroLoop(i, "idle");
    }
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------------- keyboard ----------------

  useEffect(() => {
    start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const p = v.phase;
      const menu = ["FIGHT", "SKILL", "DEFEND", "ITEM"];
      if (p === "bossMenu") {
        if (e.key === "ArrowDown" || e.key === "ArrowRight") {
          v.menuIdx = (v.menuIdx + 1) % 4;
          sfx.move();
          sync();
        } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
          v.menuIdx = (v.menuIdx + 3) % 4;
          sfx.move();
          sync();
        } else if (e.key === "Enter" || e.key.toLowerCase() === "z") {
          confirmMenu(menu[v.menuIdx]);
        }
      } else if (p === "target") {
        const alive = aliveHeroes();
        if (!alive.length) return;
        const curPos = Math.max(0, alive.findIndex((x) => x.i === v.targetIdx));
        if (e.key === "ArrowDown" || e.key === "ArrowRight") {
          v.targetIdx = alive[(curPos + 1) % alive.length].i;
          sfx.move();
          sync();
        } else if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
          v.targetIdx = alive[(curPos + alive.length - 1) % alive.length].i;
          sfx.move();
          sync();
        } else if (e.key === "Enter" || e.key.toLowerCase() === "z") {
          if (v.targetMode === "fight") bossFight(v.targetIdx);
          else if (v.pendingAbility) useAbility(v.pendingAbility, v.targetIdx);
        } else if (e.key === "Escape" || e.key.toLowerCase() === "x") {
          v.phase = v.targetMode === "fight" ? "bossMenu" : "abilities";
          v.pendingAbility = null;
          sfx.cancel();
          sync();
        }
      } else if (p === "abilities") {
        const abs = bossAbilities();
        if (!abs.length) return;
        if (e.key === "ArrowDown") {
          v.abilityIdx = (v.abilityIdx + 1) % abs.length;
          sfx.move();
          sync();
        } else if (e.key === "ArrowUp") {
          v.abilityIdx = (v.abilityIdx + abs.length - 1) % abs.length;
          sfx.move();
          sync();
        } else if (e.key === "Enter" || e.key.toLowerCase() === "z") {
          activateAbility(abs[v.abilityIdx]);
        } else if (e.key === "Escape" || e.key.toLowerCase() === "x") {
          v.phase = "bossMenu";
          sfx.cancel();
          sync();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function bossAbilities(): Asset<AbilityData>[] {
    return v.boss.data.abilityIds
      .map((id) => store.resolveAbility(id))
      .filter((a): a is Asset<AbilityData> => !!a);
  }

  function confirmMenu(item: string) {
    if (item === "FIGHT") {
      v.targetMode = "fight";
      v.phase = "target";
      const alive = aliveHeroes();
      if (alive.length) v.targetIdx = alive[0].i;
      sfx.select();
      sync();
    } else if (item === "SKILL") {
      v.phase = "abilities";
      v.abilityIdx = 0;
      sfx.select();
      sync();
    } else if (item === "DEFEND") {
      bossDefend();
    } else if (item === "ITEM") {
      v.dialogue = "* Your pockets are empty. The heroes smirk.";
      log("* No items. Perhaps next time.", "info");
      sfx.cancel();
      sync();
    }
  }

  function activateAbility(abAsset: Asset<AbilityData>) {
    const ab = abAsset.data;
    const cd = v.boss.cooldowns[abAsset.id] ?? 0;
    if (v.boss.tp < ab.tpCost || cd > 0) {
      sfx.cancel();
      return;
    }
    sfx.select();
    if (ab.target === "hero" && ab.effect !== "bullet") {
      v.targetMode = "ability";
      v.pendingAbility = abAsset;
      v.phase = "target";
      const alive = aliveHeroes();
      if (alive.length) v.targetIdx = alive[0].i;
      sync();
    } else {
      useAbility(abAsset);
    }
  }

  function rematch() {
    runToken.current++;
    Object.assign(S.current, initState());
    runsRef.current = {};
    framesRef.current = {};
    setFrames({});
    psRef.current.clear();
    heroCfgsRef.current = heroIds.map((id) => resolveHeroCfg(id));
    const t = themeRef.current;
    if (t) {
      t.currentTime = 0;
      t.play().catch(() => {});
    }
    sync();
    start();
    bossLoop("idle");
    for (let i = 0; i < v.heroes.length; i++) heroLoop(i, "idle");
  }

  // ============================================================
  // render
  // ============================================================

  const bossPct = v.boss.hp / v.boss.data.stats.maxHp;
  const tpPct = v.boss.tp / Math.max(1, v.boss.data.stats.maxTp);
  const menuItems = ["FIGHT", "SKILL", "DEFEND", "ITEM"] as const;
  const menuIcons = [ICONS.fight, ICONS.skill, ICONS.defend, ICONS.item];
  const abs = bossAbilities();
  const alive = aliveHeroes();

  const bg = bgVisual(bossAsset.data.background, bossAsset.data.bgColor);
  const bgEffect = bossAsset.data.bgEffect ?? "none";
  const fxColor = bossAsset.data.bgEffectColor ?? "#46e6a0";
  const layout = bossAsset.data.layout;
  const bossPos = layout?.boss ?? DEFAULT_BOSS_POS;
  const bossHover = bossAsset.data.hover ?? true;

  const heroSpriteFor = (i: number) => {
    const cfg = heroCfgsRef.current[i];
    return frames[`hero:${i}`] ?? cfg?.spriteId ?? v.heroes[i].data.spriteId;
  };

  return (
    <div className="h-screen min-h-[560px] bg-black flex flex-col select-none overflow-hidden font-ui">
      {/* ============ BATTLE SCENE ============ */}
      <div ref={sceneRef} className={`relative flex-1 min-h-0 ${bg.className ?? ""}`} style={bg.style}>
        {/* background effect overlay */}
        {bgEffect !== "none" && (
          <div
            className={`absolute inset-0 pointer-events-none bgfx-${bgEffect}`}
            style={{ "--fx": fxColor } as React.CSSProperties}
          />
        )}
        {/* floor */}
        {(bossAsset.data.floor ?? "default") !== "none" &&
          (bossAsset.data.floor?.startsWith("sprite:") ? (
            <div
              className="absolute left-0 right-0 bottom-0 pointer-events-none pixelated"
              style={{
                height: "24%",
                backgroundImage: `url(${floorUrl(bossAsset.data.floor) ?? ""})`,
                backgroundRepeat: "repeat-x",
                backgroundSize: "auto 100%",
                backgroundPosition: "bottom",
                imageRendering: "pixelated",
              }}
            />
          ) : (
            <div
              className="absolute left-0 right-0 bottom-0 pointer-events-none"
              style={{
                height: "24%",
                background: "linear-gradient(180deg, #141022 0%, #0a0812 30%, #050408 100%)",
                borderTop: `3px solid ${bossAsset.data.bgColor ? `${bossAsset.data.bgColor}66` : "#2a2440"}`,
              }}
            />
          ))}
        {/* particle overlay */}
        <canvas ref={partCanvasRef} className="absolute inset-0 z-10 pointer-events-none" />

        <div key={v.shake} className={`absolute inset-0 ${v.shake > 0 ? "anim-shake" : ""}`}>
          {/* top mini bar */}
          <div className="absolute top-2 left-2 right-2 flex items-center gap-3 text-lg z-20">
            <button className="pixel-btn !py-0.5 !px-2 !text-base" onClick={() => router.push("/")}>
              ✕ EXIT
            </button>
            <span className="text-[#8a7fa0]">ROUND {v.round}</span>
            <span className="flex-1" />
            <span className="text-[#8a7fa0] font-display text-[9px] hidden md:block">
              {bossAsset.data.name.toUpperCase()} VS THE FUN GANG
            </span>
            <span className="flex-1" />
            <button
              className="pixel-btn !py-0.5 !px-2 !text-base"
              onClick={() => {
                v.logOpen = !v.logOpen;
                sync();
              }}
            >
              LOG {v.logOpen ? "ON" : "OFF"}
            </button>
          </div>

          {/* battle log overlay */}
          {v.logOpen && (
            <div className="absolute top-10 right-2 w-80 max-h-48 overflow-auto bg-black/85 border-2 border-[#3a3a55] p-2 text-base leading-tight z-20">
              {v.log.slice(-12).map((l) => (
                <div
                  key={l.id}
                  className={
                    l.tone === "damage"
                      ? "text-[#ff8090]"
                      : l.tone === "heal"
                      ? "text-[#46e6a0]"
                      : l.tone === "tp"
                      ? "text-[#46e6ff]"
                      : l.tone === "system"
                      ? "text-[#ffe14d]"
                      : "text-[#c9c9d9]"
                  }
                >
                  {l.text}
                </div>
              ))}
            </div>
          )}

          {/* vertical TP gauge */}
          <div className="absolute left-3 top-1/2 -translate-y-1/2 flex flex-col items-center gap-1 z-10">
            <span className="font-display text-[10px] text-[#ffe14d] [writing-mode:vertical-rl] tracking-widest">TP</span>
            <div className="relative w-4 h-44 bg-black border-2 border-[#6b5a1a]">
              <div
                className="absolute bottom-0 left-0 right-0 bg-[#ffe14d] transition-[height] duration-300"
                style={{ height: `${Math.min(100, tpPct * 100)}%` }}
              />
              {tpPct >= 1 && <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-6 h-1 bg-white anim-blink" />}
            </div>
            <span className="text-[#ffe14d] text-sm">
              {v.boss.tp}/{v.boss.data.stats.maxTp}
            </span>
          </div>

          {/* -------- hero party (data-driven positions) -------- */}
          {v.heroes.map((h, i) => {
            const dead = h.hp <= 0;
            const cfg = heroCfgsRef.current[i];
            const hover = cfg?.hover ?? true;
            const pos = layout?.heroes?.[i] ?? DEFAULT_HERO_POS[i] ?? DEFAULT_HERO_POS[0];
            return (
              <div
                key={h.data.id}
                ref={(el) => void (heroElsRef.current[i] = el)}
                className="absolute z-10"
                style={{
                  left: `${pos.x}%`,
                  top: `${pos.y}%`,
                  transform: `translate(-50%, ${hover ? "-50%" : "-100%"})`,
                }}
              >
                <div
                  key={`${v.heroFlash}-${i}-${v.heroLunge}`}
                  className={`${v.heroFlashIdx === i && v.heroFlash > 0 ? "anim-hitflash" : ""} ${
                    v.heroLungeIdx === i && v.heroLunge > 0 ? "anim-lunge-up" : ""
                  } ${dead && !frames[`hero:${i}`] ? "grayscale opacity-50" : ""} ${!dead && hover ? "anim-bob" : ""}`}
                >
                  <SpriteView spriteId={heroSpriteFor(i)} spriteData={store.spriteData(heroSpriteFor(i))} scale={5} />
                </div>
                {dead && !frames[`hero:${i}`] && (
                  <div className="absolute inset-0 flex items-center justify-center text-4xl">💀</div>
                )}

                {v.phase === "target" && !dead && (
                  <div className="absolute -top-7 left-1/2 -translate-x-1/2 whitespace-nowrap bg-black/85 border-2 border-white px-2 py-0.5 text-lg text-white z-20">
                    {h.data.name} HP {h.hp}/{h.data.maxHp}
                  </div>
                )}
                {v.phase === "target" && v.targetIdx === i && !dead && (
                  <div className="absolute -left-8 top-1/2 -translate-y-1/2 text-[#ff2040] text-2xl anim-blink z-20">❤</div>
                )}

                {v.floats
                  .filter((f) => f.target === i)
                  .map((f) => (
                    <span
                      key={f.id}
                      className={`dmg-float absolute left-1/2 -top-2 font-display text-base z-30 ${
                        f.tone === "heal" ? "text-[#46e6a0]" : f.tone === "crit" ? "text-[#ffe14d]" : "text-white"
                      }`}
                    >
                      {f.text}
                    </span>
                  ))}
              </div>
            );
          })}

          {/* -------- YOUR BOSS -------- */}
          <div
            ref={bossElRef}
            className="absolute z-10"
            style={{
              left: `${bossPos.x}%`,
              top: `${bossPos.y}%`,
              transform: `translate(-50%, ${bossHover ? "-50%" : "-100%"})`,
            }}
          >
          <div
            ref={bossInnerRef}
            key={`${v.bossLunge}-${v.bossFlash}`}
            className={`${v.bossFlash > 0 ? "anim-hitflash" : ""} ${v.bossLunge > 0 ? "anim-lunge-left" : ""} ${
                bossPct <= 0 && !frames["boss"] ? "grayscale opacity-40" : ""
              } ${bossPct > 0 && bossHover ? "anim-bob-slow" : ""}`}
            >
              <SpriteView
                spriteId={frames["boss"] ?? bossAsset.data.spriteId}
                spriteData={store.spriteData(frames["boss"] ?? bossAsset.data.spriteId)}
                fitHeight={bossAsset.data.spriteSize ?? 150}
              />
            </div>
            {v.floats
              .filter((f) => f.target === "boss")
              .map((f) => (
                <span
                  key={f.id}
                  className={`dmg-float absolute left-1/2 -top-4 font-display text-lg z-30 ${
                    f.tone === "heal" ? "text-[#46e6a0]" : f.tone === "crit" ? "text-[#ffe14d]" : "text-[#ff2040]"
                  }`}
                >
                  {f.text}
                </span>
              ))}
          </div>
        </div>

        {/* soul-phase battle box overlay */}
        {v.phase === "soul" && v.pendingAttack && (
          <SoulPhase
            attack={v.pendingAttack}
            attackPower={bossAttack(v.boss)}
            soulDamageMult={v.boss.data.stats.soulDamageMult}
            difficulty={difficulty}
            onEnd={onSoulEnd}
          />
        )}

        {/* round / turn banners */}
        {v.banner && (
          <div className="absolute inset-0 z-40 flex items-center justify-center pointer-events-none">
            <div className="anim-banner font-display text-lg md:text-2xl text-white bg-black/80 border-4 border-white px-8 py-5">
              {v.banner}
            </div>
          </div>
        )}
      </div>

      {/* ============ BOTTOM UI — belongs to the BOSS ============ */}
      <div className="bg-black border-t-[3px] border-white px-3 pt-2 pb-1 z-20">
        <div className="flex items-stretch gap-4 flex-wrap">
          {/* boss panel */}
          <div className="shrink-0">
            <div className="border-[3px] border-white bg-[#101018] px-2 py-1 flex items-center gap-3 w-[360px]">
              <div className="w-11 h-11 bg-[#12203a] border-2 border-white flex items-center justify-center overflow-hidden">
                <SpriteView spriteId={bossAsset.data.spriteId} spriteData={store.spriteData(bossAsset.data.spriteId)} scale={2} maxHeight={40} />
              </div>
              <div className="flex-1">
                <div className="flex items-end justify-between">
                  <span className="font-display text-[10px] text-white">{bossAsset.data.name.toUpperCase()}</span>
                  <span className="text-lg text-white leading-4">
                    {Math.max(0, v.boss.hp)}/ {v.boss.data.stats.maxHp}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm text-[#9a9ab8]">HP</span>
                  <HpBar hp={v.boss.hp} max={v.boss.data.stats.maxHp} height={8} />
                </div>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-sm text-[#9a9ab8]">ATK</span>
                  <span className="text-base text-white leading-4">
                    {bossAttack(v.boss)}
                    {v.boss.atkMod !== 0 ? ` (${v.boss.atkMod > 0 ? "+" : ""}${v.boss.atkMod})` : ""}
                  </span>
                  <span className="text-sm text-[#9a9ab8] ml-2">DEF</span>
                  <span className="text-base text-white leading-4">
                    {v.boss.data.stats.defense + v.boss.defMod + (v.boss.defending ? 8 : 0)}
                    {v.boss.defending ? " 🛡" : ""}
                  </span>
                </div>
              </div>
            </div>
            {/* command buttons */}
            <div className="flex gap-1.5 mt-1.5">
              {menuItems.map((m, i) => (
                <button
                  key={m}
                  disabled={v.phase !== "bossMenu"}
                  onMouseEnter={() => {
                    if (v.phase === "bossMenu") {
                      v.menuIdx = i;
                      sync();
                    }
                  }}
                  onClick={() => v.phase === "bossMenu" && confirmMenu(m)}
                  className={`cmd-btn ${v.phase === "bossMenu" && v.menuIdx === i ? "cmd-sel" : ""}`}
                >
                  {menuIcons[i]}
                  <span>{m}</span>
                </button>
              ))}
            </div>
          </div>

          {/* hero HP panels */}
          <div className="flex-1 flex items-center gap-5 flex-wrap min-w-0">
            {v.heroes.map((h, i) => {
              const dead = h.hp <= 0;
              return (
                <div key={h.data.id} className={`flex items-center gap-2 ${dead ? "opacity-40 grayscale" : ""}`}>
                  <SpriteView spriteId={heroSpriteFor(i)} spriteData={store.spriteData(heroSpriteFor(i))} scale={2} maxHeight={36} />
                  <span className="font-display text-[9px] text-white">{h.data.name}</span>
                  <span className="text-sm text-[#9a9ab8]">HP</span>
                  <div className="w-24">
                    <HpBar hp={h.hp} max={h.data.maxHp} color={HERO_BAR_COLOR[h.data.id] ?? "#46e6a0"} height={8} />
                  </div>
                  <span className="text-lg text-white whitespace-nowrap">
                    {Math.max(0, h.hp)}/ {h.data.maxHp}
                  </span>
                  {h.defending && <span className="text-base">🛡</span>}
                  {h.atkModTurns > 0 && h.atkMod < 0 && <span className="text-base text-[#c77dff]">▼</span>}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* ============ DIALOGUE BOX ============ */}
      <div className="mx-3 mb-3 mt-2 min-h-[110px] text-[1.6rem] leading-snug px-1 z-10">
        {v.phase === "abilities" ? (
          <div>
            <div className="pixel-label mb-1">SKILL — TP {v.boss.tp}</div>
            {abs.length === 0 && <div className="text-[#9a9ab8]">* No abilities assigned to this boss.</div>}
            <div className="flex flex-col">
              {abs.map((a, i) => {
                const cd = v.boss.cooldowns[a.id] ?? 0;
                const usable = v.boss.tp >= a.data.tpCost && cd === 0;
                return (
                  <button
                    key={a.id}
                    onMouseEnter={() => (v.abilityIdx = i)}
                    onClick={() => activateAbility(a)}
                    className={`text-left py-0.5 cursor-pointer ${!usable ? "opacity-40" : ""} ${
                      v.abilityIdx === i ? "menu-cursor text-[#ffe14d]" : "text-white"
                    }`}
                  >
                    {a.data.name} <span className="text-[#46e6a0]">{a.data.tpCost}TP</span>
                    {cd > 0 && <span className="text-[#ff2040]"> CD{cd}</span>}
                    {a.data.effect === "bullet" && <span className="text-[#c77dff]"> ✦SOUL ATTACK</span>}
                  </button>
                );
              })}
            </div>
            <div className="text-base text-[#7a7a96] mt-1">X / ESC — BACK · Z / ENTER — USE</div>
          </div>
        ) : v.phase === "target" ? (
          <div>
            <div className="pixel-label mb-1">{v.targetMode === "fight" ? "WHO WILL YOU ATTACK?" : "CHOOSE A TARGET"}</div>
            <div className="flex flex-col">
              {alive.map(({ h, i }) => (
                <button
                  key={i}
                  onMouseEnter={() => (v.targetIdx = i)}
                  onClick={() => (v.targetMode === "fight" ? bossFight(i) : v.pendingAbility && useAbility(v.pendingAbility, i))}
                  className={`text-left py-0.5 cursor-pointer ${v.targetIdx === i ? "menu-cursor text-[#ffe14d]" : "text-white"}`}
                >
                  {h.data.name} <span className="text-[#9a9ab8]">HP {h.hp}/{h.data.maxHp}</span>
                </button>
              ))}
            </div>
            <div className="text-base text-[#7a7a96] mt-1">X / ESC — BACK · Z / ENTER — CONFIRM</div>
          </div>
        ) : v.dialogue ? (
          <div className="text-white">{v.dialogue}</div>
        ) : v.phase === "bossMenu" ? (
          <div className="text-white anim-blink">* What will {bossAsset.data.name.toUpperCase()} do?</div>
        ) : null}
      </div>

      {/* ============ WIN / LOSE ============ */}
      {(v.phase === "win" || v.phase === "lose") && (
        <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-4">
          <div className="pixel-panel p-8 text-center max-w-md w-full">
            <div className={`font-display text-2xl mb-4 ${v.phase === "win" ? "text-[#ffe14d]" : "text-[#ff2040]"}`}>
              {v.phase === "win" ? "VICTORY" : "DEFEATED"}
            </div>
            <div className="text-2xl font-ui mb-6">
              {v.phase === "win" ? "* THE HEROES HAVE FALLEN." : "* YOUR BOSS HAS FALLEN..."}
            </div>
            {v.phase === "win" && (
              <SpriteView
                spriteId={bossAsset.data.spriteId}
                spriteData={store.spriteData(bossAsset.data.spriteId)}
                fitHeight={120}
                className="mx-auto anim-bob"
              />
            )}
            <div className="flex flex-col gap-2 mt-6">
              <button className="pixel-btn solid" onClick={rematch}>
                REMATCH
              </button>
              <button className="pixel-btn" onClick={() => router.push(`/bosses/edit?id=${bossAsset.id}`)}>
                EDIT BOSS
              </button>
              <button className="pixel-btn" onClick={() => router.push("/bosses")}>
                RETURN TO CREATOR
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
