"use client";
// ============================================================
// SOUL phase: the attack runs in the battle box while the AI
// SOUL tries to dodge. Uses the same AttackRuntime as the
// editor preview and the headless tester.
// ============================================================

import { useEffect, useRef, useState } from "react";
import type { AttackData, SoulAIDifficulty } from "@/game/types";
import { AttackRuntime } from "@/game/engine";
import { createSoulAI } from "@/game/soulAI";
import { renderScene } from "@/game/renderScene";
import { store } from "@/game/store";
import { sfx } from "@/game/sfx";
import { playObjectSound } from "@/game/soundPlay";

export interface SoulPhaseResult {
  damage: number;
  hits: number;
  survived: boolean;
  soulDown: boolean;
}

const CW = 720;
const CH = 430;

export default function SoulPhase({
  attack,
  attackPower,
  soulDamageMult,
  difficulty,
  onEnd,
}: {
  attack: AttackData;
  attackPower: number;
  soulDamageMult: number;
  difficulty: SoulAIDifficulty;
  onEnd: (r: SoulPhaseResult) => void;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rtRef = useRef<AttackRuntime | null>(null);
  const speedRef = useRef(1);
  const [speed, setSpeed] = useState(1);
  const [hud, setHud] = useState({ time: 0, hp: 160, maxHp: 160, hits: 0 });
  const [flash, setFlash] = useState(0);
  const endedRef = useRef(false);

  useEffect(() => {
    const rt = new AttackRuntime(JSON.parse(JSON.stringify(attack)), {
      attackPower,
      soulDamageMult,
      onHit: () => setFlash((f) => f + 1),
      onSoulDown: () => sfx.hurt(),
      onObjEvent: (type, objId) => {
        const o = attack.objects.find((x) => x.id === objId);
        if (!o) return;
        if (type === "spawn") playObjectSound(o.spawnSound, o.kind === "warning" ? "warn" : "shoot");
        else if (type === "despawn") playObjectSound(o.despawnSound, "fade");
        else playObjectSound(o.hitSound, "soulhit");
      },
    });
    rt.aiUpdate = createSoulAI(difficulty);
    rtRef.current = rt;

    let raf = 0;
    let last = performance.now();
    const tick = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const r = rtRef.current;
      const canvas = canvasRef.current;
      if (r && canvas) {
        if (!r.finished) {
          r.update(dt * speedRef.current);
          setHud({ time: r.time, hp: r.soul.hp, maxHp: r.soul.maxHp, hits: r.hits });
        } else if (!endedRef.current) {
          endedRef.current = true;
          setTimeout(() => {
            onEnd({ damage: r.damageDealt, hits: r.hits, survived: r.soul.alive, soulDown: !r.soul.alive });
          }, 500);
        }
        // draw
        const ctx = canvas.getContext("2d")!;
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        ctx.fillStyle = "#000000";
        ctx.fillRect(0, 0, CW, CH);
        const boxNow = r.boxAt(r.time);
        const scale = Math.min((CW - 30) / boxNow.width, (CH - 30) / boxNow.height);
        const ox = (CW - boxNow.width * scale) / 2;
        const oy = (CH - boxNow.height * scale) / 2;
        ctx.save();
        ctx.translate(ox, oy);
        ctx.scale(scale, scale);
        renderScene(ctx, r, {
          time: r.time,
          spriteLookup: (id) => store.spriteData(id),
          showSoul: true,
          showSoulHp: true,
        });
        ctx.strokeStyle = "#ffffff";
        ctx.lineWidth = 3 / scale;
        ctx.strokeRect(0, 0, boxNow.width, boxNow.height);
        ctx.restore();
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attack]);

  const pct = Math.max(0, hud.hp / Math.max(1, hud.maxHp));

  return (
    <div className="absolute inset-0 z-30 bg-black/85 flex flex-col items-center justify-center gap-3 p-4">
      <div className="font-display text-xs text-[#ffe14d] anim-banner">
        ✦ {attack.name.toUpperCase()} ✦
      </div>
      <div className={`relative ${flash % 2 === 1 ? "anim-shake" : ""}`} key={flash}>
        <canvas ref={canvasRef} width={CW} height={CH} className="max-w-full max-h-[62vh] pixelated" />
      </div>
      <div className="flex items-center gap-6 text-xl font-ui">
        <span className="text-[#9a9ab8]">
          THE SOUL DODGES — <span className="text-white">{difficulty.name}</span> AI
        </span>
        <span className="text-[#ffe14d]">
          {hud.time.toFixed(1)}s / {attack.duration.toFixed(1)}s
        </span>
        <span className={pct > 0.4 ? "text-[#46e6a0]" : "text-[#ff2040]"}>
          SOUL HP {Math.max(0, Math.round(hud.hp))}/{hud.maxHp}
        </span>
        <span className="text-white">HITS {hud.hits}</span>
        <span className="flex gap-1">
          {[1, 2, 4].map((s) => (
            <button
              key={s}
              className={`pixel-btn !py-0.5 !px-2 text-sm ${speed === s ? "solid" : ""}`}
              onClick={() => {
                setSpeed(s);
                speedRef.current = s;
              }}
            >
              {s}×
            </button>
          ))}
        </span>
      </div>
    </div>
  );
}
