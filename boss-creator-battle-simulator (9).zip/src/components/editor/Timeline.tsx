"use client";
// ============================================================
// Timeline: ruler + one track per object with per-channel
// keyframe diamonds. Diamonds are draggable; the playhead is
// scrub-able. Editor state flows down as props.
// ============================================================

import type { AttackData, AttackObject } from "@/game/types";

export interface SelectedKF {
  objId: string;
  channel: "pos" | "rot" | "scale" | "opacity";
  index: number;
}

const CHANNEL_COLORS: Record<string, string> = {
  pos: "#ffe14d",
  rot: "#c77dff",
  scale: "#46e6a0",
  opacity: "#46e6ff",
};

export default function Timeline({
  attack,
  time,
  pxPerSec,
  selectedObjId,
  selectedKF,
  onSelectObject,
  onSelectKF,
  onSeek,
  onKFDragStart,
  onKFDrag,
  onKFDragEnd,
}: {
  attack: AttackData;
  time: number;
  pxPerSec: number;
  selectedObjId: string | null;
  selectedKF: SelectedKF | null;
  onSelectObject: (id: string) => void;
  onSelectKF: (kf: SelectedKF) => void;
  onSeek: (t: number) => void;
  onKFDragStart: () => void;
  onKFDrag: (kf: SelectedKF, newT: number) => void;
  onKFDragEnd: () => void;
}) {
  const width = Math.max(300, attack.duration * pxPerSec + 40);
  const rulerH = 26;
  const rowH = 18;

  return (
    <div className="overflow-x-auto overflow-y-auto max-h-56 border-2 border-[#3a3a55] bg-[#0a0a11] relative">
      <div style={{ width }} className="relative">
        {/* ruler */}
        <div
          className="relative border-b-2 border-[#3a3a55] cursor-ew-resize select-none"
          style={{ height: rulerH }}
          onPointerDown={(e) => {
            // capture the element NOW — React nulls currentTarget after dispatch
            const el = e.currentTarget;
            const seek = (clientX: number) => {
              const rect = el.getBoundingClientRect();
              onSeek(Math.max(0, Math.min(attack.duration, (clientX - rect.left) / pxPerSec)));
            };
            seek(e.clientX);
            const move = (ev: PointerEvent) => seek(ev.clientX);
            const up = () => {
              window.removeEventListener("pointermove", move);
              window.removeEventListener("pointerup", up);
            };
            window.addEventListener("pointermove", move);
            window.addEventListener("pointerup", up);
          }}
        >
          {Array.from({ length: Math.floor(attack.duration * 2) + 1 }, (_, i) => i * 0.5).map((t) => (
            <div
              key={t}
              className="absolute top-0 h-full border-l border-[#3a3a55] text-[#7a7a96]"
              style={{ left: t * pxPerSec }}
            >
              {Number.isInteger(t) && <span className="text-sm pl-1 font-ui">{t}s</span>}
            </div>
          ))}
        </div>

        {/* object tracks */}
        {attack.objects.map((obj) => (
          <ObjectTrack
            key={obj.id}
            obj={obj}
            pxPerSec={pxPerSec}
            rowH={rowH}
            duration={attack.duration}
            selected={selectedObjId === obj.id}
            selectedKF={selectedKF}
            onSelectObject={onSelectObject}
            onSelectKF={onSelectKF}
            onKFDragStart={onKFDragStart}
            onKFDrag={onKFDrag}
            onKFDragEnd={onKFDragEnd}
          />
        ))}
        {attack.objects.length === 0 && (
          <div className="p-3 text-lg text-[#7a7a96]">NO OBJECTS YET — ADD ONE FROM THE LEFT PANEL.</div>
        )}

        {/* playhead */}
        <div
          className="absolute top-0 bottom-0 w-[2px] bg-[#ff2040] pointer-events-none z-10"
          style={{ left: time * pxPerSec }}
        >
          <div className="w-0 h-0 border-l-[5px] border-r-[5px] border-t-[7px] border-l-transparent border-r-transparent border-t-[#ff2040] -ml-1" />
        </div>
      </div>
    </div>
  );
}

function ObjectTrack({
  obj,
  pxPerSec,
  rowH,
  duration,
  selected,
  selectedKF,
  onSelectObject,
  onSelectKF,
  onKFDragStart,
  onKFDrag,
  onKFDragEnd,
}: {
  obj: AttackObject;
  pxPerSec: number;
  rowH: number;
  duration: number;
  selected: boolean;
  selectedKF: SelectedKF | null;
  onSelectObject: (id: string) => void;
  onSelectKF: (kf: SelectedKF) => void;
  onKFDragStart: () => void;
  onKFDrag: (kf: SelectedKF, newT: number) => void;
  onKFDragEnd: () => void;
}) {
  const channels = ["pos", "rot", "scale", "opacity"] as const;
  const end = obj.lifetime == null ? duration : Math.min(duration, obj.start + obj.lifetime);

  function dragKF(e: React.PointerEvent, channel: (typeof channels)[number], index: number) {
    e.stopPropagation();
    e.preventDefault();
    const startX = e.clientX;
    const kf = obj.keyframes[channel][index];
    const origT = kf.t;
    const kfSel: SelectedKF = { objId: obj.id, channel, index };
    onSelectKF(kfSel);
    onKFDragStart();
    const move = (ev: PointerEvent) => {
      const dt = (ev.clientX - startX) / pxPerSec;
      onKFDrag(kfSel, Math.max(0, Math.min(duration, origT + dt)));
    };
    const up = () => {
      onKFDragEnd();
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  }

  return (
    <div
      className={`border-b border-[#222233] cursor-pointer ${selected ? "bg-[#1c1c30]" : ""}`}
      onClick={() => onSelectObject(obj.id)}
    >
      {/* life bar */}
      <div className="relative" style={{ height: rowH }}>
        <div className="absolute top-[3px] text-sm text-[#9a9ab8] pl-1 truncate max-w-40 z-10">{obj.name}</div>
        <div
          className="absolute top-[2px] h-[14px] border border-[#4a4a66] bg-[#23233a]"
          style={{ left: obj.start * pxPerSec, width: Math.max(4, (end - obj.start) * pxPerSec) }}
        />
      </div>
      {/* channel rows */}
      {channels.map((ch) => {
        const kfs = obj.keyframes[ch];
        if (!kfs.length) return null;
        return (
          <div key={ch} className="relative border-t border-[#161622]" style={{ height: 12 }}>
            <span className="absolute left-1 text-[10px] leading-3" style={{ color: CHANNEL_COLORS[ch] }}>
              {ch}
            </span>
            {kfs.map((kf, i) => {
              const isSel = selectedKF?.objId === obj.id && selectedKF.channel === ch && selectedKF.index === i;
              return (
                <div
                  key={i}
                  className="absolute -translate-x-1/2 -translate-y-1/2 top-1/2 cursor-ew-resize"
                  style={{ left: kf.t * pxPerSec }}
                  onPointerDown={(e) => dragKF(e, ch, i)}
                  onClick={(e) => e.stopPropagation()}
                  title={`${ch} @ ${kf.t.toFixed(2)}s`}
                >
                  <div
                    className="w-[9px] h-[9px] rotate-45 border"
                    style={{
                      background: isSel ? "#fff" : CHANNEL_COLORS[ch],
                      borderColor: isSel ? CHANNEL_COLORS[ch] : "#000",
                    }}
                  />
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}
