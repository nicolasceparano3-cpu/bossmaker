"use client";

import { useEffect, useRef, useState, type ReactNode } from "react";
import { resolveSprite, drawSpriteAt, type DrawableSprite } from "@/game/sprites";
import type { SpriteData } from "@/game/types";

// ---------------- form fields ----------------

export function Field({ label, children, className = "" }: { label: string; children: ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="pixel-label block mb-1">{label}</span>
      {children}
    </label>
  );
}

export function NumField({
  label,
  value,
  onCommit,
  min,
  max,
  step = 1,
  className = "",
}: {
  label: string;
  value: number;
  onCommit: (v: number) => void;
  min?: number;
  max?: number;
  step?: number;
  className?: string;
}) {
  const [text, setText] = useState(String(value));
  useEffect(() => setText(String(value)), [value]);
  const commit = () => {
    let v = parseFloat(text);
    if (isNaN(v)) v = value;
    if (min !== undefined) v = Math.max(min, v);
    if (max !== undefined) v = Math.min(max, v);
    setText(String(v));
    if (v !== value) onCommit(v);
  };
  return (
    <Field label={label} className={className}>
      <input
        type="number"
        className="pixel-input"
        value={text}
        min={min}
        max={max}
        step={step}
        onChange={(e) => setText(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => e.key === "Enter" && commit()}
      />
    </Field>
  );
}

export function TextField({
  label,
  value,
  onCommit,
  placeholder,
}: {
  label: string;
  value: string;
  onCommit: (v: string) => void;
  placeholder?: string;
}) {
  const [text, setText] = useState(value);
  useEffect(() => setText(value), [value]);
  return (
    <Field label={label}>
      <input
        className="pixel-input"
        value={text}
        placeholder={placeholder}
        onChange={(e) => setText(e.target.value)}
        onBlur={() => text !== value && onCommit(text)}
        onKeyDown={(e) => e.key === "Enter" && text !== value && onCommit(text)}
      />
    </Field>
  );
}

export function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
}) {
  return (
    <Field label={label}>
      <select className="pixel-input" value={value} onChange={(e) => onChange(e.target.value)}>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </Field>
  );
}

export function CheckField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex items-center gap-2 text-lg leading-none cursor-pointer"
    >
      <span className={`inline-block w-4 h-4 border-2 border-white ${checked ? "bg-[#ffe14d]" : "bg-black"}`} />
      <span>{label}</span>
    </button>
  );
}

// ---------------- modal ----------------

export function Modal({
  title,
  onClose,
  children,
  wide = false,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4" onClick={onClose}>
      <div
        className={`pixel-panel p-4 max-h-[88vh] overflow-auto ${wide ? "w-[min(920px,95vw)]" : "w-[min(520px,95vw)]"}`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-display text-xs text-[#ffe14d]">{title}</h3>
          <button className="pixel-btn !px-2 !py-1" onClick={onClose}>
            X
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

// ---------------- sprite view ----------------

export function SpriteView({
  spriteId,
  spriteData,
  scale = 4,
  fitHeight,
  maxHeight,
  className = "",
  bob = false,
}: {
  spriteId: string;
  spriteData?: SpriteData | null;
  scale?: number;
  /** if set, the sprite is drawn at exactly this pixel height */
  fitHeight?: number;
  /** caps the rendered height so big uploads never blow up menus */
  maxHeight?: number;
  className?: string;
  bob?: boolean;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  // NOTE: canvas width/height are set ONLY here (never as React props).
  // React re-applying the attributes would wipe the drawn pixels.
  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    let sprite: DrawableSprite = resolveSprite(spriteId, spriteData);
    const draw = () => {
      sprite = resolveSprite(spriteId, spriteData);
      let eff = fitHeight && sprite.h > 0 ? fitHeight / sprite.h : scale;
      if (maxHeight && sprite.h > 0) eff = Math.min(eff, maxHeight / sprite.h);
      canvas.width = Math.max(1, Math.round(sprite.w * eff));
      canvas.height = Math.max(1, Math.round(sprite.h * eff));
      const ctx = canvas.getContext("2d")!;
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.scale(eff, eff);
      drawSpriteAt(ctx, sprite, sprite.w / 2, sprite.h / 2, 1, 0, 1);
      ctx.restore();
    };
    draw();
    if (!sprite.ready) {
      const iv = setInterval(() => {
        const s2 = resolveSprite(spriteId, spriteData);
        if (s2.ready) {
          draw();
          clearInterval(iv);
        }
      }, 200);
      return () => clearInterval(iv);
    }
  }, [spriteId, spriteData, scale, fitHeight, maxHeight]);

  return <canvas ref={ref} className={`pixelated ${bob ? "anim-bob" : ""} ${className}`} />;
}

// ---------------- bars ----------------

export function HpBar({ hp, max, color = "#46e6a0", height = 10 }: { hp: number; max: number; color?: string; height?: number }) {
  const pct = Math.max(0, Math.min(1, hp / Math.max(1, max)));
  return (
    <div className="w-full border-2 border-white bg-black" style={{ height: height + 4 }}>
      <div
        className="h-full transition-[width] duration-300"
        style={{ width: `${pct * 100}%`, background: pct > 0.5 ? color : pct > 0.25 ? "#ffe14d" : "#ff2040" }}
      />
    </div>
  );
}

// ---------------- toasts ----------------

let toastFn: ((msg: string) => void) | null = null;

export function toast(msg: string) {
  toastFn?.(msg);
}

export function ToastHost() {
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => {
    toastFn = (m: string) => {
      setMsg(m);
      setTimeout(() => setMsg(null), 1800);
    };
    return () => {
      toastFn = null;
    };
  }, []);
  if (!msg) return null;
  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-[90] pixel-panel px-4 py-2 text-xl text-[#ffe14d]">
      {msg}
    </div>
  );
}

// ---------------- list card ----------------

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`pixel-panel p-3 ${className}`}>{children}</div>;
}
