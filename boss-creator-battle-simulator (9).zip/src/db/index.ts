import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

// IMPORTANT: the database client is created LAZILY. Importing this module must
// never throw, otherwise `next build` ("collecting page data") fails on hosts
// where DATABASE_URL is not configured. When the env var is missing the API
// routes simply 500 and the client store falls back to browser storage.

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

let cachedDb: NodePgDatabase | null = null;

export function getDb(): NodePgDatabase {
  if (cachedDb) return cachedDb;
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    throw new Error("DATABASE_URL is required (set it as an env var on your host)");
  }
  const pool =
    globalForDb.__arenaNextJsPostgresqlPool ?? new Pool({ connectionString: databaseUrl });
  if (process.env.NODE_ENV !== "production") {
    globalForDb.__arenaNextJsPostgresqlPool = pool;
  }
  cachedDb = drizzle(pool);
  return cachedDb;
}

/**
 * Drop-in client. Property access is forwarded to the lazily-created drizzle
 * instance (functions are bound so `this` stays correct).
 */
export const db: NodePgDatabase = new Proxy({} as NodePgDatabase, {
  get(_target, prop) {
    const inst = getDb() as unknown as Record<string | symbol, unknown>;
    const value = inst[prop];
    return typeof value === "function" ? (value as (...a: unknown[]) => unknown).bind(inst) : value;
  },
});
