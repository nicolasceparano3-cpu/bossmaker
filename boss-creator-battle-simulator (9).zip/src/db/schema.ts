import { jsonb, pgTable, text, bigint, index } from "drizzle-orm/pg-core";

/**
 * Generic asset table. Every creation (boss, attack, ability, sprite) is a
 * data-driven asset stored as JSON, so nothing about specific bosses or
 * attacks is hard-coded.
 */
export const assets = pgTable(
  "assets",
  {
    id: text("id").primaryKey(),
    kind: text("kind").notNull(), // 'boss' | 'attack' | 'ability' | 'sprite'
    name: text("name").notNull(),
    data: jsonb("data").notNull(),
    updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
  },
  (t) => [index("assets_kind_idx").on(t.kind)]
);

export type AssetRow = typeof assets.$inferSelect;
