// ============================================================
// Battle-scene backgrounds. Data-driven: bosses store a preset
// id + line color. The VOID GRID preset renders magenta-style
// scanline grids on black (colors editable per boss).
// ============================================================

import type { CSSProperties } from "react";

export interface BattleBgPreset {
  id: string;
  name: string;
}

export const BATTLE_BACKGROUNDS: BattleBgPreset[] = [
  { id: "grid", name: "VOID GRID (EDITABLE LINES)" },
  { id: "green", name: "DARK FIELD (GREEN)" },
  { id: "purple", name: "DARK CASTLE (PURPLE)" },
  { id: "blue", name: "ICE CAVERN (BLUE)" },
];

export const BG_EFFECTS = [
  { value: "none", label: "NONE" },
  { value: "beams", label: "LIGHT BEAMS" },
  { value: "rain", label: "FALLING RAIN" },
  { value: "stars", label: "TWINKLING STARS" },
  { value: "fire", label: "FIRE GROUND (embers rise)" },
  { value: "snow", label: "SNOW (drifts down-left)" },
] as const;

export const DEFAULT_BACKGROUND = "grid";

export function bgVisual(id: string | undefined, color?: string): { className?: string; style?: CSSProperties } {
  switch (id) {
    case "green":
      return { className: "battle-bg-green" };
    case "purple":
      return { className: "battle-bg-purple" };
    case "blue":
      return { className: "battle-bg-blue" };
    default: {
      const c = color || "#ff00ff";
      // lines stay slightly transparent so sprites read clearly
      return {
        style: {
          backgroundColor: "#000000",
          backgroundImage: [
            `repeating-linear-gradient(0deg, ${c}B3 0px, ${c}B3 2px, transparent 2px, transparent 60px)`,
            `repeating-linear-gradient(90deg, ${c}B3 0px, ${c}B3 2px, transparent 2px, transparent 60px)`,
            `repeating-linear-gradient(0deg, ${c}40 0px, ${c}40 1px, transparent 1px, transparent 15px)`,
            `repeating-linear-gradient(90deg, ${c}40 0px, ${c}40 1px, transparent 1px, transparent 15px)`,
          ].join(", "),
        },
      };
    }
  }
}
