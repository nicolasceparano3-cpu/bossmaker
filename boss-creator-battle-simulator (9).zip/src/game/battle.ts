// ============================================================
// Battle simulation data + helpers. Turn orchestration lives in
// the BattleView component; this module holds state shapes and
// pure calculations so they can be tested/reused.
// ============================================================

import type { AbilityData, BossData, HeroAction, HeroData } from "./types";
import { computeDamage, rollCrit, clamp } from "./combat";
import { chooseHeroAction, type HeroAIContext } from "./heroes";
import { TP_GAIN } from "./combat";

export interface HeroInstance {
  data: HeroData;
  hp: number;
  defending: boolean;
  /** debuff: flat attack modification + turns left */
  atkMod: number;
  atkModTurns: number;
  flash: number; // animation token
  lunge: number;
}

export interface BossInstance {
  data: BossData;
  hp: number;
  tp: number;
  defending: boolean;
  atkMod: number;
  atkModTurns: number;
  defMod: number;
  defModTurns: number;
  cooldowns: Record<string, number>;
}

export interface LogLine {
  id: number;
  text: string;
  tone: "info" | "damage" | "heal" | "tp" | "system";
}

let logCounter = 1;
export function makeLog(text: string, tone: LogLine["tone"] = "info"): LogLine {
  return { id: logCounter++, text, tone };
}

export function makeHeroInstance(data: HeroData): HeroInstance {
  return { data, hp: data.maxHp, defending: false, atkMod: 0, atkModTurns: 0, flash: 0, lunge: 0 };
}

export function makeBossInstance(data: BossData): BossInstance {
  return {
    data,
    hp: data.stats.maxHp,
    tp: 0,
    defending: false,
    atkMod: 0,
    atkModTurns: 0,
    defMod: 0,
    defModTurns: 0,
    cooldowns: {},
  };
}

export function bossAttack(boss: BossInstance): number {
  return Math.max(1, boss.data.stats.attack + boss.atkMod);
}
export function bossDefense(boss: BossInstance): number {
  return Math.max(0, boss.data.stats.defense + boss.defMod + (boss.defending ? 8 : 0));
}
export function heroAttackValue(h: HeroInstance): number {
  return Math.max(1, h.data.attack + (h.atkModTurns > 0 ? h.atkMod : 0));
}
export function heroMagicValue(h: HeroInstance): number {
  return Math.max(1, h.data.magic + (h.atkModTurns > 0 ? h.atkMod : 0));
}

export function addTp(boss: BossInstance, amount: number): number {
  const before = boss.tp;
  boss.tp = clamp(boss.tp + amount, 0, boss.data.stats.maxTp);
  return boss.tp - before;
}

export interface HeroActionOutcome {
  action: HeroAction;
  damage: number;
  heal: number;
  crit: boolean;
  tpGain: number;
}

export function pickHeroAction(h: HeroInstance, heroes: HeroInstance[], boss: BossInstance): HeroAction {
  const alive = heroes.filter((x) => x.hp > 0);
  const ctx: HeroAIContext = {
    selfHpPct: h.hp / h.data.maxHp,
    lowestAllyHpPct: Math.min(...alive.map((x) => x.hp / x.data.maxHp)),
    bossHpPct: boss.hp / boss.data.stats.maxHp,
  };
  return chooseHeroAction(h.data, ctx);
}

/** Resolve a hero action against the boss (or an ally for heals). */
export function resolveHeroAction(h: HeroInstance, action: HeroAction, boss: BossInstance): HeroActionOutcome {
  let damage = 0;
  let heal = 0;
  let crit = false;
  if (action.kind === "attack") {
    const roll = rollCrit(0.06, 1.4);
    crit = roll.crit;
    damage = computeDamage({
      power: heroAttackValue(h) * action.power,
      defense: bossDefense(boss),
      multiplier: roll.mult * (boss.defending ? 0.5 : 1),
    });
  } else if (action.kind === "magic") {
    const roll = rollCrit(0.06, 1.4);
    crit = roll.crit;
    damage = computeDamage({
      power: heroMagicValue(h) * action.power,
      defense: bossDefense(boss),
      ignoreDefenseFraction: 0.5,
      multiplier: roll.mult * (boss.defending ? 0.5 : 1),
    });
  } else if (action.kind === "heal") {
    heal = Math.round(action.power);
  }
  const tpGain = damage > 0 ? Math.round(damage * TP_GAIN.dealtFraction * 0.5) : 0;
  return { action, damage, heal, crit, tpGain };
}

/** Boss basic attack on a hero. */
export function resolveBossFight(boss: BossInstance, target: HeroInstance): { damage: number; crit: boolean } {
  const roll = rollCrit(boss.data.stats.critChance, boss.data.stats.critDamage);
  const damage = computeDamage({
    power: bossAttack(boss),
    defense: target.data.defense,
    multiplier: roll.mult * (target.defending ? 0.5 : 1),
  });
  return { damage, crit: roll.crit };
}

/** Boss ability direct damage/heal math. */
export function resolveAbilityPower(
  boss: BossInstance,
  ability: AbilityData,
  target?: HeroInstance
): { damage: number; heal: number; crit: boolean } {
  const base = ability.powerIsMultiplier ? bossAttack(boss) * ability.power : ability.power;
  if (ability.effect === "damage" || ability.effect === "drain") {
    const roll = rollCrit(boss.data.stats.critChance, boss.data.stats.critDamage);
    const damage = computeDamage({
      power: base,
      defense: target ? target.data.defense : 0,
      ignoreDefenseFraction: 0.5,
      multiplier: roll.mult * (target?.defending ? 0.5 : 1),
    });
    return { damage, heal: 0, crit: roll.crit };
  }
  if (ability.effect === "heal") {
    return { damage: 0, heal: Math.round(base), crit: false };
  }
  return { damage: 0, heal: 0, crit: false };
}

export function tickCooldowns(boss: BossInstance) {
  for (const k of Object.keys(boss.cooldowns)) {
    boss.cooldowns[k] = Math.max(0, boss.cooldowns[k] - 1);
  }
}

export function tickHeroMods(h: HeroInstance) {
  if (h.atkModTurns > 0) {
    h.atkModTurns--;
    if (h.atkModTurns === 0) h.atkMod = 0;
  }
}

export function tickBossMods(b: BossInstance) {
  if (b.atkModTurns > 0) {
    b.atkModTurns--;
    if (b.atkModTurns === 0) b.atkMod = 0;
  }
  if (b.defModTurns > 0) {
    b.defModTurns--;
    if (b.defModTurns === 0) b.defMod = 0;
  }
}
