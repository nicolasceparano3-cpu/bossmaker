"use client";
// ============================================================
// FULL BOSS BUNDLE: exports a boss together with EVERYTHING it
// references (custom sprites, sounds incl. theme, attacks,
// abilities, animations and their nested refs) as one JSON file
// that can be imported into a fresh session in one click.
// ============================================================

import type { AbilityData, AnimationData, AssetKind, AttackData, BossData, SpriteData } from "./types";
import { uid } from "./types";
import { BUILTIN_SPRITES } from "./sprites";
import { store } from "./store";

export interface BundleAsset {
  kind: AssetKind;
  id: string;
  name: string;
  data: unknown;
}

export interface BossBundle {
  format: "bossmaker.bundle";
  version: 1;
  bossId: string;
  bossName: string;
  assets: BundleAsset[];
}

const clone = <T,>(x: T): T => JSON.parse(JSON.stringify(x));

export function collectBossBundle(bossId: string): BossBundle | null {
  const bossRow = store.resolveBoss(bossId);
  if (!bossRow) return null;
  const boss = bossRow.data;
  const assets: BundleAsset[] = [];
  const seen = new Set<string>();

  function push(kind: AssetKind, id: string | null | undefined) {
    if (!id || seen.has(`${kind}:${id}`)) return;
    seen.add(`${kind}:${id}`);
    const row = store.get(id);
    if (!row) return;
    assets.push({ kind, id, name: row.name, data: clone(row.data) });
  }
  function spriteRef(sid: string | undefined) {
    if (sid && !BUILTIN_SPRITES[sid]) push("sprite", sid);
  }
  function soundRef(s: string | undefined) {
    if (s && s.startsWith("asset:")) push("sound", s.slice(6));
  }
  function attackRef(id: string | null | undefined) {
    if (!id) return;
    const atk = store.resolveAttack(id);
    if (!atk) return;
    push("attack", id);
    for (const o of atk.data.objects) {
      spriteRef(o.spriteId);
      soundRef(o.spawnSound);
      soundRef(o.hitSound);
      soundRef(o.despawnSound);
    }
  }
  function animRef(id: string | undefined) {
    if (!id) return;
    const row = store.get(id);
    if (!row || row.kind !== "animation") return;
    push("animation", id);
    const d = row.data as AnimationData;
    for (const f of d.frames) spriteRef(f.spriteId);
    for (const em of d.emitters) spriteRef(em.spriteId);
  }

  for (const abId of boss.abilityIds) {
    const ab = store.resolveAbility(abId);
    if (!ab) continue;
    push("ability", abId);
    attackRef(ab.data.attackId);
  }
  Object.values(boss.animations ?? {}).forEach(animRef);
  spriteRef(boss.spriteId);
  if (boss.themeId) push("sound", boss.themeId);
  if (boss.floor?.startsWith("sprite:")) push("sprite", boss.floor.slice(7));
  for (const ef of boss.effects ?? []) spriteRef(ef.spriteId);

  assets.push({ kind: "boss", id: bossId, name: bossRow.name, data: clone(boss) });

  return { format: "bossmaker.bundle", version: 1, bossId, bossName: bossRow.name, assets };
}

export async function importBossBundle(json: BossBundle): Promise<string | null> {
  if (!json || json.format !== "bossmaker.bundle" || !Array.isArray(json.assets)) return null;
  const map = new Map<string, string>();
  for (const a of json.assets) if (a.kind !== "boss") map.set(a.id, uid(a.kind));

  const remapSprite = (sid: string | undefined) => (sid && map.has(sid) ? map.get(sid)! : sid);
  const remapSound = (s: string | undefined) =>
    s && s.startsWith("asset:") && map.has(s.slice(6)) ? `asset:${map.get(s.slice(6))!}` : s;

  for (const a of json.assets) {
    const data = clone(a.data) as never;
    if (a.kind === "attack") {
      const d = data as AttackData;
      for (const o of d.objects ?? []) {
        o.spriteId = remapSprite(o.spriteId) ?? o.spriteId;
        o.spawnSound = remapSound(o.spawnSound);
        o.hitSound = remapSound(o.hitSound);
        o.despawnSound = remapSound(o.despawnSound);
      }
    } else if (a.kind === "animation") {
      const d = data as AnimationData;
      for (const f of d.frames ?? []) f.spriteId = remapSprite(f.spriteId) ?? f.spriteId;
      for (const em of d.emitters ?? []) em.spriteId = remapSprite(em.spriteId) ?? em.spriteId;
    } else if (a.kind === "ability") {
      const d = data as AbilityData;
      if (d.attackId && map.has(d.attackId)) d.attackId = map.get(d.attackId)!;
    } else if (a.kind === "sprite") {
      const d = data as SpriteData;
      d.name = a.name;
    }
    if (a.kind !== "boss") {
      await store.create(a.kind, a.name, data, map.get(a.id));
    }
  }

  const bossAsset = json.assets.find((a) => a.kind === "boss");
  if (!bossAsset) return null;
  const boss = clone(bossAsset.data) as BossData;
  boss.spriteId = remapSprite(boss.spriteId) ?? boss.spriteId;
  if (boss.themeId && map.has(boss.themeId)) boss.themeId = map.get(boss.themeId)!;
  boss.abilityIds = (boss.abilityIds ?? []).map((id) => map.get(id) ?? id);
  const anims: Record<string, string> = {};
  for (const [k, id] of Object.entries(boss.animations ?? {})) anims[k] = map.get(id) ?? id;
  boss.animations = anims;
  if (boss.floor?.startsWith("sprite:") && map.has(boss.floor.slice(7)))
    boss.floor = `sprite:${map.get(boss.floor.slice(7))!}`;
  for (const ef of boss.effects ?? []) ef.spriteId = remapSprite(ef.spriteId) ?? ef.spriteId;

  const created = await store.create("boss", bossAsset.name, boss);
  return created.id;
}
