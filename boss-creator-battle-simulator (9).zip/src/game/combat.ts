// ============================================================
// Reusable combat calculation system. Damage formulas are
// data-selected rather than hard-coded into the UI.
// ============================================================

export type DamageFormulaId = "atkMinusDef" | "flat" | "percentMax";

export interface DamageRollInput {
  /** raw power (attack stat, flat number, or percentage 0..1) */
  power: number;
  defense?: number;
  formula?: DamageFormulaId;
  /** target max HP for percentMax */
  targetMaxHp?: number;
  multiplier?: number;
  ignoreDefenseFraction?: number; // 0..1
}

export function computeDamage(input: DamageRollInput): number {
  const formula = input.formula ?? "atkMinusDef";
  const defense = input.defense ?? 0;
  const ignored = defense * (input.ignoreDefenseFraction ?? 0);
  const effDef = defense - ignored;
  let dmg = 0;
  switch (formula) {
    case "flat":
      dmg = input.power;
      break;
    case "percentMax":
      dmg = (input.targetMaxHp ?? 100) * input.power;
      break;
    case "atkMinusDef":
    default:
      dmg = input.power - effDef;
      break;
  }
  dmg *= input.multiplier ?? 1;
  return Math.max(1, Math.round(dmg));
}

export function rollCrit(chance: number, critDamageMult: number): { crit: boolean; mult: number } {
  if (Math.random() < chance) return { crit: true, mult: critDamageMult };
  return { crit: false, mult: 1 };
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

export function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/** TP gain helpers — configurable event-based gains. */
export const TP_GAIN = {
  dealtFraction: 0.12,
  takenFraction: 0.1,
  defend: 8,
  killBonus: 10,
};

export function tpFromDamageDealt(dmg: number): number {
  return Math.round(dmg * TP_GAIN.dealtFraction);
}
export function tpFromDamageTaken(dmg: number): number {
  return Math.round(dmg * TP_GAIN.takenFraction);
}
