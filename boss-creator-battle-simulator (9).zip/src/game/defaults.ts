// ============================================================
// Seed content — the first demo target from the design doc:
// Test Boss + Bullet Storm + a handful of abilities. These are
// plain data objects inserted into the DB on first run.
// ============================================================

import type { AttackData, AbilityData, BossData, AssetKind, AttackObject } from "./types";
import { newAttackObject } from "./types";

function obj(partial: Partial<AttackObject> & { name: string }): AttackObject {
  const o = newAttackObject(partial.kind ?? "projectile", partial.start ?? 0);
  return { ...o, ...partial, keyframes: { ...o.keyframes, ...(partial.keyframes ?? {}) } };
}

export const ATTACK_BULLET_STORM: AttackData = {
  name: "Bullet Storm",
  description: "Falling bullets, a telegraphed beam, sweeping blades and a homing knife.",
  box: { width: 500, height: 300, soulStart: { x: 250, y: 150 } },
  duration: 8,
  invuln: 0.5,
  soulMaxHp: 160,
  objects: [
    obj({
      name: "Beam Warning",
      kind: "warning",
      start: 0.5,
      lifetime: 1.2,
      spriteId: "rect",
      collision: { type: "rect", w: 460, h: 40 },
      movement: "static",
      keyframes: {
        pos: [{ t: 0.5, x: 250, y: 150, e: "linear" }],
        rot: [],
        scale: [],
        opacity: [
          { t: 0.5, v: 0, e: "out" },
          { t: 0.8, v: 0.8, e: "linear" },
          { t: 1.45, v: 0.8, e: "in" },
          { t: 1.65, v: 0, e: "linear" },
        ],
      },
    }),
    obj({
      name: "Beam",
      kind: "hazard",
      start: 1.5,
      lifetime: 0.9,
      spriteId: "rect",
      collision: { type: "rect", w: 460, h: 34 },
      movement: "static",
      damageMult: 1.0,
      keyframes: {
        pos: [{ t: 1.5, x: 250, y: 150, e: "linear" }],
        rot: [],
        scale: [],
        opacity: [
          { t: 1.5, v: 0, e: "step" },
          { t: 1.58, v: 1, e: "linear" },
          { t: 2.1, v: 1, e: "in" },
          { t: 2.35, v: 0, e: "linear" },
        ],
      },
    }),
    // falling bullets
    ...[0, 1, 2, 3, 4, 5].map((i) =>
      obj({
        name: `Rain ${i + 1}`,
        kind: "projectile",
        spriteId: "bullet",
        movement: "linear",
        angle: 90,
        velocity: 120 + i * 12,
        damageMult: 0.4,
        collision: { type: "circle", radius: 7 },
        start: 0.8 + i * 0.55,
        lifetime: 4,
        keyframes: {
          pos: [{ t: 0.8 + i * 0.55, x: 40 + i * 78, y: -18, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [],
        },
      })
    ),
    obj({
      name: "Blade Sweep L",
      kind: "projectile",
      spriteId: "blade",
      movement: "linear",
      angle: 0,
      velocity: 205,
      spin: 360,
      damageMult: 0.6,
      collision: { type: "circle", radius: 10 },
      start: 2.9,
      lifetime: 4,
      keyframes: { pos: [{ t: 2.9, x: -30, y: 85, e: "linear" }], rot: [], scale: [], opacity: [] },
    }),
    obj({
      name: "Blade Sweep R",
      kind: "projectile",
      spriteId: "blade",
      movement: "linear",
      angle: 180,
      velocity: 205,
      spin: -360,
      damageMult: 0.6,
      collision: { type: "circle", radius: 10 },
      start: 3.7,
      lifetime: 4,
      keyframes: { pos: [{ t: 3.7, x: 530, y: 215, e: "linear" }], rot: [], scale: [], opacity: [] },
    }),
    obj({
      name: "Hunter Knife",
      kind: "projectile",
      spriteId: "knife",
      movement: "keyframed",
      damageMult: 0.8,
      collision: { type: "circle", radius: 9 },
      start: 4.2,
      lifetime: 2.5,
      keyframes: {
        pos: [
          { t: 4.2, x: 60, y: -20, e: "out" },
          { t: 5.3, x: 250, y: 150, e: "in" },
          { t: 6.4, x: 470, y: 330, e: "linear" },
        ],
        rot: [
          { t: 4.2, v: 90, e: "linear" },
          { t: 6.4, v: 140, e: "linear" },
        ],
        scale: [],
        opacity: [],
      },
    }),
    // radial orb burst
    ...[45, 135, 225, 315].map((a) =>
      obj({
        name: `Orb ${a}`,
        kind: "projectile",
        spriteId: "orb",
        movement: "radial",
        angle: a,
        velocity: 95,
        damageMult: 0.5,
        collision: { type: "circle", radius: 8 },
        start: 5.1,
        lifetime: 3,
        keyframes: {
          pos: [{ t: 5.1, x: 250, y: 150, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [
            { t: 5.1, v: 0, e: "linear" },
            { t: 5.35, v: 1, e: "linear" },
          ],
        },
      })
    ),
  ],
};

export const ATTACK_KNIFE_CIRCLE: AttackData = {
  name: "Knife Circle",
  description: "Knives spiral out from the center while two hunters chase the SOUL.",
  box: { width: 440, height: 280, soulStart: { x: 220, y: 140 } },
  duration: 7,
  invuln: 0.5,
  soulMaxHp: 160,
  objects: [
    ...[0, 45, 90, 135, 180, 225, 270, 315].map((a, i) =>
      obj({
        name: `Spiral Knife ${i + 1}`,
        kind: "projectile",
        spriteId: "knife",
        movement: "radial",
        angle: a,
        velocity: 70 + i * 6,
        accel: 30,
        spin: 200,
        damageMult: 0.5,
        collision: { type: "circle", radius: 8 },
        start: 0.6 + Math.floor(i / 2) * 0.9,
        lifetime: 5,
        keyframes: {
          pos: [{ t: 0.6 + Math.floor(i / 2) * 0.9, x: 220, y: 140, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [
            { t: 0.6 + Math.floor(i / 2) * 0.9, v: 0, e: "linear" },
            { t: 0.6 + Math.floor(i / 2) * 0.9 + 0.25, v: 1, e: "linear" },
          ],
        },
      })
    ),
    obj({
      name: "Hunter I",
      kind: "projectile",
      spriteId: "knife",
      movement: "homing",
      velocity: 98,
      turnRate: 135,
      damageMult: 0.7,
      collision: { type: "circle", radius: 9 },
      start: 1.2,
      lifetime: 5,
      keyframes: { pos: [{ t: 1.2, x: -20, y: 40, e: "linear" }], rot: [], scale: [], opacity: [
        { t: 1.2, v: 0, e: "linear" },
        { t: 1.45, v: 1, e: "linear" },
      ] },
    }),
    obj({
      name: "Hunter II",
      kind: "projectile",
      spriteId: "knife",
      movement: "homing",
      velocity: 88,
      turnRate: 115,
      damageMult: 0.7,
      collision: { type: "circle", radius: 9 },
      start: 2.4,
      lifetime: 5,
      keyframes: { pos: [{ t: 2.4, x: 460, y: 240, e: "linear" }], rot: [], scale: [], opacity: [
        { t: 2.4, v: 0, e: "linear" },
        { t: 2.65, v: 1, e: "linear" },
      ] },
    }),
  ],
};

/** Showcase: the attack box itself shrinks and shifts during the attack. */
export const ATTACK_BOX_MELT: AttackData = {
  name: "Box Meltdown",
  description: "The arena itself collapses while bullets rain. Shows box size keyframes.",
  box: { width: 500, height: 300, soulStart: { x: 250, y: 150 } },
  boxKeys: [
    { t: 0, w: 500, h: 300 },
    { t: 2.5, w: 500, h: 300 },
    { t: 4, w: 260, h: 220 },
    { t: 6, w: 260, h: 220 },
    { t: 7.5, w: 440, h: 140 },
    { t: 9, w: 440, h: 140 },
  ],
  duration: 10,
  invuln: 0.5,
  soulMaxHp: 160,
  objects: [
    ...[0, 1, 2, 3, 4, 5, 6, 7].map((i) =>
      obj({
        name: `Rain ${i + 1}`,
        kind: "projectile",
        spriteId: "bullet",
        movement: "linear",
        angle: 90,
        velocity: 105 + (i % 4) * 15,
        damageMult: 0.4,
        collision: { type: "circle", radius: 7 },
        start: 0.6 + i * 1.05,
        lifetime: 6,
        keyframes: {
          pos: [{ t: 0.6 + i * 1.05, x: 40 + ((i * 97) % 420), y: -16, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [],
        },
      })
    ),
    ...[0, 1, 2, 3].map((i) =>
      obj({
        name: `Pinch ${i + 1}`,
        kind: "hazard",
        spriteId: "blade",
        movement: "linear",
        angle: i % 2 === 0 ? 0 : 180,
        velocity: 150,
        spin: 400,
        damageMult: 0.5,
        collision: { type: "circle", radius: 9 },
        start: 4.4 + i * 1.1,
        lifetime: 4,
        keyframes: {
          pos: [{ t: 4.4 + i * 1.1, x: i % 2 === 0 ? -20 : 520, y: 110 + (i % 2) * 60, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [],
        },
      })
    ),
  ],
};

/** Narrowing corridors of bones with a widening finale. */
export const ATTACK_BONE_CORRIDOR: AttackData = {
  name: "Bone Corridor",
  description: "Walls of bones close in as the box narrows, then a wide-orb finale.",
  box: { width: 480, height: 300, soulStart: { x: 240, y: 150 } },
  boxKeys: [
    { t: 0, w: 480, h: 300 },
    { t: 3, w: 300, h: 300 },
    { t: 5.5, w: 200, h: 240 },
    { t: 8, w: 460, h: 260 },
  ],
  duration: 9,
  invuln: 0.5,
  soulMaxHp: 160,
  objects: [
    ...[0, 1, 2, 3, 4, 5].map((i) =>
      obj({
        name: `Wall L${i + 1}`,
        kind: "projectile",
        spriteId: "bone",
        movement: "linear",
        angle: 0,
        velocity: 120,
        damageMult: 0.45,
        collision: { type: "circle", radius: 8 },
        start: 0.5 + i * 0.8,
        lifetime: 5,
        keyframes: {
          pos: [{ t: 0.5 + i * 0.8, x: -16, y: 40 + i * 44, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [],
        },
      })
    ),
    ...[0, 1, 2, 3, 4, 5].map((i) =>
      obj({
        name: `Wall R${i + 1}`,
        kind: "projectile",
        spriteId: "bone",
        movement: "linear",
        angle: 180,
        velocity: 120,
        damageMult: 0.45,
        collision: { type: "circle", radius: 8 },
        start: 0.9 + i * 0.8,
        lifetime: 5,
        keyframes: {
          pos: [{ t: 0.9 + i * 0.8, x: 496, y: 62 + i * 44, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [],
        },
      })
    ),
    ...[0, 45, 90, 135, 180, 225, 270, 315].map((a) =>
      obj({
        name: `Finale ${a}`,
        kind: "projectile",
        spriteId: "orb",
        movement: "radial",
        angle: a,
        velocity: 90,
        damageMult: 0.5,
        collision: { type: "circle", radius: 8 },
        start: 6.2,
        lifetime: 3,
        keyframes: {
          pos: [{ t: 6.2, x: 240, y: 150, e: "linear" }],
          rot: [],
          scale: [],
          opacity: [
            { t: 6.2, v: 0, e: "linear" },
            { t: 6.45, v: 1, e: "linear" },
          ],
        },
      })
    ),
  ],
};

export const ABILITIES: AbilityData[] = [
  {
    name: "Bullet Storm",
    description: "Rain a storm of bullets across the arena.",
    category: "bullet",
    tpCost: 20,
    cooldown: 1,
    target: "soul",
    effect: "bullet",
    power: 0,
    powerIsMultiplier: false,
    attackId: "at_bulletstorm",
    buffStat: "attack",
    buffAmount: 0,
    buffDuration: 0,
    drainHeal: 0,
  },
  {
    name: "Knife Circle",
    description: "Spiral knives outward and hunt the SOUL.",
    category: "bullet",
    tpCost: 35,
    cooldown: 2,
    target: "soul",
    effect: "bullet",
    power: 0,
    powerIsMultiplier: false,
    attackId: "at_knifecircle",
    buffStat: "attack",
    buffAmount: 0,
    buffDuration: 0,
    drainHeal: 0,
  },
  {
    name: "Dark Blast",
    description: "Deals 80 dark damage to one hero.",
    category: "offensive",
    tpCost: 25,
    cooldown: 0,
    target: "hero",
    effect: "damage",
    power: 80,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: 0,
    buffDuration: 0,
    drainHeal: 0,
  },
  {
    name: "Drain Life",
    description: "Deal 60 damage. Heal for 50% of damage dealt.",
    category: "offensive",
    tpCost: 30,
    cooldown: 1,
    target: "hero",
    effect: "drain",
    power: 60,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: 0,
    buffDuration: 0,
    drainHeal: 0.5,
  },
  {
    name: "Dark Heal",
    description: "Restore 150 HP.",
    category: "healing",
    tpCost: 30,
    cooldown: 1,
    target: "self",
    effect: "heal",
    power: 150,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: 0,
    buffDuration: 0,
    drainHeal: 0,
  },
  {
    name: "Weaken",
    description: "Heroes deal 8 less damage for 2 turns.",
    category: "debuff",
    tpCost: 20,
    cooldown: 2,
    target: "all",
    effect: "debuff",
    power: 0,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: -8,
    buffDuration: 2,
    drainHeal: 0,
  },
  {
    name: "Empower",
    description: "Raise ATTACK by 12 for 3 turns.",
    category: "buff",
    tpCost: 25,
    cooldown: 2,
    target: "self",
    effect: "buff",
    power: 0,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: 12,
    buffDuration: 3,
    drainHeal: 0,
  },
];

export const BOSS_TEST: BossData = {
  name: "Test Boss",
  description: "A dark guardian assembled for the first demonstration.",
  spriteId: "boss_grim",
  stats: {
    maxHp: 1000,
    attack: 50,
    defense: 10,
    speed: 10,
    maxTp: 100,
    critChance: 0.08,
    critDamage: 1.5,
    soulDamageMult: 1,
  },
  abilityIds: ["ab_bulletstorm", "ab_darkblast", "ab_drain", "ab_darkheal", "ab_weaken", "ab_empower"],
};

export interface SeedAsset {
  id: string;
  kind: AssetKind;
  name: string;
  data: unknown;
}

export function seedAssets(): SeedAsset[] {
  const abilityIds = ["bulletstorm", "knifecircle", "darkblast", "drain", "darkheal", "weaken", "empower"];
  return [
    { id: "at_bulletstorm", kind: "attack", name: ATTACK_BULLET_STORM.name, data: ATTACK_BULLET_STORM },
    { id: "at_knifecircle", kind: "attack", name: ATTACK_KNIFE_CIRCLE.name, data: ATTACK_KNIFE_CIRCLE },
    { id: "at_boxmelt", kind: "attack", name: ATTACK_BOX_MELT.name, data: ATTACK_BOX_MELT },
    { id: "at_bonewalls", kind: "attack", name: ATTACK_BONE_CORRIDOR.name, data: ATTACK_BONE_CORRIDOR },
    ...ABILITIES.map((a, i) => ({ id: `ab_${abilityIds[i]}`, kind: "ability" as AssetKind, name: a.name, data: a })),
    { id: "boss_test", kind: "boss", name: BOSS_TEST.name, data: BOSS_TEST },
  ];
}
