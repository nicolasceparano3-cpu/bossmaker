// ============================================================
// AttackPlayback engine. Receives AttackData + a Soul and runs
// the timeline: keyframe interpolation, movement simulation,
// collision, damage. The editor preview, the TEST simulator and
// the real battle all use this exact same code path.
// Time-based (seconds), never frame-count based.
// ============================================================

import type { AttackData, AttackObject, Easing, KF, KF2, SoulAIDifficulty } from "./types";
import { LAYER_ORDER } from "./types";

export const SOUL_RADIUS = 5;

// ---------------- easing ----------------

export function ease(e: Easing, t: number): number {
  t = Math.max(0, Math.min(1, t));
  switch (e) {
    case "linear":
      return t;
    case "in":
      return t * t;
    case "out":
      return 1 - (1 - t) * (1 - t);
    case "inout":
      return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    case "step":
      return t < 1 ? 0 : 1;
  }
}

function kfBracket<T extends { t: number }>(kfs: T[], time: number): [T, T] | T | null {
  if (kfs.length === 0) return null;
  const sorted = kfs; // assumed sorted by t
  if (time <= sorted[0].t) return sorted[0];
  if (time >= sorted[sorted.length - 1].t) return sorted[sorted.length - 1];
  for (let i = 0; i < sorted.length - 1; i++) {
    if (time >= sorted[i].t && time <= sorted[i + 1].t) return [sorted[i], sorted[i + 1]];
  }
  return sorted[sorted.length - 1];
}

export function evalKF(kfs: KF[], time: number, def = 0): number {
  const b = kfBracket(kfs, time);
  if (!b) return def;
  if (!Array.isArray(b)) return b.v;
  const [a, n] = b;
  const span = n.t - a.t;
  const k = span <= 0 ? 1 : ease(a.e ?? "linear", (time - a.t) / span);
  return a.v + (n.v - a.v) * k;
}

export function evalKF2(kfs: KF2[], time: number, def = { x: 0, y: 0 }): { x: number; y: number } {
  const b = kfBracket(kfs, time);
  if (!b) return { ...def };
  if (!Array.isArray(b)) return { x: b.x, y: b.y };
  const [a, n] = b;
  const span = n.t - a.t;
  const k = span <= 0 ? 1 : ease(a.e ?? "linear", (time - a.t) / span);
  return { x: a.x + (n.x - a.x) * k, y: a.y + (n.y - a.y) * k };
}

export function sortKeyframes(attack: AttackData) {
  for (const o of attack.objects) {
    for (const ch of ["pos", "rot", "scale", "opacity"] as const) {
      (o.keyframes[ch] as { t: number }[]).sort((a, b) => a.t - b.t);
    }
  }
}

// ---------------- object state ----------------

export interface ObjectState {
  x: number;
  y: number;
  rot: number;
  scale: number;
  opacity: number;
  active: boolean;
}

export function objectWindow(obj: AttackObject): [number, number] {
  return [obj.start, obj.lifetime == null ? Infinity : obj.start + obj.lifetime];
}

export function isObjActive(obj: AttackObject, t: number): boolean {
  const [s, e] = objectWindow(obj);
  return t >= s && t <= e;
}

/** Pure evaluation for keyframed/static objects. */
export function evalKeyframedState(attack: AttackData, obj: AttackObject, t: number): ObjectState {
  const defPos = { x: attack.box.width / 2, y: attack.box.height / 2 };
  const pos = evalKF2(obj.keyframes.pos, t, defPos);
  const rot = obj.keyframes.rot.length ? evalKF(obj.keyframes.rot, t, 0) : obj.spin * Math.max(0, t - obj.start);
  const scale = evalKF(obj.keyframes.scale, t, 1);
  const opacity = evalKF(obj.keyframes.opacity, t, 1);
  return { x: pos.x, y: pos.y, rot, scale: Math.max(0.01, scale), opacity, active: isObjActive(obj, t) };
}

// ---------------- collision (independent of rendering) ----------------

export function circleVsCircle(ax: number, ay: number, ar: number, bx: number, by: number, br: number) {
  const dx = ax - bx;
  const dy = ay - by;
  const r = ar + br;
  return dx * dx + dy * dy <= r * r;
}

/** circle vs rotated rectangle centered at (bx,by) */
export function circleVsOBB(
  cx: number,
  cy: number,
  cr: number,
  bx: number,
  by: number,
  w: number,
  h: number,
  rotDeg: number
) {
  const ang = (-rotDeg * Math.PI) / 180;
  const dx = cx - bx;
  const dy = cy - by;
  const lx = dx * Math.cos(ang) - dy * Math.sin(ang);
  const ly = dx * Math.sin(ang) + dy * Math.cos(ang);
  const nx = Math.max(-w / 2, Math.min(w / 2, lx));
  const ny = Math.max(-h / 2, Math.min(h / 2, ly));
  const ddx = lx - nx;
  const ddy = ly - ny;
  return ddx * ddx + ddy * ddy <= cr * cr;
}

// ---------------- runtime ----------------

export interface SoulState {
  x: number;
  y: number;
  vx: number;
  vy: number;
  hp: number;
  maxHp: number;
  invulnT: number;
  alive: boolean;
}

interface SimState {
  x: number;
  y: number;
  speed: number;
  angle: number; // radians
  simmedTo: number;
}

export type ObjEventType = "spawn" | "despawn" | "hit";

export interface RuntimeOptions {
  attackPower: number; // boss attack stat (or test value)
  soulDamageMult?: number;
  withSoul?: boolean;
  difficulty?: SoulAIDifficulty | null;
  /** optional external AI driver (battle passes its own tick) */
  onHit?: (damage: number) => void;
  onSoulDown?: () => void;
  /** object lifecycle events (spawn/despawn/hit) for sound & effects */
  onObjEvent?: (type: ObjEventType, objId: string) => void;
}

export interface HitEvent {
  time: number;
  damage: number;
  x: number;
  y: number;
  objId: string;
}

export class AttackRuntime {
  attack: AttackData;
  opts: RuntimeOptions;
  time = 0;
  finished = false;
  soul: SoulState;
  hits = 0;
  damageDealt = 0;
  minSoulHpPct = 100;
  hitEvents: HitEvent[] = [];
  private sims = new Map<string, SimState>();
  private activeMap = new Map<string, boolean>();
  /** AI driver injected externally (SoulAI) */
  aiUpdate: ((dt: number, rt: AttackRuntime) => void) | null = null;

  constructor(attack: AttackData, opts: RuntimeOptions) {
    this.attack = attack;
    this.opts = opts;
    sortKeyframes(attack);
    (attack.boxKeys ?? []).sort((a, b) => a.t - b.t);
    this.soul = {
      x: attack.box.soulStart.x,
      y: attack.box.soulStart.y,
      vx: 0,
      vy: 0,
      hp: attack.soulMaxHp || 160,
      maxHp: attack.soulMaxHp || 160,
      invulnT: 0,
      alive: true,
    };
  }

  get duration() {
    return this.attack.duration;
  }

  /** attack box dimensions at time t (keyframeable size) */
  boxAt(t: number): { width: number; height: number } {
    const keys = this.attack.boxKeys;
    const base = this.attack.box;
    if (!keys || keys.length === 0) return { width: base.width, height: base.height };
    if (t <= keys[0].t) return { width: keys[0].w, height: keys[0].h };
    for (let i = 0; i < keys.length - 1; i++) {
      const a = keys[i];
      const b = keys[i + 1];
      if (t >= a.t && t <= b.t) {
        const k = b.t - a.t <= 0 ? 1 : (t - a.t) / (b.t - a.t);
        return { width: a.w + (b.w - a.w) * k, height: a.h + (b.h - a.h) * k };
      }
    }
    const lastK = keys[keys.length - 1];
    return { width: lastK.w, height: lastK.h };
  }

  isDynamic(obj: AttackObject) {
    return obj.movement !== "keyframed" && obj.movement !== "static";
  }

  private initSim(obj: AttackObject): SimState {
    const kf0 = obj.keyframes.pos[0];
    const x = kf0 ? kf0.x : this.attack.box.width / 2;
    const y = kf0 ? kf0.y : this.attack.box.height / 2;
    return { x, y, speed: obj.velocity, angle: (obj.angle * Math.PI) / 180, simmedTo: obj.start };
  }

  private simTo(obj: AttackObject, target: number) {
    let s = this.sims.get(obj.id);
    if (!s) {
      s = this.initSim(obj);
      this.sims.set(obj.id, s);
    }
    if (target < s.simmedTo) {
      s = this.initSim(obj);
      this.sims.set(obj.id, s);
    }
    const h = 1 / 120;
    let guard = 0;
    while (s.simmedTo < target - 1e-6 && guard < 4000) {
      const dt = Math.min(h, target - s.simmedTo);
      s.simmedTo += dt;
      if (s.simmedTo < obj.start) continue;
      if (obj.movement === "homing") {
        const want = Math.atan2(this.soul.y - s.y, this.soul.x - s.x);
        let diff = want - s.angle;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const maxTurn = ((obj.turnRate * Math.PI) / 180) * dt;
        s.angle += Math.max(-maxTurn, Math.min(maxTurn, diff));
      }
      s.speed = Math.max(0, s.speed + obj.accel * dt);
      s.x += Math.cos(s.angle) * s.speed * dt;
      s.y += Math.sin(s.angle) * s.speed * dt;
      guard++;
    }
  }

  /** Object state at current time (dynamic objects use simulation). */
  stateOf(obj: AttackObject, t: number): ObjectState {
    if (!this.isDynamic(obj)) {
      const st = evalKeyframedState(this.attack, obj, t);
      if (obj.movement === "static") {
        const kf0 = obj.keyframes.pos[0];
        if (kf0) {
          st.x = kf0.x;
          st.y = kf0.y;
        }
      }
      return st;
    }
    this.simTo(obj, Math.max(obj.start, t));
    const s = this.sims.get(obj.id)!;
    const rot = obj.keyframes.rot.length
      ? evalKF(obj.keyframes.rot, t, 0)
      : obj.spin * Math.max(0, t - obj.start) + (obj.angle ?? 0);
    const scale = evalKF(obj.keyframes.scale, t, 1);
    const opacity = evalKF(obj.keyframes.opacity, t, 1);
    return { x: s.x, y: s.y, rot, scale: Math.max(0.01, scale), opacity, active: isObjActive(obj, t) };
  }

  /** Predicted position at future time — used by the SOUL AI. */
  predictPos(obj: AttackObject, t: number): { x: number; y: number } {
    if (t <= this.time) return this.stateOf(obj, this.time);
    if (!this.isDynamic(obj)) return evalKeyframedState(this.attack, obj, t);
    const s = this.stateOf(obj, this.time);
    const sim = this.sims.get(obj.id);
    if (!sim) return s;
    const dt = t - this.time;
    const speed = Math.max(0, sim.speed + obj.accel * dt);
    return {
      x: s.x + Math.cos(sim.angle) * ((sim.speed + speed) / 2) * dt,
      y: s.y + Math.sin(sim.angle) * ((sim.speed + speed) / 2) * dt,
    };
  }

  allStates(t: number): { obj: AttackObject; st: ObjectState }[] {
    const out: { obj: AttackObject; st: ObjectState; layer: number }[] = [];
    for (const obj of this.attack.objects) {
      out.push({ obj, st: this.stateOf(obj, t), layer: LAYER_ORDER.indexOf(obj.layer) });
    }
    out.sort((a, b) => a.layer - b.layer);
    return out;
  }

  seek(t: number) {
    this.time = Math.max(0, Math.min(t, this.duration + 1));
    this.sims.clear();
    this.activeMap.clear();
    if (t > 0) {
      // silently establish current activity so no events fire for the jump
      for (const obj of this.attack.objects) {
        if (this.isDynamic(obj) && obj.start < t) this.simTo(obj, Math.min(t, this.duration));
        this.activeMap.set(obj.id, isObjActive(obj, this.time));
      }
    }
    this.finished = this.time >= this.duration;
  }

  private emitLifecycle() {
    for (const obj of this.attack.objects) {
      const active = isObjActive(obj, this.time);
      const prev = this.activeMap.get(obj.id) ?? false;
      if (active && !prev) this.opts.onObjEvent?.("spawn", obj.id);
      if (!active && prev) this.opts.onObjEvent?.("despawn", obj.id);
      this.activeMap.set(obj.id, active);
    }
  }

  update(dt: number) {
    if (this.finished) return;
    this.time += dt;
    if (this.aiUpdate && this.soul.alive) this.aiUpdate(dt, this);
    // clamp soul into (possibly resizing) box
    const b = this.boxAt(this.time);
    this.soul.x = Math.max(SOUL_RADIUS, Math.min(b.width - SOUL_RADIUS, this.soul.x));
    this.soul.y = Math.max(SOUL_RADIUS, Math.min(b.height - SOUL_RADIUS, this.soul.y));
    if (this.soul.invulnT > 0) this.soul.invulnT -= dt;
    // collisions
    if (this.soul.alive && this.soul.invulnT <= 0) {
      for (const obj of this.attack.objects) {
        if (obj.kind === "warning" || obj.kind === "effect") continue;
        if (obj.damageMult <= 0) continue;
        if (obj.collision.type === "none") continue;
        if (!isObjActive(obj, this.time)) continue;
        const st = this.stateOf(obj, this.time);
        if (st.opacity < 0.05) continue;
        let hit = false;
        if (obj.collision.type === "circle") {
          hit = circleVsCircle(this.soul.x, this.soul.y, SOUL_RADIUS, st.x, st.y, obj.collision.radius * st.scale);
        } else {
          hit = circleVsOBB(
            this.soul.x,
            this.soul.y,
            SOUL_RADIUS,
            st.x,
            st.y,
            obj.collision.w * st.scale,
            obj.collision.h * st.scale,
            st.rot
          );
        }
        if (hit) {
          const dmg = Math.max(1, Math.round(this.opts.attackPower * obj.damageMult * (this.opts.soulDamageMult ?? 1)));
          this.soul.hp -= dmg;
          this.soul.invulnT = this.attack.invuln;
          this.hits++;
          this.damageDealt += dmg;
          this.hitEvents.push({ time: this.time, damage: dmg, x: this.soul.x, y: this.soul.y, objId: obj.id });
          this.opts.onHit?.(dmg);
          this.opts.onObjEvent?.("hit", obj.id);
          if (this.soul.hp <= 0) {
            this.soul.hp = 0;
            this.soul.alive = false;
            this.opts.onSoulDown?.();
          }
          break;
        }
      }
    }
    this.emitLifecycle();
    this.minSoulHpPct = Math.min(this.minSoulHpPct, (this.soul.hp / this.soul.maxHp) * 100);
    if (this.time >= this.duration) this.finished = true;
  }
}

// ---------------- headless test simulator ----------------

export interface TestResult {
  duration: number;
  damage: number;
  hits: number;
  survived: boolean;
  minHpPct: number;
  soulDown: boolean;
}

export function simulateAttack(
  attack: AttackData,
  difficulty: SoulAIDifficulty,
  attackPower: number,
  aiFactory: (d: SoulAIDifficulty) => (dt: number, rt: AttackRuntime) => void
): TestResult {
  const rt = new AttackRuntime(JSON.parse(JSON.stringify(attack)), { attackPower });
  rt.aiUpdate = aiFactory(difficulty);
  let guard = 0;
  while (!rt.finished && guard < 60 * 60) {
    rt.update(1 / 60);
    guard++;
  }
  return {
    duration: Math.min(rt.time, attack.duration),
    damage: rt.damageDealt,
    hits: rt.hits,
    survived: rt.soul.alive,
    minHpPct: rt.minSoulHpPct,
    soulDown: !rt.soul.alive,
  };
}
