"use client";
// ============================================================
// Player customization of roster heroes, stored as assets with
// stable ids (herocfg_<heroId>) so battles and the editor share
// them. Missing config = data-driven defaults.
// ============================================================

import type { HeroCustom } from "./types";
import { store } from "./store";

export function heroCfgId(heroId: string) {
  return `herocfg_${heroId}`;
}

export function getHeroCfg(heroId: string): HeroCustom | undefined {
  const row = store.get(heroCfgId(heroId));
  return (row?.data as HeroCustom | undefined) ?? undefined;
}

export async function saveHeroCfg(heroId: string, cfg: HeroCustom, name: string) {
  const id = heroCfgId(heroId);
  if (store.get(id)) {
    await store.update(id, `Hero Config: ${name}`, cfg);
  } else {
    await store.create("hero", `Hero Config: ${name}`, cfg, id);
  }
}
