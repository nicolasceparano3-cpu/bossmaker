"use client";
// ============================================================
// Resolves heroes for battle & UI: built-in roster (with player
// overrides) plus fully custom heroes stored as kind 'hero'.
// ============================================================

import { HERO_ROSTER } from "./heroes";
import { getHeroCfg } from "./heroCfg";
import { store } from "./store";
import type { HeroCustom, HeroData } from "./types";

export const DEFAULT_ACTIONS = [
  { id: "fight", name: "FIGHT", kind: "attack" as const, power: 1, weight: 10 },
  { id: "defend", name: "DEFEND", kind: "defend" as const, power: 0, weight: 3 },
];

export function isCustomHero(id: string) {
  return id.startsWith("herocust_");
}

export function allHeroesMeta(): { id: string; name: string; spriteId: string; maxHp: number; attack: number }[] {
  const roster = HERO_ROSTER.map((h) => ({ id: h.id, name: h.name, spriteId: h.spriteId, maxHp: h.maxHp, attack: h.attack }));
  const custom = store.byKind<HeroCustom>("hero").map((a) => ({
    id: a.id,
    name: a.data.name ?? a.name,
    spriteId: a.data.spriteId ?? "kris",
    maxHp: a.data.maxHp ?? 120,
    attack: a.data.attack ?? 20,
  }));
  return [...roster, ...custom];
}

export function resolveHeroData(id: string): HeroData {
  const base = HERO_ROSTER.find((h) => h.id === id);
  if (base) {
    const cfg = getHeroCfg(id);
    if (!cfg) return base;
    return {
      ...base,
      name: cfg.name ?? base.name,
      spriteId: cfg.spriteId ?? base.spriteId,
      maxHp: cfg.maxHp ?? base.maxHp,
      attack: cfg.attack ?? base.attack,
      defense: cfg.defense ?? base.defense,
      magic: cfg.magic ?? base.magic,
      actions: cfg.actions?.length ? cfg.actions : base.actions,
    };
  }
  const row = store.get(id);
  if (row && row.kind === "hero") {
    const c = row.data as HeroCustom;
    return {
      id,
      name: c.name ?? row.name,
      spriteId: c.spriteId ?? "kris",
      maxHp: c.maxHp ?? 120,
      attack: c.attack ?? 20,
      defense: c.defense ?? 6,
      magic: c.magic ?? 12,
      actions: c.actions?.length ? c.actions : DEFAULT_ACTIONS,
    };
  }
  return HERO_ROSTER[0];
}

export function resolveHeroCfg(id: string): HeroCustom | undefined {
  if (isCustomHero(id)) return store.get(id)?.data as HeroCustom | undefined;
  return getHeroCfg(id);
}
