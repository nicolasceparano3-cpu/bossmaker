// ============================================================
// Hero roster — fully data-driven. Adding a hero means adding
// an entry here (or later, an asset). The AI picks actions from
// weighted lists with situational bias conditions.
// ============================================================

import type { HeroData, HeroAction } from "./types";

export const HERO_ROSTER: HeroData[] = [
  {
    id: "kris",
    name: "KRIS",
    spriteId: "kris",
    maxHp: 160,
    attack: 26,
    defense: 8,
    magic: 12,
    actions: [
      { id: "fight", name: "FIGHT", kind: "attack", power: 1, weight: 10 },
      { id: "slash", name: "FOCUSED SLASH", kind: "attack", power: 1.4, weight: 4, when: "bossLow" },
      { id: "defend", name: "DEFEND", kind: "defend", power: 0, weight: 3, when: "selfHurt" },
      { id: "act", name: "ACT: OBSERVE", kind: "defend", power: 0, weight: 2 },
    ],
  },
  {
    id: "susie",
    name: "SUSIE",
    spriteId: "susie",
    maxHp: 190,
    attack: 32,
    defense: 6,
    magic: 18,
    actions: [
      { id: "fight", name: "FIGHT", kind: "attack", power: 1, weight: 9 },
      { id: "rudebuster", name: "RUDE BUSTER", kind: "magic", power: 1.5, weight: 6 },
      { id: "defend", name: "DEFEND", kind: "defend", power: 0, weight: 2, when: "selfHurt" },
    ],
  },
  {
    id: "ralsei",
    name: "RALSEI",
    spriteId: "ralsei",
    maxHp: 140,
    attack: 16,
    defense: 6,
    magic: 26,
    actions: [
      { id: "heal", name: "HEAL PRAYER", kind: "heal", power: 55, weight: 6, when: "allyHurt" },
      { id: "pacify", name: "PACIFY", kind: "magic", power: 1.1, weight: 5 },
      { id: "fight", name: "FIGHT", kind: "attack", power: 1, weight: 3 },
      { id: "defend", name: "DEFEND", kind: "defend", power: 0, weight: 3, when: "selfHurt" },
    ],
  },
  {
    id: "noelle",
    name: "NOELLE",
    spriteId: "noelle",
    maxHp: 150,
    attack: 20,
    defense: 7,
    magic: 24,
    actions: [
      { id: "iceshock", name: "ICE SHOCK", kind: "magic", power: 1.2, weight: 6 },
      { id: "heal", name: "SOOTHING SNOW", kind: "heal", power: 45, weight: 5, when: "allyHurt" },
      { id: "fight", name: "FIGHT", kind: "attack", power: 1, weight: 3 },
      { id: "defend", name: "DEFEND", kind: "defend", power: 0, weight: 2, when: "selfHurt" },
    ],
  },
];

export function getHero(id: string): HeroData {
  return HERO_ROSTER.find((h) => h.id === id) ?? HERO_ROSTER[0];
}

export interface HeroAIContext {
  selfHpPct: number;
  lowestAllyHpPct: number;
  bossHpPct: number;
}

/** Weighted action selection with situational biases. */
export function chooseHeroAction(hero: HeroData, ctx: HeroAIContext): HeroAction {
  const scored = hero.actions.map((a) => {
    let w = a.weight;
    switch (a.when) {
      case "allyHurt":
        w *= ctx.lowestAllyHpPct < 0.45 ? 6 : 0.25;
        break;
      case "selfHurt":
        w *= ctx.selfHpPct < 0.4 ? 3.2 : 0.6;
        break;
      case "bossLow":
        w *= ctx.bossHpPct < 0.3 ? 2.2 : 1;
        break;
      default:
        break;
    }
    return { a, w };
  });
  const total = scored.reduce((s, x) => s + x.w, 0);
  let roll = Math.random() * total;
  for (const { a, w } of scored) {
    roll -= w;
    if (roll <= 0) return a;
  }
  return scored[0].a;
}
