// ============================================================
// Particle system. Emitters are created by animations at their
// spawnAt time and only despawn at their despawnAt time, so an
// emitter can outlive the animation that created it.
// Two modes: BURST (all particles once) and CONTINUOUS (loops
// spawning every `interval` until despawned).
// ============================================================

import type { ParticleEmitterDef, SpriteData } from "./types";
import { drawSpriteAt, resolveSprite } from "./sprites";

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  rot: number;
  vr: number;
  g: number;
  life: number;
  max: number;
  scale: number;
  spriteId: string;
  fade: boolean;
}

interface ActiveEmitter {
  def: ParticleEmitterDef;
  bornAt: number;
  lastSpawn: number;
  burstDone: boolean;
  x: number;
  y: number;
}

export class ParticleSystem {
  particles: Particle[] = [];
  private emitters: ActiveEmitter[] = [];
  time = 0;

  clear() {
    this.particles = [];
    this.emitters = [];
    this.time = 0;
  }

  /** create an emitter at world position (scene pixels) */
  spawnEmitter(def: ParticleEmitterDef, x: number, y: number) {
    this.emitters.push({ def, bornAt: this.time, lastSpawn: this.time, burstDone: false, x, y });
  }

  get emitterCount() {
    return this.emitters.length;
  }

  private emit(e: ActiveEmitter, n: number) {
    for (let i = 0; i < n; i++) {
      const ang = Math.random() * Math.PI * 2;
      const sp = e.def.speed * (0.4 + Math.random() * 0.8);
      const off = e.def.spread * Math.random();
      const oa = Math.random() * Math.PI * 2;
      this.particles.push({
        x: e.x + Math.cos(oa) * off,
        y: e.y + Math.sin(oa) * off,
        vx: (e.def.outward ? Math.cos(ang) * sp : 0) + e.def.driftX,
        vy: (e.def.outward ? Math.sin(ang) * sp : 0) + e.def.driftY,
        rot: Math.random() * 360,
        vr: e.def.rotSpeed,
        g: e.def.gravity,
        life: e.def.lifetime * (0.7 + Math.random() * 0.6),
        max: e.def.lifetime,
        scale: e.def.scale,
        spriteId: e.def.spriteId,
        fade: e.def.fade,
      });
    }
    // cap particles for performance
    if (this.particles.length > 600) this.particles.splice(0, this.particles.length - 600);
  }

  update(dt: number) {
    this.time += dt;
    // emitters
    for (let i = this.emitters.length - 1; i >= 0; i--) {
      const e = this.emitters[i];
      const age = this.time - e.bornAt;
      if (e.def.despawnAt != null && age >= e.def.despawnAt) {
        this.emitters.splice(i, 1);
        continue;
      }
      if (e.def.mode === "burst") {
        if (!e.burstDone) {
          this.emit(e, e.def.count);
          e.burstDone = true;
        }
      } else {
        const interval = Math.max(0.01, e.def.interval);
        while (this.time - e.lastSpawn >= interval) {
          e.lastSpawn += interval;
          this.emit(e, Math.max(1, e.def.count));
        }
      }
    }
    // particles
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.life -= dt;
      if (p.life <= 0) {
        this.particles.splice(i, 1);
        continue;
      }
      p.vy += p.g * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.rot += p.vr * dt;
    }
  }

  render(ctx: CanvasRenderingContext2D, lookup: (id: string) => SpriteData | null) {
    for (const p of this.particles) {
      const alpha = p.fade ? Math.max(0, Math.min(1, p.life / p.max)) : 1;
      const sprite = resolveSprite(p.spriteId, lookup(p.spriteId));
      const norm = sprite.kind === "image" ? 16 / sprite.h : 1;
      drawSpriteAt(ctx, sprite, p.x, p.y, p.scale * norm, p.rot, alpha);
    }
  }
}
