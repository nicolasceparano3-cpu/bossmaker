// ============================================================
// Canvas scene renderer for attacks. Used by the editor
// preview AND the battle soul-phase — one renderer, same data.
// Draws in attack-box coordinates; caller sets the transform.
// ============================================================

import type { AttackRuntime, ObjectState } from "./engine";
import { SOUL_RADIUS } from "./engine";
import type { AttackObject, SpriteData } from "./types";
import { drawSpriteAt, resolveSprite } from "./sprites";

export interface SceneOptions {
  time: number;
  spriteLookup: (id: string) => SpriteData | null;
  showCollisions?: boolean;
  selectedId?: string | null;
  showSoul?: boolean;
  showSoulHp?: boolean;
}

function drawWarningShape(ctx: CanvasRenderingContext2D, obj: AttackObject, st: ObjectState, time: number) {
  const flash = 0.55 + 0.45 * Math.sin(time * 12);
  const alpha = st.opacity * flash;
  if (alpha <= 0.01) return;
  ctx.save();
  ctx.translate(st.x, st.y);
  ctx.rotate((st.rot * Math.PI) / 180);
  ctx.globalAlpha = Math.min(1, alpha);
  if (obj.collision.type === "rect") {
    const w = obj.collision.w * st.scale;
    const h = obj.collision.h * st.scale;
    ctx.fillStyle = "rgba(255,32,64,0.16)";
    ctx.fillRect(-w / 2, -h / 2, w, h);
    ctx.strokeStyle = "#ff2040";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(-w / 2, -h / 2, w, h);
  } else if (obj.collision.type === "circle") {
    const r = obj.collision.radius * st.scale;
    ctx.fillStyle = "rgba(255,32,64,0.16)";
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#ff2040";
    ctx.lineWidth = 2;
    ctx.setLineDash([6, 4]);
    ctx.stroke();
  }
  ctx.restore();
}

function drawBeam(ctx: CanvasRenderingContext2D, obj: AttackObject, st: ObjectState) {
  if (obj.collision.type !== "rect" || st.opacity <= 0.01) return;
  const w = obj.collision.w * st.scale;
  const h = obj.collision.h * st.scale;
  ctx.save();
  ctx.translate(st.x, st.y);
  ctx.rotate((st.rot * Math.PI) / 180);
  ctx.globalAlpha = st.opacity;
  const g = ctx.createLinearGradient(0, -h / 2, 0, h / 2);
  g.addColorStop(0, "rgba(255,255,255,0.1)");
  g.addColorStop(0.5, "rgba(255,255,255,0.95)");
  g.addColorStop(1, "rgba(255,255,255,0.1)");
  ctx.fillStyle = g;
  ctx.fillRect(-w / 2, -h / 2, w, h);
  ctx.restore();
}

function drawCollision(ctx: CanvasRenderingContext2D, obj: AttackObject, st: ObjectState, color: string) {
  if (obj.collision.type === "none") return;
  ctx.save();
  ctx.translate(st.x, st.y);
  ctx.rotate((st.rot * Math.PI) / 180);
  ctx.globalAlpha = 0.9;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  if (obj.collision.type === "circle") {
    ctx.beginPath();
    ctx.arc(0, 0, obj.collision.radius * st.scale, 0, Math.PI * 2);
    ctx.stroke();
  } else {
    const w = obj.collision.w * st.scale;
    const h = obj.collision.h * st.scale;
    ctx.strokeRect(-w / 2, -h / 2, w, h);
  }
  ctx.restore();
}

export function renderScene(ctx: CanvasRenderingContext2D, rt: AttackRuntime, opts: SceneOptions) {
  const box = rt.boxAt(opts.time);
  // backdrop — the inside of the attack box is pure black
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, box.width, box.height);

  for (const { obj, st } of rt.allStates(opts.time)) {
    if (!st.active && !opts.showCollisions) continue;
    if (obj.kind === "warning") {
      drawWarningShape(ctx, obj, st, opts.time);
    } else if (obj.spriteId === "rect") {
      drawBeam(ctx, obj, st);
    } else {
      const sprite = resolveSprite(obj.spriteId, opts.spriteLookup(obj.spriteId));
      // uploaded images are normalized to a 16px-tall base so they behave
      // like built-in sprites regardless of their original resolution
      const norm = sprite.kind === "image" ? 16 / sprite.h : 1;
      drawSpriteAt(ctx, sprite, st.x, st.y, st.scale * 2 * norm, st.rot, st.opacity);
    }
    if (opts.showCollisions && obj.damageMult > 0 && obj.collision.type !== "none" && st.active) {
      drawCollision(ctx, obj, st, "rgba(70,230,160,0.9)");
    }
    if (opts.selectedId === obj.id) {
      drawCollision(ctx, obj, st, "#ffe14d");
      ctx.save();
      ctx.strokeStyle = "#ffe14d";
      ctx.setLineDash([3, 3]);
      ctx.strokeRect(st.x - 16 * st.scale, st.y - 16 * st.scale, 32 * st.scale, 32 * st.scale);
      ctx.restore();
    }
  }

  if (opts.showSoul !== false && rt.soul.alive) {
    const blinkOff = rt.soul.invulnT > 0 && Math.floor(opts.time * 14) % 2 === 0;
    if (!blinkOff) {
      const sprite = resolveSprite("soul", null);
      drawSpriteAt(ctx, sprite, rt.soul.x, rt.soul.y, 1.4, 0, 1);
      // hitbox dot (the real collision)
      ctx.save();
      ctx.globalAlpha = 0.9;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath();
      ctx.arc(rt.soul.x, rt.soul.y, SOUL_RADIUS * 0.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  if (opts.showSoulHp) {
    const pct = Math.max(0, rt.soul.hp / rt.soul.maxHp);
    const w = Math.min(140, box.width - 20);
    const x = box.width / 2 - w / 2;
    ctx.save();
    ctx.globalAlpha = 0.95;
    ctx.fillStyle = "#1a1a24";
    ctx.fillRect(x - 2, 8, w + 4, 10);
    ctx.fillStyle = "#ff2040";
    ctx.fillRect(x, 10, w * pct, 6);
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 1;
    ctx.strokeRect(x - 2.5, 7.5, w + 5, 11);
    ctx.restore();
  }
}
