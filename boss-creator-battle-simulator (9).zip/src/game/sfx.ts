// ============================================================
// Tiny WebAudio synth for retro battle sounds. No audio files;
// everything is generated square/triangle blips.
// ============================================================

let ctx: AudioContext | null = null;
let enabled = true;

export function setSfxEnabled(on: boolean) {
  enabled = on;
}
export function sfxEnabled() {
  return enabled;
}

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return null;
    ctx = new AC();
  }
  if (ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

function tone(freq: number, dur: number, type: OscillatorType, vol = 0.08, slide = 0) {
  if (!enabled) return;
  const a = ac();
  if (!a) return;
  try {
    const o = a.createOscillator();
    const g = a.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, a.currentTime);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(30, freq + slide), a.currentTime + dur);
    g.gain.setValueAtTime(vol, a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + dur);
    o.connect(g).connect(a.destination);
    o.start();
    o.stop(a.currentTime + dur + 0.02);
  } catch {
    /* ignore */
  }
}

function noise(dur: number, vol = 0.08) {
  if (!enabled) return;
  const a = ac();
  if (!a) return;
  try {
    const len = Math.floor(a.sampleRate * dur);
    const buf = a.createBuffer(1, len, a.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = a.createBufferSource();
    src.buffer = buf;
    const g = a.createGain();
    g.gain.setValueAtTime(vol, a.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, a.currentTime + dur);
    src.connect(g).connect(a.destination);
    src.start();
  } catch {
    /* ignore */
  }
}

// ---------------- sound library (for attack objects) ----------------

export interface SfxPreset {
  id: string;
  name: string;
  play: () => void;
}

export const SFX_LIBRARY: SfxPreset[] = [
  { id: "shoot", name: "SHOOT", play: () => tone(420, 0.05, "square", 0.05, -160) },
  { id: "laser", name: "LASER", play: () => tone(1200, 0.12, "sawtooth", 0.05, -900) },
  { id: "boom", name: "BOOM", play: () => { noise(0.3, 0.12); tone(90, 0.25, "sine", 0.1, -40); } },
  { id: "whoosh", name: "WHOOSH", play: () => noise(0.18, 0.06) },
  { id: "warn", name: "WARNING", play: () => { tone(220, 0.1, "square", 0.06); setTimeout(() => tone(220, 0.1, "square", 0.06), 140); } },
  { id: "hit", name: "HIT", play: () => { noise(0.12, 0.1); tone(180, 0.1, "square", 0.08, -80); } },
  { id: "soulhit", name: "SOUL HIT", play: () => { noise(0.08, 0.09); tone(1400, 0.07, "square", 0.06, -700); } },
  { id: "sparkle", name: "SPARKLE", play: () => [880, 1174, 1568].forEach((f, i) => setTimeout(() => tone(f, 0.06, "triangle", 0.05), i * 40)) },
  { id: "chime", name: "CHIME", play: () => { tone(660, 0.15, "triangle", 0.07); setTimeout(() => tone(990, 0.2, "triangle", 0.06), 90); } },
  { id: "fade", name: "FADE OUT", play: () => tone(300, 0.18, "triangle", 0.05, -220) },
];

export function playSfxPreset(id: string) {
  SFX_LIBRARY.find((s) => s.id === id)?.play();
}

/** Play an uploaded audio asset (data url). */
export function playAudioUrl(url: string, loop = false, volume = 0.8): HTMLAudioElement | null {
  if (!enabled) return null;
  try {
    const a = new Audio(url);
    a.loop = loop;
    a.volume = volume;
    a.play().catch(() => {});
    return a;
  } catch {
    return null;
  }
}

export const sfx = {
  move: () => tone(520, 0.04, "square", 0.03),
  select: () => tone(760, 0.06, "square", 0.05),
  confirm: () => {
    tone(620, 0.05, "square", 0.05);
    setTimeout(() => tone(930, 0.07, "square", 0.05), 55);
  },
  cancel: () => tone(300, 0.08, "square", 0.05, -80),
  hit: () => {
    noise(0.12, 0.1);
    tone(180, 0.1, "square", 0.08, -80);
  },
  hurt: () => {
    noise(0.15, 0.1);
    tone(120, 0.16, "sawtooth", 0.08, -50);
  },
  heal: () => {
    tone(520, 0.08, "triangle", 0.07);
    setTimeout(() => tone(660, 0.08, "triangle", 0.07), 80);
    setTimeout(() => tone(880, 0.12, "triangle", 0.07), 160);
  },
  tp: () => tone(980, 0.05, "triangle", 0.05),
  shoot: () => tone(420, 0.05, "square", 0.04, -160),
  warn: () => {
    tone(220, 0.1, "square", 0.06);
    setTimeout(() => tone(220, 0.1, "square", 0.06), 140);
  },
  soulHit: () => {
    noise(0.08, 0.09);
    tone(1400, 0.07, "square", 0.06, -700);
  },
  victory: () => {
    [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => tone(f, 0.16, "square", 0.06), i * 130));
  },
  defeat: () => {
    [392, 330, 262, 196].forEach((f, i) => setTimeout(() => tone(f, 0.22, "triangle", 0.08), i * 170));
  },
};
