// ============================================================
// SOUL AI — behaves like a human player trying to dodge.
// Continuously re-evaluates: hazards -> predicted positions ->
// safe locations -> best escape -> movement with acceleration.
// Difficulty controls reaction, prediction, speed and mistakes.
// Not hard-wired to a single SOUL: it only reads/writes the
// runtime's soul state, so multiple souls could use instances.
// ============================================================

import type { AttackObject, SoulAIDifficulty } from "./types";
import type { AttackRuntime, ObjectState } from "./engine";
import { SOUL_RADIUS } from "./engine";

interface ThreatInfo {
  obj: AttackObject;
  st: ObjectState;
  px: number; // predicted pos at horizon
  py: number;
  r: number; // collision radius approx (circle) or half-diagonal (rect)
  hw: number; // rect half extents (0 for circles)
  hh: number;
  isRect: boolean;
  warning: boolean; // telegraph objects get a softer penalty
  firstSeen: number;
}

function distToRect(px: number, py: number, cx: number, cy: number, hw: number, hh: number): number {
  const dx = Math.max(Math.abs(px - cx) - hw, 0);
  const dy = Math.max(Math.abs(py - cy) - hh, 0);
  return Math.hypot(dx, dy);
}

export function createSoulAI(diff: SoulAIDifficulty): (dt: number, rt: AttackRuntime) => void {
  let target = { x: -1, y: -1 };
  let replanT = 0;
  let panicT = 0;
  const seenAt = new Map<string, number>();

  function gatherThreats(rt: AttackRuntime): ThreatInfo[] {
    const threats: ThreatInfo[] = [];
    for (const obj of rt.attack.objects) {
      if (obj.kind === "effect") continue;
      const isWarningObj = obj.kind === "warning";
      if (!isWarningObj && (obj.damageMult <= 0 || obj.collision.type === "none")) continue;
      if (isWarningObj && obj.collision.type === "none") continue;
      const st = rt.stateOf(obj, rt.time);
      if (!st.active || st.opacity < 0.05) {
        seenAt.delete(obj.id);
        continue;
      }
      if (!seenAt.has(obj.id)) seenAt.set(obj.id, rt.time);
      // reaction delay: threats are invisible to the AI until noticed
      if (rt.time - (seenAt.get(obj.id) ?? rt.time) < diff.reaction) continue;
      const p = rt.predictPos(obj, rt.time + diff.predict);
      const isRect = obj.collision.type === "rect";
      const hw = obj.collision.type === "rect" ? (obj.collision.w / 2) * st.scale : 0;
      const hh = obj.collision.type === "rect" ? (obj.collision.h / 2) * st.scale : 0;
      const r =
        obj.collision.type === "circle"
          ? obj.collision.radius * st.scale
          : Math.hypot(hw, hh);
      threats.push({ obj, st, px: p.x, py: p.y, r, hw, hh, isRect, warning: isWarningObj, firstSeen: seenAt.get(obj.id)! });
    }
    return threats;
  }

  function segDistSq(px: number, py: number, ax: number, ay: number, bx: number, by: number) {
    const abx = bx - ax;
    const aby = by - ay;
    const len = abx * abx + aby * aby;
    let t = len === 0 ? 0 : ((px - ax) * abx + (py - ay) * aby) / len;
    t = Math.max(0, Math.min(1, t));
    const dx = px - (ax + abx * t);
    const dy = py - (ay + aby * t);
    return dx * dx + dy * dy;
  }

  function scorePoint(rt: AttackRuntime, x: number, y: number, threats: ThreatInfo[]): number {
    const box = rt.boxAt(rt.time);
    let score = 0;
    for (const th of threats) {
      if (th.isRect) {
        // distance to the (axis-approximated) rect now and at the predicted position
        const dNow = distToRect(x, y, th.st.x, th.st.y, th.hw, th.hh);
        const dFut = distToRect(x, y, th.px, th.py, th.hw, th.hh);
        const d = Math.min(dNow, dFut);
        if (th.warning) {
          if (d < SOUL_RADIUS + 3) score += 900;
          else score += Math.max(0, 70 - d * 0.6);
        } else if (d < SOUL_RADIUS + 3) score += 10000;
        else score += Math.max(0, 130 - d * 0.9);
        continue;
      }
      if (th.warning) {
        const dW = Math.hypot(x - th.st.x, y - th.st.y) - th.r;
        if (dW < SOUL_RADIUS + 3) score += 900;
        else score += Math.max(0, 70 - dW * 0.6);
        continue;
      }
      const danger = th.r + SOUL_RADIUS;
      // current position danger
      const dNowSq = (x - th.st.x) ** 2 + (y - th.st.y) ** 2;
      if (dNowSq < (danger + 2) ** 2) score += 10000;
      else score += Math.max(0, 90 - Math.sqrt(dNowSq) * 0.5);
      // swept path danger (prediction)
      const dSq = segDistSq(x, y, th.st.x, th.st.y, th.px, th.py);
      const range = danger * 3.2;
      if (dSq < range * range) {
        const d = Math.sqrt(dSq);
        score += (1 - d / range) * 320;
        if (d < danger + 4) score += 2500;
      }
    }
    // wall penalty — avoid being cornered
    const m = 26;
    const wallD = Math.min(x, y, box.width - x, box.height - y);
    if (wallD < m) score += ((m - wallD) / m) * 220;
    // gentle center preference (keeps escape routes open)
    const cx = box.width / 2;
    const cy = box.height / 2;
    score += (Math.hypot(x - cx, y - cy) / Math.hypot(cx, cy)) * 24;
    // travel cost
    score += Math.hypot(x - rt.soul.x, y - rt.soul.y) * 0.55;
    return score;
  }

  function pickTarget(rt: AttackRuntime) {
    const box = rt.attack.box;
    const threats = gatherThreats(rt);
    const pad = SOUL_RADIUS + 4;
    const cell = 22;
    const candidates: { x: number; y: number; s: number }[] = [];
    for (let x = pad; x <= box.width - pad; x += cell) {
      for (let y = pad; y <= box.height - pad; y += cell) {
        let s = scorePoint(rt, x, y, threats);
        s += Math.random() * diff.noise * 2;
        candidates.push({ x, y, s });
      }
    }
    if (!candidates.length) return;
    candidates.sort((a, b) => a.s - b.s);
    let pick = candidates[0];
    // sloppy difficulties sometimes choose a bad spot or freeze
    if (Math.random() < diff.mistake) {
      pick = candidates[Math.floor(Math.random() * Math.min(6, candidates.length))];
    }
    target = { x: pick.x, y: pick.y };
  }

  return function soulAITick(dt: number, rt: AttackRuntime) {
    const s = rt.soul;
    if (!s.alive) return;
    const box = rt.boxAt(rt.time);
    replanT -= dt;
    panicT -= dt;

    // urgent reaction: anything heading straight for us?
    const threats = gatherThreats(rt);
    let urgent = false;
    for (const th of threats) {
      if (th.warning) continue;
      const d = th.isRect
        ? distToRect(s.x, s.y, th.st.x, th.st.y, th.hw, th.hh)
        : Math.hypot(th.st.x - s.x, th.st.y - s.y) - th.r;
      if (d < SOUL_RADIUS + 26) {
        urgent = true;
        break;
      }
    }
    if (target.x < 0 || replanT <= 0 || (urgent && panicT <= 0)) {
      pickTarget(rt);
      replanT = diff.replan * (0.75 + Math.random() * 0.5);
      if (urgent) panicT = 0.12;
    }

    // move toward target with acceleration / deceleration
    const dx = target.x - s.x;
    const dy = target.y - s.y;
    const dist = Math.hypot(dx, dy);
    const maxSp = diff.speed * (panicT > 0 ? 1.15 : 1);
    const desiredSp = dist > 3 ? Math.min(maxSp, 40 + dist * 3.2) : 0;
    const dvx = dist > 0.001 ? (dx / dist) * desiredSp : 0;
    const dvy = dist > 0.001 ? (dy / dist) * desiredSp : 0;
    const ax = (dvx - s.vx) / Math.max(dt, 1e-4);
    const ay = (dvy - s.vy) / Math.max(dt, 1e-4);
    const aMag = Math.hypot(ax, ay);
    const aClamp = Math.min(1, diff.accel / Math.max(aMag, 1e-4));
    s.vx += ax * aClamp * dt;
    s.vy += ay * aClamp * dt;
    const sp = Math.hypot(s.vx, s.vy);
    if (sp > maxSp) {
      s.vx = (s.vx / sp) * maxSp;
      s.vy = (s.vy / sp) * maxSp;
    }
    s.x += s.vx * dt;
    s.y += s.vy * dt;
    s.x = Math.max(SOUL_RADIUS, Math.min(box.width - SOUL_RADIUS, s.x));
    s.y = Math.max(SOUL_RADIUS, Math.min(box.height - SOUL_RADIUS, s.y));
  };
}
