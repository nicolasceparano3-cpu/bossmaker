"use client";
// ============================================================
// Resolves object sound ids and plays them. 'default' uses the
// caller-provided fallback preset, 'none' is silent, presets are
// synthesized, and 'asset:<id>' plays an uploaded audio asset.
// ============================================================

import { playAudioUrl, playSfxPreset } from "./sfx";
import { store } from "./store";

export function playObjectSound(value: string | undefined, fallback: string) {
  const id = value === undefined ? fallback : value;
  if (!id || id === "none" || id === "default") {
    if (id === "default") playSfxPreset(fallback);
    return;
  }
  if (id.startsWith("asset:")) {
    const a = store.get(id.slice(6));
    const url = (a?.data as { dataUrl?: string } | undefined)?.dataUrl;
    if (url) playAudioUrl(url);
    return;
  }
  playSfxPreset(id);
}
