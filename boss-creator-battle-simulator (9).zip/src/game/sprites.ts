// ============================================================
// Built-in pixel sprites. Each sprite is a grid of characters
// mapped to palette colors, drawn to an offscreen canvas once
// and cached. imageSmoothing is disabled everywhere so art
// stays crisp at any integer scale.
// ============================================================

import type { SpriteData } from "./types";

export interface BuiltinSprite {
  grid: string[];
  palette: Record<string, string>;
}

export const BUILTIN_SPRITES: Record<string, BuiltinSprite> = {
  // --- SOUL heart ---
  soul: {
    palette: { r: "#ff2040", R: "#ff7080" },
    grid: [
      ".rr...rr.",
      "rRrr.rrrr",
      "rrrrrrrrr",
      "rrrrrrrrr",
      ".rrrrrrr.",
      "..rrrrr..",
      "...rrr...",
      "....r....",
    ],
  },
  // --- heroes (recreated from reference pixel art) ---
  kris: {
    palette: {
      h: "#0d0d22", t: "#46e6ff", s: "#5ff0c8", S: "#16323e",
      d: "#101028", D: "#1e1e40", p: "#ff2f92", w: "#dfe8f4",
      b: "#cdd6ea", Y: "#f6c9cf", g: "#6e0f2a",
    },
    grid: [
      "....hhhhhhhh...........",
      "...hhhhhhhhhh......YYY.",
      "..hhhhhhhhhhhh....YYYY.",
      "..hhthhhhhhhhh...YYY...",
      ".hhhtthhhhhhhh..YYY....",
      ".hhhtsssssshhh.YYY.....",
      ".hhhsssssssssh.YY......",
      "..hsssssssssh..YY......",
      "..hssSssSsssh...YY.....",
      "...ssssssss....YY......",
      "...dddddddd.....YY.....",
      "..dppddddddd....YY.....",
      ".dpppdddwwddd..ggg.....",
      ".dpppddwwwwdd.sgg......",
      ".ddddddwwwwd.sgg.......",
      "..dddddwwwwd.gg........",
      "..dddwwwwwwgg..........",
      "...dddddddd............",
      "...dd....dd............",
      "...dd....dd............",
      "...Dd....dD............",
      "...DD....DD............",
      "..bbb....bbb...........",
      ".bbbb....bbbb..........",
    ],
  },
  susie: {
    palette: {
      m: "#7a2a5a", u: "#c99ad4", U: "#2a1030", k: "#180f2c",
      y: "#ffd23f", T: "#5ff0c8", A: "#a8aec4", a: "#4a3050",
      o: "#e8a020",
    },
    grid: [
      ".........mmmm..........",
      "........mmmmmm.........",
      ".......mmmmmmmm........",
      "......mmmmmmmmm........",
      "......mmuuuumm.........",
      ".TT...mmuuuumm.........",
      "TTTT..muuuuuum.........",
      "TTTTA.muuUuUum.........",
      "AAAAA.muuuuuum.........",
      ".AAA..mmuuuumm.........",
      "..a...mmmmmmmm.........",
      "..a..kkkkkkkkk.........",
      "..aa.kkykkykkk.........",
      "...a.kkkkkkkkk.........",
      "....kkuukkuukk.........",
      "....kkkkkkkkkk.........",
      ".....kkkkkkkk..........",
      ".....kk....kk..........",
      ".....kk....kk..........",
      ".....oo....oo..........",
      "....ooo....ooo.........",
    ],
  },
  ralsei: {
    palette: {
      w: "#f4f4f8", p: "#ff9ec4", P: "#ff5fae", g: "#35d08a",
      G: "#0e3a2a", n: "#3f8f6a", e: "#101018", d: "#202028",
    },
    grid: [
      "..p........p........",
      "..pp......pp........",
      "..pwwwwwwwwp........",
      ".pwwwwwwwwwwp.......",
      ".wwwwwwwwwwww.......",
      ".wggwwwwwggw........",
      ".wgGgwwwgGgw........",
      ".wwggwwwwggww.......",
      "..wwwwddwwww........",
      "..PPPPPPPPPP........",
      ".PPPPPPPPPPPP.......",
      ".wnnnnnnnnnnP.......",
      "wnnnnneennnnnw......",
      "wnnnneeeennnnw......",
      ".nnnneeeennnn.......",
      ".nnnnnnnnnnn........",
      ".nnnnnnnnnnn........",
      "..nnnnnnnnn.........",
      "..nn.....nn.........",
      ".ww.......ww........",
      ".wp.......pw........",
    ],
  },
  noelle: {
    palette: { a: "#b0713a", y: "#f0d060", s: "#f5deb3", d: "#3f5f8f", e: "#1a1a1a", w: "#fff" },
    grid: [
      ".a...yy...a.",
      ".a..yyyy..a.",
      "...yyyyyy...",
      "...yssssy...",
      "...sessey...",
      "....ssss....",
      "..dddddddd..",
      ".d.dwddwd.d.",
      "...dddddd...",
      "...dddddd...",
      "...dd..dd...",
      "..ddd..ddd..",
    ],
  },
  // --- default bosses ---
  boss_grim: {
    palette: { d: "#2a1f3d", D: "#3d2d5c", p: "#7b4fb0", e: "#ff2040", E: "#ffd23f", c: "#c9c9d9", h: "#141021" },
    grid: [
      "..c..........c..",
      "..cc........cc..",
      "...cchhhhhhcc...",
      "....chhhhhhc....",
      "...chhhhhhhhc...",
      "...chEhhhEhhc...",
      "...chhhhhhhhc...",
      "....chhddhhc....",
      "..DDDddddddDDD..",
      ".DppDddddddDppD.",
      ".DppddddddddppD.",
      "..DddddddddddD..",
      "..DddddddddddD..",
      "...dddddddddd...",
      "...ddDddddDdd...",
      "...dd.dddd.dd...",
      "..ddd..dd..ddd..",
    ],
  },
  boss_fang: {
    palette: { b: "#1d2b53", B: "#2e4a8f", e: "#46e6ff", f: "#fff", r: "#ff2040", h: "#0d1530" },
    grid: [
      ".f....ffff....f.",
      ".ff..ffffff..ff.",
      "..fhhhhhhhhhhf..",
      "..hbbbbbbbbb bh..",
      ".hbbbebbbbebbh..",
      ".hbbbbbbbbbbbh..",
      ".hbbffbbffbbbh..",
      "..hbbbrrbbb bh..",
      "..BBbbbbbbbbBB..",
      ".BrrBbbbbbbBrrB.",
      ".BBBBbbbbbbBBBB.",
      "..BBbbbbbbbbBB..",
      "...bbbbbbbbbb...",
      "...bb.bbbb.bb...",
      "..bbb..bb..bbb..",
    ],
  },
  // --- projectiles / objects ---
  bullet: {
    palette: { w: "#ffffff", s: "#9aa0b4" },
    grid: ["...ww...", "..wwww..", ".wwwwww.", "wwwwwwww", "wwwwwwww", ".wwwwww.", "..wwww..", "...ww..."],
  },
  orb: {
    palette: { y: "#ffd23f", Y: "#fff3b0", o: "#ff8c1a" },
    grid: ["..YYYY..", ".YyyyyY.", "Yyyyyyyo", "Yyyyyyyo", "yyyyyyoo", ".yyyyoo.", "..oooo..", "...oo..."],
  },
  blade: {
    palette: { g: "#c9c9d9", G: "#8a8aa0", e: "#3a3a4a" },
    grid: ["....g....", "...ggg...", "..ggggg..", ".ggGgGgg.", "gggGeGggg", ".ggGgGgg.", "..ggggg..", "...ggg...", "....g...."],
  },
  fireball: {
    palette: { r: "#ff5722", y: "#ffd23f", R: "#c62828" },
    grid: ["...y....", "..yyy...", ".yyryy..", ".yrrry..", "yyrrrRy.", ".yrrrR..", "..rRR...", "...RR..."],
  },
  bone: {
    palette: { w: "#f2f2f2", s: "#c9c9c9" },
    grid: [".ww.ww.", "wwwwwww", ".wwwww.", "..www..", "..www..", "..www..", ".wwwww.", "wwwwwww", ".ww.ww."],
  },
  spark: {
    palette: { c: "#46e6ff", w: "#ffffff" },
    grid: ["...c...", "...c...", "cc.c.cc", "..cwc..", "cc.c.cc", "...c...", "...c..."],
  },
  knife: {
    palette: { g: "#e8e8f0", G: "#9a9ab0", h: "#7b4fb0" },
    grid: ["....g....", "...ggg...", "...ggg...", "...gGg...", "...gGg...", "...gGg...", "....G....", "...hhh...", "...hhh...", "..hhhhh.."],
  },
  darkOrb: {
    palette: { d: "#3d2d5c", p: "#7b4fb0", e: "#ff2040" },
    grid: [
      "..dddd..",
      ".dppppd.",
      "dppeeepp",
      "dppeeepp",
      "dppppppd",
      "dppppppd",
      ".dppppd.",
      "..dddd..",
    ],
  },
};

export function builtinToSpriteData(id: string): SpriteData {
  const b = BUILTIN_SPRITES[id];
  return { name: id, type: "builtin", grid: b.grid, palette: b.palette };
}

// ---------------- rendering helpers (client-side) ----------------

const gridCache = new Map<string, HTMLCanvasElement>();
const imageCache = new Map<string, HTMLImageElement>();

export function gridCacheKey(grid: string[], palette: Record<string, string>): string {
  return grid.join("|") + "#" + Object.keys(palette).map((k) => `${k}:${palette[k]}`).join(",");
}

export function renderGridToCanvas(grid: string[], palette: Record<string, string>): HTMLCanvasElement {
  const key = gridCacheKey(grid, palette);
  const cached = gridCache.get(key);
  if (cached) return cached;
  const h = grid.length;
  const w = Math.max(1, ...grid.map((r) => r.length));
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const ctx = c.getContext("2d")!;
  for (let y = 0; y < h; y++) {
    const row = grid[y];
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      if (ch === "." || ch === " ") continue;
      const col = palette[ch];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x, y, 1, 1);
    }
  }
  gridCache.set(key, c);
  return c;
}

export interface DrawableSprite {
  kind: "canvas" | "image";
  canvas?: HTMLCanvasElement;
  img?: HTMLImageElement;
  w: number;
  h: number;
  ready: boolean;
}

/** Resolve a sprite id (builtin or custom SpriteData) into something drawable. */
export function resolveSprite(spriteId: string, custom?: SpriteData | null): DrawableSprite {
  const builtin = BUILTIN_SPRITES[spriteId];
  if (builtin) {
    const c = renderGridToCanvas(builtin.grid, builtin.palette);
    return { kind: "canvas", canvas: c, w: c.width, h: c.height, ready: true };
  }
  if (custom) {
    if (custom.type === "pixels" && custom.grid && custom.palette) {
      const c = renderGridToCanvas(custom.grid, custom.palette);
      return { kind: "canvas", canvas: c, w: c.width, h: c.height, ready: true };
    }
    if (custom.type === "image" && custom.dataUrl) {
      let img = imageCache.get(custom.dataUrl);
      if (!img) {
        img = new Image();
        img.src = custom.dataUrl;
        imageCache.set(custom.dataUrl, img);
      }
      return {
        kind: "image",
        img,
        w: img.naturalWidth || 16,
        h: img.naturalHeight || 16,
        ready: img.complete && img.naturalWidth > 0,
      };
    }
  }
  // fallback dot
  const c = renderGridToCanvas(["ww", "ww"], { w: "#ffffff" });
  return { kind: "canvas", canvas: c, w: 2, h: 2, ready: true };
}

export function drawSpriteAt(
  ctx: CanvasRenderingContext2D,
  sprite: DrawableSprite,
  x: number,
  y: number,
  scale: number,
  rotDeg: number,
  alpha: number
) {
  if (!sprite.ready || alpha <= 0.01) return;
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((rotDeg * Math.PI) / 180);
  ctx.scale(scale, scale);
  ctx.globalAlpha = Math.max(0, Math.min(1, alpha));
  ctx.imageSmoothingEnabled = false;
  const w = sprite.w;
  const h = sprite.h;
  if (sprite.kind === "canvas" && sprite.canvas) {
    ctx.drawImage(sprite.canvas, -w / 2, -h / 2);
  } else if (sprite.img) {
    ctx.drawImage(sprite.img, -w / 2, -h / 2);
  }
  ctx.restore();
}

export function spriteDataUrlFromGrid(grid: string[], palette: Record<string, string>, px = 8): string {
  const h = grid.length;
  const w = Math.max(1, ...grid.map((r) => r.length));
  const c = document.createElement("canvas");
  c.width = w * px;
  c.height = h * px;
  const ctx = c.getContext("2d")!;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < grid[y].length; x++) {
      const col = palette[grid[y][x]];
      if (!col) continue;
      ctx.fillStyle = col;
      ctx.fillRect(x * px, y * px, px, px);
    }
  }
  return c.toDataURL();
}
