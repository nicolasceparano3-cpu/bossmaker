"use client";
// ============================================================
// Client asset store. Primary persistence is the Postgres API;
// if the API is unavailable (static hosts, no DATABASE_URL) it
// transparently falls back to browser localStorage so the game
// remains fully playable anywhere.
// ============================================================

import { useSyncExternalStore } from "react";
import type { Asset, AssetKind, BossData, AttackData, AbilityData, SpriteData } from "./types";
import { uid } from "./types";
import { seedAssets } from "./defaults";

type Row = Asset;

const LOCAL_KEY = "bossmaker.assets.v1";

class AssetStore {
  private rows: Row[] = [];
  private listeners = new Set<() => void>();
  private loading: Promise<void> | null = null;
  private useLocal = false;
  loaded = false;
  error: string | null = null;

  subscribe = (fn: () => void) => {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  };

  getSnapshot = () => this.rows;

  get usingLocal() {
    return this.useLocal;
  }

  private emit() {
    for (const l of this.listeners) l();
  }

  private persistLocal() {
    try {
      localStorage.setItem(LOCAL_KEY, JSON.stringify(this.rows));
    } catch {
      /* storage may be unavailable/full — ignore */
    }
  }

  private loadLocal(): Row[] {
    try {
      const raw = localStorage.getItem(LOCAL_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed as Row[];
      }
    } catch {
      /* ignore */
    }
    const seeds = seedAssets().map((s) => ({
      id: s.id,
      kind: s.kind,
      name: s.name,
      data: s.data,
      updatedAt: Date.now(),
    })) as unknown as Row[];
    this.rows = seeds;
    this.persistLocal();
    return seeds;
  }

  ensureLoaded(): Promise<void> {
    if (this.loading) return this.loading;
    this.loading = (async () => {
      try {
        const res = await fetch("/api/assets");
        if (!res.ok) throw new Error(`http ${res.status}`);
        const json = await res.json();
        if (json.error || !Array.isArray(json.assets)) throw new Error(String(json.error ?? "bad payload"));
        this.useLocal = false;
        this.rows = json.assets as Row[];
      } catch {
        // API unreachable (static hosting, missing DATABASE_URL...) -> browser storage
        this.useLocal = true;
        this.rows = this.loadLocal();
      } finally {
        this.loaded = true;
        this.emit();
      }
    })();
    return this.loading;
  }

  all(): Row[] {
    return this.rows;
  }

  byKind<T>(kind: AssetKind): Asset<T>[] {
    return this.rows.filter((r) => r.kind === kind) as Asset<T>[];
  }

  get(id: string): Row | undefined {
    return this.rows.find((r) => r.id === id);
  }

  spriteData(id: string): SpriteData | null {
    const row = this.get(id);
    if (row && row.kind === "sprite") return row.data as SpriteData;
    return null;
  }

  async create<T>(kind: AssetKind, name: string, data: T, id?: string): Promise<Asset<T>> {
    const row = {
      id: id || uid(kind || "asset"),
      kind,
      name,
      data,
      updatedAt: Date.now(),
    } as unknown as Row;
    if (!this.useLocal) {
      try {
        const res = await fetch("/api/assets", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: row.id, kind, name, data }),
        });
        const json = await res.json();
        if (json.error) throw new Error(json.error);
        const saved = json.asset as Row;
        this.rows = [...this.rows, saved];
        this.emit();
        return saved as Asset<T>;
      } catch {
        this.useLocal = true;
      }
    }
    this.rows = [...this.rows, row];
    this.persistLocal();
    this.emit();
    return row as Asset<T>;
  }

  async update<T>(id: string, name: string, data: T): Promise<void> {
    const existing = this.get(id);
    const apply = () => {
      this.rows = this.rows.map((r) => (r.id === id ? { ...r, name, data, updatedAt: Date.now() } : r));
      this.emit();
    };
    if (!this.useLocal) {
      try {
        const res = await fetch(`/api/assets/${id}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name, data, kind: existing?.kind }),
        });
        const json = await res.json();
        if (json.error) throw new Error(json.error);
        apply();
        return;
      } catch {
        this.useLocal = true;
      }
    }
    apply();
    this.persistLocal();
  }

  async duplicate(id: string): Promise<Row | null> {
    const src = this.get(id);
    if (!src) return null;
    const copy = JSON.parse(JSON.stringify(src.data));
    if (copy && typeof copy === "object" && "name" in copy) copy.name = `${src.name} (copy)`;
    return this.create(src.kind as AssetKind, `${src.name} (copy)`, copy);
  }

  async remove(id: string): Promise<void> {
    if (!this.useLocal) {
      try {
        const res = await fetch(`/api/assets/${id}`, { method: "DELETE" });
        if (!res.ok) throw new Error(`http ${res.status}`);
      } catch {
        this.useLocal = true;
      }
    }
    this.rows = this.rows.filter((r) => r.id !== id);
    if (this.useLocal) this.persistLocal();
    this.emit();
  }

  resolveAbility(id: string): Asset<AbilityData> | undefined {
    return this.get(id) as Asset<AbilityData> | undefined;
  }
  resolveAttack(id: string): Asset<AttackData> | undefined {
    return this.get(id) as Asset<AttackData> | undefined;
  }
  resolveBoss(id: string): Asset<BossData> | undefined {
    return this.get(id) as Asset<BossData> | undefined;
  }
}

export const store = new AssetStore();

export function useAssets(): Row[] {
  return useSyncExternalStore(store.subscribe, store.getSnapshot, () => []);
}

// ---------------- battle config persistence ----------------

export interface BattleConfig {
  bossId: string;
  heroIds: string[];
  soulDifficulty: string;
  speed: number;
}

const CFG_KEY = "bossmaker.battleConfig";

export function loadBattleConfig(): BattleConfig {
  try {
    const raw = localStorage.getItem(CFG_KEY);
    if (raw) return JSON.parse(raw) as BattleConfig;
  } catch {
    /* ignore */
  }
  return { bossId: "boss_test", heroIds: ["kris", "susie", "ralsei"], soulDifficulty: "normal", speed: 1 };
}

export function saveBattleConfig(cfg: BattleConfig) {
  try {
    localStorage.setItem(CFG_KEY, JSON.stringify(cfg));
  } catch {
    /* ignore */
  }
}

export function downloadJson(filename: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
