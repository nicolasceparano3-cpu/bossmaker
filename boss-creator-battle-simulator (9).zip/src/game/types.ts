// ============================================================
// Core data model. Everything (bosses, attacks, abilities,
// sprites) is stored as plain data objects so the editor and
// the battle engine always share the exact same definitions.
// ============================================================

export type AssetKind = "boss" | "attack" | "ability" | "sprite" | "sound" | "animation" | "hero";

export interface SoundData {
  name: string;
  dataUrl: string;
}

// ---------------- animations & particles ----------------

/** one frame of a sprite-swap animation */
export interface AnimFrame {
  spriteId: string;
  duration: number; // seconds
}

export type ParticleAnchor =
  | "boss"
  | "hero1"
  | "hero2"
  | "hero3"
  | "hero4"
  | "target"
  | "lastDamaged"
  | "randomHero"
  | "center"
  | "top"
  | "bottom";

export const PARTICLE_ANCHORS: { value: ParticleAnchor; label: string }[] = [
  { value: "boss", label: "BOSS" },
  { value: "hero1", label: "HERO 1" },
  { value: "hero2", label: "HERO 2" },
  { value: "hero3", label: "HERO 3" },
  { value: "hero4", label: "HERO 4" },
  { value: "target", label: "TARGETED HERO (of the move)" },
  { value: "lastDamaged", label: "LAST DAMAGED HERO" },
  { value: "randomHero", label: "RANDOM HERO" },
  { value: "center", label: "ARENA CENTER" },
  { value: "top", label: "ARENA TOP" },
  { value: "bottom", label: "ARENA BOTTOM" },
];

export interface ParticleEmitterDef {
  id: string;
  name: string;
  spriteId: string;
  mode: "burst" | "continuous";
  /** seconds into the animation when the emitter is created */
  spawnAt: number;
  /** seconds after spawn when the emitter is destroyed (null = persists) */
  despawnAt: number | null;
  anchor: ParticleAnchor;
  /** burst: total particles; continuous: particles per spawn tick */
  count: number;
  /** continuous: seconds between spawn ticks */
  interval: number;
  /** particles fly outward from the spawn point in random directions */
  outward: boolean;
  speed: number;
  /** constant velocity added to every particle (e.g. driftY -40 = move up) */
  driftX: number;
  driftY: number;
  gravity: number;
  rotSpeed: number; // deg/s
  scale: number;
  fade: boolean;
  lifetime: number;
  /** random spawn offset radius around the anchor */
  spread: number;
}

export interface AnimationData {
  name: string;
  frames: AnimFrame[];
  emitters: ParticleEmitterDef[];
}

export function newAnimation(name = "New Animation"): AnimationData {
  return { name, frames: [{ spriteId: "boss_grim", duration: 0.4 }], emitters: [] };
}

export function newEmitter(spawnAt = 0): ParticleEmitterDef {
  return {
    id: uid("em"),
    name: "Emitter",
    spriteId: "spark",
    mode: "burst",
    spawnAt,
    despawnAt: 1,
    anchor: "boss",
    count: 10,
    interval: 0.1,
    outward: true,
    speed: 60,
    driftX: 0,
    driftY: -30,
    gravity: 0,
    rotSpeed: 90,
    scale: 2,
    fade: true,
    lifetime: 0.8,
    spread: 6,
  };
}

export interface Asset<T = unknown> {
  id: string;
  kind: AssetKind;
  name: string;
  data: T;
  updatedAt: number;
}

export interface Vec2 {
  x: number;
  y: number;
}

// ---------------- Sprites ----------------

export interface SpriteData {
  name: string;
  type: "builtin" | "pixels" | "image";
  /** pixel-editor grid (rows of palette keys) */
  grid?: string[];
  /** palette key -> css color */
  palette?: Record<string, string>;
  /** uploaded PNG data url (kept at original resolution) */
  dataUrl?: string;
  /** optional folder for organizing sprites in the library */
  folder?: string;
}

// ---------------- Bosses ----------------

export interface BossStats {
  maxHp: number;
  attack: number;
  defense: number;
  speed: number;
  maxTp: number;
  critChance: number; // 0..1
  critDamage: number; // multiplier, e.g. 1.5
  soulDamageMult: number; // multiplier applied to bullet damage vs SOUL
}

export interface BossData {
  name: string;
  description: string;
  spriteId: string;
  stats: BossStats;
  abilityIds: string[];
  /** battle-scene background preset id (data-driven, more later) */
  background?: string;
  /** looping battle theme (sound asset id) */
  themeId?: string;
  /** boss sprite height in px during battle */
  spriteSize?: number;
  /** animation asset ids per trigger: idle | damaged | killed | attack | victory | defend | ability:<id> */
  animations?: Record<string, string>;
  /** hover (glide up/down) or stand static on the ground */
  hover?: boolean;
  /** battle positions in % of the scene */
  layout?: BattleLayout;
  /** grid background line color */
  bgColor?: string;
  /** background effect overlay */
  bgEffect?: "none" | "beams" | "rain" | "stars" | "fire" | "snow";
  bgEffectColor?: string;
  /** floor: 'default' | 'none' | 'sprite:<id>' */
  floor?: string;
  /** persistent particle effects anchored to the boss sprite */
  effects?: BossEffectDef[];
  /** built-in afterimages trail */
  afterimages?: boolean;
}

export interface BossEffectDef {
  id: string;
  name: string;
  spriteId: string;
  /** offset as fraction of the boss sprite box (-0.5..0.5) */
  ax: number;
  ay: number;
  mode: "burst" | "continuous";
  interval: number;
  count: number;
  outward: boolean;
  speed: number;
  driftX: number;
  driftY: number;
  gravity: number;
  rotSpeed: number;
  scale: number;
  fade: boolean;
  lifetime: number;
  spread: number;
  /** active while boss HP% is within this window */
  hpMin: number;
  hpMax: number;
}

export function newBossEffect(): BossEffectDef {
  return {
    id: uid("bfx"),
    name: "Boss Effect",
    spriteId: "spark",
    ax: 0,
    ay: -0.4,
    mode: "continuous",
    interval: 0.15,
    count: 1,
    outward: false,
    speed: 20,
    driftX: 0,
    driftY: -40,
    gravity: 0,
    rotSpeed: 120,
    scale: 2,
    fade: true,
    lifetime: 0.8,
    spread: 8,
    hpMin: 0,
    hpMax: 100,
  };
}

export interface BattleLayout {
  boss: Vec2;
  heroes: Vec2[];
}

/** player customization of a roster hero (or a fully custom hero when stored as kind 'hero') */
export interface HeroCustom {
  name?: string;
  spriteId?: string;
  hover?: boolean;
  /** idle | attack | ability | heal | damaged | killed | defend */
  animations?: Record<string, string>;
  maxHp?: number;
  attack?: number;
  defense?: number;
  magic?: number;
  actions?: HeroAction[];
}

// ---------------- Attacks (bullet-hell timelines) ----------------

export type Easing = "linear" | "in" | "out" | "inout" | "step";

/** Scalar keyframe. `e` = easing from this key to the next. */
export interface KF {
  t: number;
  v: number;
  e: Easing;
}
/** Vector keyframe for position. */
export interface KF2 {
  t: number;
  x: number;
  y: number;
  e: Easing;
}

export type Collision =
  | { type: "circle"; radius: number }
  | { type: "rect"; w: number; h: number }
  | { type: "none" };

export type MovementType = "keyframed" | "linear" | "radial" | "homing" | "static";
export type ObjKind = "projectile" | "hazard" | "warning" | "effect";
export type LayerId = "background" | "warning" | "projectiles" | "effects" | "foreground";

export const LAYER_ORDER: LayerId[] = ["background", "warning", "projectiles", "effects", "foreground"];

export interface AttackObject {
  id: string;
  name: string;
  kind: ObjKind;
  spriteId: string;
  layer: LayerId;
  /** damage = bossAttack * damageMult */
  damageMult: number;
  collision: Collision;
  movement: MovementType;
  keyframes: {
    pos: KF2[];
    rot: KF[]; // degrees
    scale: KF[];
    opacity: KF[]; // 0..1
  };
  /** movement params for non-keyframed movement */
  velocity: number; // px/s
  angle: number; // degrees; direction for linear/radial
  accel: number; // px/s^2 along direction of travel
  turnRate: number; // deg/s for homing
  spin: number; // deg/s visual spin for non-keyframed objects
  /** timeline window of this object (absolute seconds) */
  start: number;
  lifetime: number | null;
  /** sound ids: 'default' | 'none' | preset id | 'asset:<id>' */
  spawnSound?: string;
  hitSound?: string;
  despawnSound?: string;
}

export interface AttackBox {
  width: number;
  height: number;
  soulStart: Vec2;
}

/** keyframed attack-box size over time */
export interface BoxKey {
  t: number;
  w: number;
  h: number;
}

export interface AttackData {
  name: string;
  description: string;
  box: AttackBox;
  /** optional box-size keyframes (interpolated). Empty = static box. */
  boxKeys?: BoxKey[];
  duration: number;
  /** SOUL invulnerability after a hit, seconds */
  invuln: number;
  soulMaxHp: number;
  objects: AttackObject[];
}

// ---------------- Abilities ----------------

export type AbilityTarget = "self" | "hero" | "all" | "random" | "soul" | "none";
export type AbilityEffect = "damage" | "heal" | "drain" | "buff" | "debuff" | "bullet";
export type AbilityCategory =
  | "offensive"
  | "defensive"
  | "healing"
  | "bullet"
  | "buff"
  | "debuff"
  | "utility";

export interface AbilityData {
  name: string;
  description: string;
  category: AbilityCategory;
  tpCost: number;
  cooldown: number; // boss turns
  target: AbilityTarget;
  effect: AbilityEffect;
  /** damage/heal amount */
  power: number;
  /** if true, power is a multiplier of boss Attack instead of flat */
  powerIsMultiplier: boolean;
  /** for bullet effect: attack asset id */
  attackId: string | null;
  /** for buff/debuff */
  buffStat: "attack" | "defense";
  buffAmount: number;
  buffDuration: number; // turns
  /** for drain: fraction of damage dealt healed back */
  drainHeal: number;
}

// ---------------- Heroes (data-driven roster) ----------------

export type HeroActionKind = "attack" | "magic" | "heal" | "defend";

export interface HeroAction {
  id: string;
  name: string;
  kind: HeroActionKind;
  /** damage multiplier of hero attack/magic stat, or heal amount when kind=heal */
  power: number;
  weight: number;
  /** AI bias condition */
  when?: "always" | "allyHurt" | "selfHurt" | "bossLow";
}

export interface HeroData {
  id: string;
  name: string;
  spriteId: string;
  maxHp: number;
  attack: number;
  defense: number;
  magic: number;
  actions: HeroAction[];
}

// ---------------- Soul AI difficulty ----------------

export interface SoulAIDifficulty {
  id: string;
  name: string;
  reaction: number; // seconds before new threats are noticed
  speed: number; // px/s max speed
  accel: number; // px/s^2
  predict: number; // seconds of prediction horizon
  noise: number; // px of target jitter
  replan: number; // seconds between replans
  mistake: number; // 0..1 chance of a sloppy choice
}

export const SOUL_DIFFICULTIES: SoulAIDifficulty[] = [
  { id: "easy", name: "EASY", reaction: 0.45, speed: 85, accel: 380, predict: 0.4, noise: 70, replan: 0.5, mistake: 0.35 },
  { id: "normal", name: "NORMAL", reaction: 0.3, speed: 110, accel: 500, predict: 0.7, noise: 45, replan: 0.34, mistake: 0.16 },
  { id: "hard", name: "HARD", reaction: 0.18, speed: 135, accel: 650, predict: 1.0, noise: 26, replan: 0.24, mistake: 0.07 },
  { id: "expert", name: "EXPERT", reaction: 0.1, speed: 160, accel: 800, predict: 1.35, noise: 12, replan: 0.15, mistake: 0.02 },
  { id: "perfect", name: "PERFECT", reaction: 0.04, speed: 185, accel: 950, predict: 1.7, noise: 4, replan: 0.08, mistake: 0 },
];

// ---------------- Shared helpers ----------------

export function uid(prefix = "id"): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export const DEFAULT_STATS: BossStats = {
  maxHp: 1000,
  attack: 50,
  defense: 10,
  speed: 10,
  maxTp: 100,
  critChance: 0.08,
  critDamage: 1.5,
  soulDamageMult: 1,
};

export function newAttackObject(kind: ObjKind, start = 0): AttackObject {
  const base: AttackObject = {
    id: uid("obj"),
    name: kind === "warning" ? "Warning" : kind === "hazard" ? "Hazard" : kind === "effect" ? "Effect" : "Projectile",
    kind,
    spriteId: kind === "effect" ? "spark" : "bullet",
    layer: kind === "warning" ? "warning" : "projectiles",
    damageMult: kind === "warning" || kind === "effect" ? 0 : 0.5,
    collision: { type: "circle", radius: 8 },
    movement: "keyframed",
    keyframes: {
      pos: [{ t: start, x: 100, y: 60, e: "linear" }],
      rot: [],
      scale: [],
      opacity: [],
    },
    velocity: 80,
    angle: 90,
    accel: 0,
    turnRate: 120,
    spin: 0,
    start,
    lifetime: null,
  };
  return base;
}

export function newAttack(name = "New Attack"): AttackData {
  return {
    name,
    description: "",
    box: { width: 460, height: 280, soulStart: { x: 230, y: 140 } },
    duration: 6,
    invuln: 0.5,
    soulMaxHp: 160,
    objects: [],
  };
}

export function newAbility(name = "New Ability"): AbilityData {
  return {
    name,
    description: "",
    category: "offensive",
    tpCost: 20,
    cooldown: 0,
    target: "hero",
    effect: "damage",
    power: 60,
    powerIsMultiplier: false,
    attackId: null,
    buffStat: "attack",
    buffAmount: 10,
    buffDuration: 2,
    drainHeal: 0.5,
  };
}

export function newBoss(name = "New Boss"): BossData {
  return {
    name,
    description: "",
    spriteId: "boss_grim",
    stats: { ...DEFAULT_STATS },
    abilityIds: [],
    background: "grid",
    hover: true,
  };
}
